/**
 * This example was written by Bruno Lowagie in answer to the following question:
 * https://www.linkedin.com/groups/Script-Change-Author-Name-Comments-159987.S.5984062085800144899
 */
package com.parseImage;
 
 
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.exceptions.UnsupportedPdfException;
import com.itextpdf.text.pdf.PRStream;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
 
public class ParseCzech {
	public static final String DEST = "./src/test/resources";
    public static final String SRC = "./src/test/resources/scanner.pdf";
	public static void extractImage(String filename){  
        
        PdfReader reader = null;  
        try {  
            //读取pdf文件  
            reader = new PdfReader(filename);  
            //获得pdf文件的页数  
            int sumPage = reader.getNumberOfPages();
            //读取pdf文件中的每一页  
            for(int i = 1;i <= sumPage;i++){  
                //得到pdf每一页的字典对象  
                PdfDictionary dictionary = reader.getPageN(i);  
                //通过RESOURCES得到对应的字典对象  
                PdfDictionary res = (PdfDictionary) PdfReader.getPdfObject(dictionary.get(PdfName.RESOURCES));  
                //得到XOBJECT图片对象  
                PdfDictionary xobj = (PdfDictionary) PdfReader.getPdfObject(res.get(PdfName.XOBJECT));  
                Set<PdfName> keys = xobj.getKeys();
                for (PdfName pdfName : keys) {
                	PdfObject obj = xobj.get(pdfName);	
                	if(obj.isIndirect()){
						PdfDictionary tg = (PdfDictionary) PdfReader.getPdfObject(obj);					
						PdfName type = (PdfName) PdfReader.getPdfObject(tg.get(PdfName.SUBTYPE));
						if(PdfName.IMAGE.equals(type)){		
							PdfObject object =  reader.getPdfObject(obj);
							if(object.isStream()){						
								PRStream prstream = (PRStream)object;
								byte[] b;
								try{
									b = reader.getStreamBytes(prstream);
								}catch(UnsupportedPdfException e){
									b = reader.getStreamBytesRaw(prstream);
								}
								InputStream in = new ByteArrayInputStream(b);
								TwoDimensionCode handler = new TwoDimensionCode();
								String decoderContent = handler.decoderQRCode(in);
				                
								System.out.println("解析结果如下：");    
						        System.out.println(decoderContent);    
						        System.out.println("========decoder success!!!");
                	
							}
							 PdfStamper pdfStamper = null;
							try {
								pdfStamper = new PdfStamper(reader, new FileOutputStream("D:\\PDF\\a.pdf"));
							} catch (DocumentException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} 
							 PdfContentByte over = pdfStamper.getOverContent(1);
						}
                	}
				}
            }
        } catch (IOException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
} 
	public static void main(String[] args) {
		extractImage(SRC);
	}
}