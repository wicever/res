package com.parseImage.parse;

import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;

import com.google.zxing.Binarizer;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.parseImage.BufferedImageLuminanceSource;

public class ParseImage {

	public static void main(String[] args) throws NotFoundException, IOException {
		String decode = decode("D:\\temp\\Img-1.png");
		System.out.println(decode);
	}
	public static String decode(String filepath) throws IOException, NotFoundException {
		  BufferedImage bufferedImage = ImageIO.read(new FileInputStream(filepath));
		  LuminanceSource source = new BufferedImageLuminanceSource(bufferedImage);
		  Binarizer binarizer = new HybridBinarizer(source);
		  BinaryBitmap bitmap = new BinaryBitmap(binarizer);
		  HashMap<DecodeHintType, Object> decodeHints = new HashMap<DecodeHintType, Object>();
		  decodeHints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
		  Result result = new MultiFormatReader().decode(bitmap, decodeHints);
		  return result.getText();
		}
}
