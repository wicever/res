package com.parseImage;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.exceptions.UnsupportedPdfException;
import com.itextpdf.text.pdf.PRIndirectReference;
import com.itextpdf.text.pdf.PRStream;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfException;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfObject;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.hyphenation.TernaryTree.Iterator;

public class aaa {

	public static void main(String[] args) throws PdfException, DocumentException, IOException {
		
	PdfReader pdf = new PdfReader("./src/test/resources/scanner.pdf");
	PdfStamper stp = new PdfStamper(pdf, new FileOutputStream("./src/test/resources/1.gif"));
	PdfWriter writer = stp.getWriter();
	Image img = Image.getInstance("./src/test/resources/czech.jpg");
	PdfDictionary pg = pdf.getPageN(1);
	PdfDictionary res =
	    (PdfDictionary)PdfReader.getPdfObject(pg.get(PdfName.RESOURCES));
	PdfDictionary xobj =
	    (PdfDictionary)PdfReader.getPdfObject(res.get(PdfName.XOBJECT));
	if (xobj != null) {
		Set<PdfName> keys = xobj.getKeys();
	    for (PdfName pdfName : keys) {
	    	PdfObject obj = xobj.get(pdfName);
	        if (obj.isIndirect()) {
	            PdfDictionary tg = (PdfDictionary)PdfReader.getPdfObject(obj);
	            PdfName type =
	                (PdfName)PdfReader.getPdfObject(tg.get(PdfName.SUBTYPE));
	            if (PdfName.IMAGE.equals(type)) {
	                PdfReader.killIndirect(obj);
	                Image maskImage = img.getImageMask();
	                if (maskImage != null)
	                    writer.addDirectImageSimple(maskImage);
	                writer.addDirectImageSimple(img, (PRIndirectReference)obj);
	                break;
	            }
	        }
	    }
	    TwoDimensionCode handler = new TwoDimensionCode();
	    String decoderContent = handler.decoderQRCode("./target/Img%s.%s-1.png");    
        System.out.println("解析结果如下：");    
        System.out.println(decoderContent);    
        System.out.println("========decoder success!!!");
	}
	try {
		stp.close();
	} catch (DocumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
