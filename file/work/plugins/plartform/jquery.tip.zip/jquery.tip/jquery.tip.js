/**
 * 使用说明:
 * 消息提示框: 
 * $.tip(
 * 		message,	// 消息内容
 * 		stay				// 停留的时间(毫秒),默认2000
 * 	);
 * $.tip("你好",3000);
 * $.tip("你好坏！")
 * 
 * 确认提示框:
 * $.confirm({
 * 		message:"整点提示呗！",												// 提示消息
 * 		buttons:[{label:"xx",click:function(){alert("a");}},	// 按钮定义，label:按钮文本;	clazz:按钮样式;	click: 按钮单击事件, autoClose: 是否自动关闭
 * 		{type:"yes",click:function(){}},									// 简约按钮定义, 覆盖组件内嵌的按钮单击事件
 * 		"cancle","yes","no"]														//组件内嵌的按钮:取消,是,否
 * });
 * 
 * $.confirm({message:"你们好吗？",buttons:[{type:"yes",click:function(){alert("我很好！");}},{type:"no",click:function(){alert("我他妈没法活啦！");}}]});
 * $.confirm({message:"你们好吗？",buttons:[{type:"yes",click:function(){alert("我很好！");}},"no"]});
 */

jQuery.jsRenderTemplate.register({
	id:"plugin.tip.message",
	content:"<div class=\"message\" id=\"{{:id}}\" style=\"top:{{:top}}px;z-index:10060;position:fixed;\"><span class=\"bg-info\">{{:message}}</span></div>"
});
jQuery.jsRenderTemplate.register({
	id:"plugin.tip.confirm",
	url: "resources/plugins/jquery.tip/jquery.confirm.html"
});

(function($) {
	  "use strict";
	  var dialogArea = null;
	  var initDialogArea =  function(){
		  if(dialogArea == null){
			  $("body").append("<div id='systemDialogs'></div>");
			  dialogArea = $("#systemDialogs");
		  } 
	  };
	  var positionStatus = new Array(30);
	  for(var i =0; i < positionStatus.length; i++) {
		  positionStatus[i] = false;
	  }
	  var getPosition = function(){
		  var result = 0;
		  for(var i = 0; i < positionStatus.length; i ++) {
			  if(positionStatus[i] === false) {
				  result = i;
				  positionStatus[i] = true;
				  break;
			  }
		  }
		 return result;
	  };
	  
	  $.tip = function(message,stay){
		  initDialogArea();
		  var postionIndex = getPosition();
		  var param = {id:$.randomString(5),top: 120+44*postionIndex,"message":message};
		  var tipMessageTemplate = $.jsRenderTemplate.getTemplateById("plugin.tip.message");
		  var tipMessagehtml = tipMessageTemplate.render(param);
		  dialogArea.append(tipMessagehtml);
		  var tipMessage  = dialogArea.find("#" + param.id);
		  tipMessage.show();
		  setTimeout(function fadeOut(){ tipMessage.fadeOut(); positionStatus[postionIndex] =false;},stay?stay:2000);
	  };
	  
	  $.confirm = function(options){
		  initDialogArea();
		  
		  var options = $.extend({
			  id:$.randomString(5),
			  message:"",
			  buttons:[{label:$.confirm.i18n.i18nBtnOk,clazz:"", click:function(){}},"cancel"]
		  },options);
		  
		  $.each(options.buttons, function(i, button){
			  if(typeof button == "string") {
				  if("cancel" == button){
					  button = {id:$.randomString(8),label:$.confirm.i18n.i18nBtnCancel,clazz:"", click:function(){}};
					  options.buttons[i] = button;
				  }
				  if("yes" == button){
					  button = {id:$.randomString(8),label:$.confirm.i18n.i18nBtnYes,clazz:"", click:function(){}};
					  options.buttons[i] = button;
				  }
				  if("no" == button){
					  button = {id:$.randomString(8),label:$.confirm.i18n.i18nBtnNo,clazz:"", click:function(){}};
					  options.buttons[i] = button;
				  }
			  }
			  if(typeof button == "object"){
				  if(!button.id) {
					  button.id = $.randomString(8);
				  }
				  if(button.type && button.type == "yes") {
					  button.label = $.confirm.i18n.i18nBtnYes;
				  }
				  if(button.type && button.type == "no") {
					  button.label = $.confirm.i18n.i18nBtnNo;
				  }
				  if(button.type && button.type == "cancel") {
					  button.label = $.confirm.i18n.i18nBtnCancel;
				  }
			  }
		  });
		  
		  var confimTemplate = $.jsRenderTemplate.getTemplateById("plugin.tip.confirm");
		  var confimHtml = confimTemplate.render(options);
		  dialogArea.append(confimHtml);
		  var confimDom = $("#" + options.id);
		  $.each(options.buttons, function(i, button){
			  var buttonId = button.id;
			  confimDom.find("#" + buttonId).click(function(e){
				  button.click();
				  confimDom.hide().remove();
			  });
		  });
		  
		  var x,y;
		  var bodyWidth = $("body").width();
		  var confimBodyWidth = 250;
		  if(options.event) {
			  var event  = options.event;
			  x = (event.pageX - event.offsetX + $(event.target).width() + 35), y = event.pageY-100;
			  x = x<0? 100:x;
			  y = y<0? 20: y;
			  x = (x>(bodyWidth - confimBodyWidth - $(event.target).width()))? (bodyWidth - confimBodyWidth - $(event.target).width()):x;
			  confimDom.find(".bg-danger").css({"position":"absolute","left":x,"top":y,"z-index":"10060"});
		  } else {
			  var x = '50%', y = $("body").height()/2;
			  confimDom.find(".bg-danger").css({"position":"absolute","left":x,"top":y,"transform":"translateX(-50%) translateY(-50%)","z-index":"10060"}); 

		  }
		  confimDom.show();
	  }
	  
	  $.confirm.i18n = {
		  i18nBtnYes : '是',
		  i18nBtnNo : '否',
		  i18nBtnOk : 'Ok',
		  i18nBtnCancel  : 'Cancel'
	  };
})(jQuery);