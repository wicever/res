;(function($) {
	  if ($.confirm) {
	    $.extend($.confirm.i18n, {
	    	i18nBtnYes : '是',
	    	i18nBtnNo : '否',
	    	i18nBtnOk : '确定',
	    	i18nBtnCancel  : '取消'
	    });
	  }
})(jQuery);