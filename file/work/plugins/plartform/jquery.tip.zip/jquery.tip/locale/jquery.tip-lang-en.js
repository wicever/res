;(function($) {
	  if ($.confirm) {
	    $.extend($.confirm.i18n, {
	    	i18nBtnYes : 'Yes',
	    	i18nBtnNo : 'No',
	    	i18nBtnOk : 'Ok',
	    	i18nBtnCancel  : 'Cancel'
	    });
	  }
})(jQuery);