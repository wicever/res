/**
 * 使用说明:
 * $.seniorDialog({
 * 		title:"对话框",	
 * 		size:"lg|sm",		// lg: 大框，sm: 小框, '':默认为中等 
 * 		height:250,		// 弹现框高度
 * 		contentId:"",		//弹出框内展示内容
 * 		template:{			//弹出框内要加载的模板
 * 			name:"",	    //<script>模板ID, 如使用jQuery.jsRenderTemplate.register注册的模板，必须将script属性设置为true,且模板id值不许出现'.','$'等特殊字符, 如$.jsRenderTemplate.register({id:"pageDesignerPropertyGroupTable",url:"xxx",script:true});
 * 			data:{}			//模板将要使用的数据
 * 		},
 * 		buttons:[		//弹出框按钮
 * 			{label:"确定",clazz:"", click:function(){}},	// 按钮定义，label:按钮文本;	clazz:按钮样式;	click: 按钮单击事件, autoClose: 是否自动关闭
 * 			"cancel"	//组件内嵌的按钮:取消
 * 		],
 *    autoDestroy:true	//在窗体关闭后，是否自动销毁窗体，默认值:true
 * });
 * 
 * 注： $.seniorDialog 返回窗体的id, 在窗体关闭后会自动销毁窗体，如需在关闭后保留窗体，使用参数autoDestroy:true, 则窗体的销毁由调用者管理
 * 
 * $.seniorDialog({title:"修改密码",buttons:[{label:"点我", click:function(){alert("不要烦我");}},"cancel"]});
 */

jQuery.jsRenderTemplate.register({
	id:"plugin.dialog",
	url: "resources/plugins/jquery.dialog/jquery.dialog.html"
});

(function($) {
  "use strict";
  var dialogArea = null;
  var initDialogArea =  function(){
	  if(dialogArea == null){
		  $("body").append("<div id='systemDialogs'></div>");
		  dialogArea = $("#systemDialogs");
	  } 
  };
  var getDialogId = function(){
	  return $.randomString(5);
  };
  
  $.seniorDialog = function(options){
	  var options = $.extend({
		  title:"对话框",
		  size:"",
		  buttons:[{label:"确定",clazz:"", click:function(){}},"cancel"],
		  template:{
			  name:"",
			  data:{}
		  },
		  autoDestroy:true
	  },options);
	  options.id = getDialogId();
	  for(var i = 0; i < options.buttons.length; i++) {
		  var button = options.buttons[i];
		  if(typeof button == "string") {
			  if("cancel" == button){
				  button = {id:$.randomString(8),label:"取消",clazz:"", click:function(){},autoClose:true};
				  options.buttons[i] = button;
			  }
		  }
		  if(typeof button == "object" && !button.id){
			  button.id = $.randomString(8);
		  }
	  }
	  
	  initDialogArea();
	  
	  var dialogTemplate = $.jsRenderTemplate.getTemplateById("plugin.dialog");
	  var dialogHtml = dialogTemplate.render(options);
	  dialogArea.append(dialogHtml);
	  var dialogDom = $("#" + options.id);
	  
	  $.each(options.buttons, function(i, button){
		  var buttonId = button.id;
		  dialogDom.find("#" + buttonId).click(function(e){
			  button.click($("#" + options.id),e);
			  if(button.autoClose === true) {
				  $("#" + options.id).modal("hide");
			  } 
		  });
	  });
	  
	  if(options.autoDestroy === true){
		  dialogDom.on('hidden.bs.modal', function (e) {
			  dialogDom.remove();
		  });
	  }
	  
	  if(options.template && options.template.name){
		  $.jsRenderTemplate.render(options.template.name,dialogDom.find(".modal-body"),options.template.data);
	  }
	  
	  if(options.contentId){
		  dialogDom.find(".modal-body").append($("#" + options.contentId).html());
	  }
	  
	  if(options.onload){
		  options.onload(dialogDom);
	  }
	  
	  dialogDom.modal({backdrop:"static",keyboard:false,show:true});
	  return dialogDom;
  };
})(jQuery);