;(function($) {
	  if ($.seniorDialog) {
	    $.extend($.seniorDialog.i18n, {
	    	i18nBtnOk : '确定',
	    	i18nBtnCancel  : '取消'
	    });
	  }
})(jQuery);