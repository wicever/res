;(function($) {
	  if ($.seniorDialog) {
	    $.extend($.seniorDialog.i18n, {
	    	i18nBtnOk : 'OK',
	    	i18nBtnCancel  : 'Cancel'
	    });
	  }
})(jQuery);