/**
 *  =========================== 初始化jsrender模板的内容begin ======================================
 */
var treeTableTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.treeTable.html", function(data){
		treeTableTplhtml = data;
	 });
});

var fatherTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.father.html", function(data){
		fatherTplhtml = data;
	 });
});

var fatherTrTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.fatherTr.html", function(data){
		fatherTrTplhtml = data;
	 });
});

var childTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.child.html", function(data){
		childTplhtml = data;
	 });
});


var seniorTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.senior.html", function(data){
		seniorTplhtml = data;
	 });
});

var middleTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.treeTable/jquery.middle.html", function(data){
		middleTplhtml = data;
	 });
});


/**
 *  =========================== 初始化jsrender模板的内容end ======================================
 */
 

/**
 *  =========================== 定义Jquery插件begin ======================================
 */
(function($) {
	
	function setScriptHtml(sc,c){
		try{
			sc.innerHTML =c;
		}catch(e){
			sc.text =c;
		}
	}


	/*
	 * 创建主模板
	 */
	$.createTreetableTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("treeTableTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","treeTableTpl");
			 setScriptHtml(sc,treeTableTplhtml);
			 //sc.innerHTML =treeTableTplhtml;
			 dom.appendChild(sc);
		 }
		 return "treeTableTpl";
	 };
	 /*
	 * 创建主表
	 */
	$.createFatherTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("fatherTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","fatherTpl");
			 setScriptHtml(sc,fatherTplhtml);
			 //sc.innerHTML =fatherTplhtml;
			 dom.appendChild(sc);
		 }
		 return "fatherTpl";
	 };
	 
	 /*
	 * 创建主表字段
	 */
	 
	$.createFatherTrTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("fatherTrTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","fatherTrTpl");
			 setScriptHtml(sc,fatherTrTplhtml);
			 //sc.innerHTML =fatherTrTplhtml;
			 dom.appendChild(sc);
		 }
		 return "fatherTrTpl";
	 };
	 
	 /*
	 * 创建子表
	 */
	$.createChildTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("childTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","childTpl");
			 setScriptHtml(sc,childTplhtml);
			 //sc.innerHTML =childTplhtml;
			 dom.appendChild(sc);
		 }
		 return "childTpl";
	 };
	 
	 
	 /*
	 * 创建高级字段
	 */
	$.createSeniorTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("seniorTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","seniorTpl");
			 setScriptHtml(sc,seniorTplhtml);
			 //sc.innerHTML =seniorTplhtml;
			 dom.appendChild(sc);
		 }
		 return "seniorTpl";
	 };
	 
	 /*
	 * 创建高级字段
	 */
	$.createMiddleTpl =function(){
		 var dom = document.body;
		 if($.checkHasCreate("middleTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id","middleTpl");
			 setScriptHtml(sc,middleTplhtml);
			 //sc.innerHTML =middleTplhtml;
			 dom.appendChild(sc);
		 }
		 return "middleTpl";
	 };
	 
	 /**
	  * 验证模板是否已经创建
	  */
	 $.checkHasCreate =function(id,data){
		 var falg =true;
		 $("body").find("script").each(function(){ 
			 if(id==$(this).attr("id")){
				 falg = false;
			 }
		}); 
		return falg;
	 };
	
	 $.initTreeTable =function(id,data){
		  
		 var treeTableTplId = $.createTreetableTpl();
		 var fatherTplId = $.createFatherTpl();
		 var fatherTrTplId = $.createFatherTrTpl();
		 var childTplId = $.createChildTpl ();
		 var seniorTplId = $.createSeniorTpl();
		 var middleTplId =  $.createMiddleTpl();
		 
		 fatherTplId  ="#"+fatherTplId;
		 fatherTrTplId  ="#"+fatherTrTplId;
		 childTplId ="#"+childTplId;
		 seniorTplId ="#"+seniorTplId;
		 middleTplId ="#"+middleTplId;
		 
		 var tableData = translateData(data);
		 var treeTableData = {modal:{
			 "modalData": tableData,
			 "father": fatherTplId,
			 "fatherTr": fatherTrTplId,
			 "child": childTplId,
			 "senior": seniorTplId,
			 "middle": middleTplId
		 },
		 changeManager: function() {
			 $.observable(this).setProperty({
				 treeTableManager: modal
			 });
		 }};
		 $.views.settings.allowCode(true);
			console.log('===========================================');
			console.log(treeTableData);
		 treeTableData.treeTableManager = treeTableData.modal;
		 var template1 = $.templates("#"+treeTableTplId);
		 var htmlOutput1 = template1.render(treeTableData);
		 $("#"+id).html(htmlOutput1);
	 };
	 
})(jQuery);
/**
 *  =========================== 定义Jquery插件end ======================================
 */


/**
 *  =========================== 公用方法 begin======================================
 */

function translateData(data){
	if(data.resources.length==0){
		data = fatherAdd(data.model);
	}
	var tableData = new Object();
	tableData.middleTable = new Object();
	tableData.senior = new Object();
	tableData = translateTreeTable(data.model,new Object() ,data,"main");
	tableData = translateMiddleTable(data.resources,data.model,tableData);
	tableData.senior = translateSeniorTable(data.resources,data.model);
//	$("#view").text(JSON.stringify(tableData));
	
	
	return tableData;
}

function translateMiddleTable(resources,model,tableData){
	tableData.middles =  new Array();
	var returnMiddleTableData =  new Object();
	var middleFields = new Array();
	
	var middleFields= new Array();
	//获取中间表对应资源的名称
	for(var i in resources){
		if(resources.hasOwnProperty(i)){
			var resource = resources[i];
			if(resource.name==model.resourceRefInfos[0].resourceName){
				for(var j in resource.fields){
					if(resource.fields.hasOwnProperty(j)){
						var field = resource.fields[j];
						if(field.$dwrClassName =='ManyToOneFieldDefinition'){
							middleFields.push(field);
						}
					}
				}
			}
		}
	}
	//获取中间表的资源拼装返回数据
	for(var i in resources){
		if(resources.hasOwnProperty(i)){
			var resource = resources[i];
			for(var j in middleFields){
				if(middleFields.hasOwnProperty(j)){
					var middleField = middleFields[j];
					if(resource.name==middleField.targetEntity){
						tableData.middles.push({caption:resource.caption,
							name:middleField.targetEntity,
							type:middleField.type,
							middleResourceName:resource.name,
							fatherResourceName:resource.name,
							middleResourceName:resource.name,
							table:resource.table,
							middleFields:new Array()
							});
					}
				}
			}
		}
	}
	
	for(var i in model.propertyDetails){
		if(model.propertyDetails.hasOwnProperty(i)){
			var propertyDetail = model.propertyDetails[i];
			var fieldName = propertyDetail.mappingInfoDetails.fieldMappings[0].fieldName;
			if(fieldName.split(".").length>1){
				var fatherFieldName = fieldName.split(".")[0];
				fieldName = fieldName.split(".")[1];
				
				var fatherField;
				for(var x in resources){
					if(resources.hasOwnProperty(x)){
						var resource = resources[x];
						if(resource.name==model.resourceRefInfos[0].resourceName){
							for(var y in resource.fields){
								if(resource.fields.hasOwnProperty(y)){
									var field = resource.fields[y];
									if(field.name==fatherFieldName){
										fatherField= field;
										for(var x in tableData.middles){
											if(tableData.middles.hasOwnProperty(x)){
												if(tableData.middles[x].name==fatherField.targetEntity){
													for(var y in resources){
														if(resources.hasOwnProperty(y)){
															if(resources[y].name==tableData.middles[x].name){
																for(var z in resources[y].fields){
																	if(resources[y].fields.hasOwnProperty(z)){
																		if(fieldName ==resources[y].fields[z].name){
																			tableData.middles[x].middleFields.push({caption:propertyDetail.caption,
																				name:propertyDetail.name,
																				type:propertyDetail.dataType,
																				viewType:"entity",
																				view:tableData.middles[x].caption,
																				viewColumn:resources[y].fields[z].caption,
																				table:tableData.middles[x].table,
																				column:resources[y].fields[z].column});
																		}
																	}
																}
															}
														}
													}
													
												}
											}
										}
									}
								}
							}
						}
					}
				}
				/*var middlefield;
				for(var x in resources){
					if(resources.hasOwnProperty(x)){
						var resource = resources[x];
						if(resource.name==fatherField.targetEntity){
							for(var y in resource.fields){
								if(resource.fields.hasOwnProperty(y)){
									var field = resource.fields[y];
									if(field.name==fieldName){
										middlefield= field;
									}
								}
							}
						}
					}
				}*/
				
			}
		}
	}
	
	
	return tableData;
}
function translateSeniorTable(resources,model){
	var returnSeniorTableData =  new Object();
	for(var i in resources){
		if(resources.hasOwnProperty(i)){
			var resource = resources[i];
			if(resource.$dwrClassName=="SpringBeanResourceDefinition"){
				returnSeniorTableData={"tableData":{caption:resource.caption,
					name:resource.name,
					type:"bean"}};
				returnSeniorTableData.fields = new Array();
				for(var j in resource.fields){
					if(resource.fields.hasOwnProperty(j)){
						var field = resource.fields[j];
						for(var k in model.propertyDetails){
							if(model.propertyDetails.hasOwnProperty(k)){
								var propertyDetail =   model.propertyDetails[k];
								if (propertyDetail.mappingInfoDetails.fieldMappings[0].fieldName ==field.name){
									//封装高级字段
									returnSeniorTableData.fields.push({
										caption:propertyDetail.caption,
										name:propertyDetail.name,
										type:propertyDetail.dataType,
										viewType:"bean",
										view:resource.caption,
										viewColumn:field.caption});
								}
							}
						}
					}
				}
			}
		}
	}
	return returnSeniorTableData;
}




//递归循环获取
function translateTreeTable(table,propertyDetail,data,type){
	var returnTable = new  Object();
	var returnTableData = translateTable(table,propertyDetail,data,type);
	returnTable = returnTableData.tableData;
	if(returnTable==undefined){
		returnTable = new Object();
	}
	
	returnTable.fields = new Array();
	returnTable.childs = new Array();
	for(var i in table.propertyDetails ){
		if(table.propertyDetails.hasOwnProperty(i)){
			//属性详情
			var propertyDetail = table.propertyDetails[i];
			if(checkIsFields(returnTableData.resourceData,propertyDetail)=="child"){//为子表
				var childTable;
				for(var j in data.childModels){
					if(data.childModels.hasOwnProperty(j)){
						var childModel = data.childModels[j];
						if(propertyDetail.mappingInfoDetails.attrs.componentType ==childModel.id){
							childTable = childModel;
						}
					}
				}
				var retrunChild = translateTreeTable(childTable,propertyDetail,data,'minor');
				returnTable.childs.push(retrunChild);
			}else if(checkIsFields(returnTableData.resourceData,propertyDetail)=="field"){//为字段属性
				var retrunfields = translatefields(propertyDetail,returnTableData.resourceData,type);
				if(!isEmptyObject(retrunfields)){
					returnTable.fields.push(retrunfields);
				}
			}
		}
	}
	return returnTable;
}

function checkIsFields(resource,property){
	for(var i in resource.fields ){
		if(resource.fields.hasOwnProperty(i)){
			var field = resource.fields[i];
			if(field.name.toUpperCase()==property.mappingInfoDetails.fieldMappings[0].fieldName.toUpperCase()){
				if(field.$dwrClassName =='GeneralFieldDefinition'||field.$dwrClassName =='IdFieldDefinition'){
					return "field";
				}else if (field.$dwrClassName =='OneToManyFieldDefinition'){
					return "child";
				}else if (field.$dwrClassName =='ManyToOneFieldDefinition'){
					return "middle";
				}
			}
		}
	}
}

function translateTable(table,propertyDetail,data,type){
	var returnTableData = new  Object();
	for(var j in data.resources){//循环资源
		if(data.resources.hasOwnProperty(j)){
			var resource = data.resources[j];
			for(var  k in table.resourceRefInfos){//循环table资源
				if(table.resourceRefInfos.hasOwnProperty(k)){
					var resourceRefInfo = table.resourceRefInfos[k];
					if(resource.name.toLowerCase()==resourceRefInfo.resourceName.toLowerCase()&&resourceRefInfo.resourceType== "entity"){
						if(type =='main'){
							returnTableData={"tableData":{caption:resource.caption,
								name:resourceRefInfo.resourceName,
								type:resourceRefInfo.resourceType,
								table:resource.table},"resourceData":resource};
						}else if(type =='minor'){
							returnTableData={"tableData":{caption:propertyDetail.caption,
								name:propertyDetail.name,
								type:propertyDetail.dataType,
								viewType:resourceRefInfo.dataType,
								view:resource.caption,
								table:resource.table},"resourceData":resource};
						}
					}
				}
			}
		}
	}
	return returnTableData;
}

function translatefields(propertyDetail,resourceData,type){
	var returnPropertyDetail = new  Object();
	for(var i in resourceData.fields){//循环资源
		if(resourceData.fields.hasOwnProperty(i)){
			var field = resourceData.fields[i];
			if(field.name.toUpperCase() ==propertyDetail.mappingInfoDetails.fieldMappings[0].fieldName.toUpperCase()){
				returnPropertyDetail={caption:propertyDetail.caption,
					name:propertyDetail.name,
					type:propertyDetail.dataType,
					viewType:"entity",
					view:resourceData.caption,
					viewColumn:field.caption,
					table:resourceData.table,
					column:field.column
				};
			}
		}
	}
	return returnPropertyDetail;
}


/*
 * 封装调用方法
 */
function initTreeTable(id,data){
	$.initTreeTable(id,data);
}

$.views
.helpers({	
	"isMainTable" : function(mainTable, name) {
		if (fatherName == name) {
			return true;
		}else {
			return false;
		}
	}
});



function isEmptyObject(e) {  
    var t;  
    for (t in e)  
        return !1;  
    return !0  
}  

/**
 *  =========================== 公用方法 end======================================
 */



