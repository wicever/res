jQuery.jsRenderTemplate.register({
	id:"plugin.tabTemplate",
	url:"resources/plugins/jquery.tab/jquery.tab.html"
});

/**
 * 使用方法:
 *
 * $("#workArea").tablet({
 * 	id:"testTabs",	// tab标签的ID
 * tabChanged: function(){newTab, oldTab},	
 * tabClosed: function(){tab},	
 * 	tabs:			// 标签页的定义
 * 	[{
 * 		id:"tab1",	// 标签页的ID
 * 		label:"xx"	// 标签页的名称
 * 	},
 * 	{
 * 		id:"tab2",
 * 		label:"yy",
 * 		active:true,	// 是否当前页
 * 		closeable:true, //是否显示关闭按钮
 *		template:{			//标签页内要加载的模板，不能与下面的url同时使用，如同时使用则会被url覆盖 
 *			name:"pageDesignerFrame",	//方法$.jsRenderTemplate.register注册的模板ID
 *			data:{}											//模板将要使用的数据
 *		}
 *		,tipMsg:"关闭前提示信息"
  *		url:"/resources/template/admin/pageNew/pageSet.html",	// 标签页内要加载的url
  *		urls:[{				// 与url冲突，配合template属性使用，目前尚未实现
  *				id:"",		// div的ID 
  *				url:"",		// 指定id的div内要装载的url
  *			},{
  *				id:"",
  *			...
  *			}]
  *		onload:function(tab){} 				// 当标签页加载完成后的回调，参数为定义标签定义对象
 * 	}]
 * });
 * 
 
 * 当一个页面有多个标签区域时，使用 $.tabs.initOrGetBack方法初始化或获取相应的实例，得到标签区域的实例后，可以调用相关方法
 * 如addOrFocus添加新标签，remove删除标签
 * 
 * 
 * 全局事件：
 * tabChanged 标签切换事件，当添加新的标签，或者手动点击切换标签时触发
 * 方法接收四个参数：
 * 第一个参数为事件对象，第二个参数为切换后的标签配置信息，第三个参数为切换之前的标签配置信息，第四个参数是标签区域的配置信息
 * 使用方法:
 * 		$(document).bind("tabChanged",function(e,newTab, oldTab, tabArea ){console.log(newTab);console.log(oldTab);console.log(tabArea);});
 * 
 * 
 * tabClosed 标签关闭之后
 * 方法接收三个参数， 第一个参数为事件对象，第二个参数为关闭标签的配置信息,第三个参数为标签区域的配置信息
 * 使用方法:
 * 		$(document).bind("tabClosed",function(e,tab,tabArea){console.log(tab.id + " is closed");});
 * 
 * $.tabs.initOrGetBack(
 * selector,
 * tabAreaId
 * );
 *
 *$.tabs.get(
 *tabAreaName
 *);
 * 
 $("#workArea").tablet({id:"testTabs",tabs:[{id:"tab1",label:"xx"},{id:"tab2",label:"yy",active:true}]});
 $.tabs.initOrGetBack("#workArea","testTabs").add({id:"abc",label:"xxx",active:true});
 $.tabs.get("testTabs").add({id:"abc",label:"xxx",active:true});
 *
 */


(function($) {
  "use strict";
  var tabAreas = {};
  var tabFunction = function(self,options){
	  if(typeof(options) == "string"){
		  var tabAreaName = options;
		  if(tabAreas.hasOwnProperty(tabAreaName)) {
			  return tabAreas[tabAreaName];
		  } else {
			  options = {id:tabAreaName,tabs:[]};
		  }
	  } 
	  var existPropertyIndex = function(arry,property){
		  var position = -1;
		  for (var i = 0; i < arry.length; i++) {
			  if(arry[i].hasOwnProperty(property)){
			      // 需要对激活的标签的进行特殊处理，以适应切换后刷新，再切换失去焦点的情况。
				  if("active" == property) {
					  if(arry[i].active) {
				    	  position = i;
						  break;
					  }
				  } else {
					  position = i;
					  break;
				  }
			  }
		  }
		  return position;
	  }

	  // 渲染模板完成后的属性处理
	  var dealingOptionProperties = function(tabDef){
		  var tabDealing = function(tab){
			 if(tab.template && tab.template.name) {
				$.jsRenderTemplate.render(tab.template.name,"#" + tab.id,tab.template.data,function(){
					if(tab.onload) {
						tab.onload(tab,$("#" + tab.id));
					}
				});
			} else if(tab.url) {
				$("#" + tab.id).load(tab.url,{},function(){
					if(tab.onload) {
						tab.onload(tab,$("#" + tab.id));
					}
				});
			} else {
				if(tab.onload) {
					tab.onload(tab,$("#" + tab.id));
				}
			}
		  };
		  
		 if($.isArray(tabDef)) {
			 $.each(tabDef,function(index,tab){
				 tabDealing(tab);
			});
		 } else {
			 var tab = tabDef;
			 tabDealing(tab)
		 }
	  };
	  
	  var defualtOptions = {
		id:"tabs",
		tabs:[{id:"tab1",label:"标签1",active:true}],
		close:function(index){
			var self = this;
			var c = function(){
				var currentTab = self.tabs[index];
				$.observable(self.tabs).remove(index);
				if(self.tabs.length == 0) {
					$("#"+self.id).remove();
					$("#tab_"+self.id).remove();
					delete tabAreas[options.id];
				}
				if(self.tabClosed){
					self.tabClosed(currentTab);
				}
				if(self.tabs.length>0) {
					var focusIndex = 0;
					if(index < self.tabs.length){
						focusIndex = index;
					} else {
						focusIndex = self.tabs.length -1;
					}
					self.focus(focusIndex);
				}
				$(document).trigger("tabClosed",[currentTab,self]);
			};
			c();
		},
		beforeClose: function(index,confirmFunciton,e){
			if(confirmFunciton) {
				confirmFunciton(index,this,e);
			} else {
				this.close(index);
			}
		},
		getIndex:function(tabId) {
			var index = -1;
			for (var i = 0; i < this.tabs.length; i++) {
				  if(this.tabs[i].id == tabId){
					  index = i;
					  break;
				  }
			}
			return index;
		},
		getCurrentTab:function(){
			var position = existPropertyIndex(this.tabs,"active");
			return this.tabs[position];
		},
		getAllTabs:function(){
			return this.tabs;
		},
		focus:function(index){
			var position = existPropertyIndex(this.tabs,"active");
			if(position >= 0){	//存在激活的标签
				if(index != position) {
					$.observable(this.tabs[position]).removeProperty("active");
					$.observable(this.tabs[index]).setProperty("active", true);
				}
			} else {	//不存在激活的标签
				$.observable(this.tabs[index]).setProperty("active", true);
			}
			if(this.tabChanged){
				this.tabChanged(this.tabs[index],this.tabs[position]);
			}
			$(document).trigger("tabChanged",[this.tabs[index],this.tabs[position],this]);
		},
		addOrFocus:function(tab) {
			var index = this.getIndex(tab.id);
			if(index == -1){	// 如果不存所指定id的标签页, 则添加
				tab = $.extend({closeable:true},tab);
				$.observable(this.tabs).insert(tab);
				if(tab.template && tab.template.name) {
					$.jsRenderTemplate.render(tab.template.name,"#" + tab.id,tab.template.data);
				}
				dealingOptionProperties(tab);
				this.focus(this.tabs.length -1);
			} else { // 如果存所指定id的标签页, 定位到指定标签
				this.focus(index);
			}
		},
		remove:function(tabId){
			var j = this.getIndex(typeof tabId == "string"?tabId:tabId.id);
			if(j != -1) {
				this.close(j);
			}
		}
	  };
	  
	  var initTabArea = function(dfOpts){
		  options = $.extend({},dfOpts, options);

		  if(existPropertyIndex(options.tabs,"active") == -1 && options.tabs.length>0){
			  options.tabs[0]["active"] = true;
		  }
		  $.jsRenderTemplate.link("plugin.tabTemplate",self,options,options,function(){
			  tabAreas[options.id] = options;
			  dealingOptionProperties(options.tabs);
			  if(options.onload){
				  options.onload();
			  }
		  });
		  return options;
	  };
	  
	  return initTabArea(defualtOptions);
  };
  
  $.tabs = {
	initOrGetBack :function(selector, tabAreaId){
		return $(selector).tablet(tabAreaId);
	},
	get:function(tabAreaName){
		return  tabAreas[tabAreaName];
	}
  };

  $.fn.tablet = function(options){
	  var self = $(this);
	 return  tabFunction(self,options);
  };
})(jQuery);