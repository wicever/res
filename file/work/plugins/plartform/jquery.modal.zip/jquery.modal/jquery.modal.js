/**
 *  =========================== 初始化jsrender模板的内容begin ======================================
 */

/*
 * 弹出框主模板内容，里面的内容为bootstrap的modal基础样式和jsRender插入语法
 */
var modalTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.modal/jquery.modal.html", function(data){
		modalTplhtml = data;
	 });
});
/*
 * 弹出框引入的jsRender模板内容,基础样式和语法。用于比较复杂的弹出框==
 * 
 * 此处对应功能为生成数据表模板
 */
var modalCreateTableTplhtml;
$(function(){  
	$.get(GlobalParam.context +"/resources/plugins/jquery.modal/jquery.modal.createTable.html", function(data){
		modalCreateTableTplhtml = data;
	 });
});

/**
 *  =========================== 初始化jsrender模板的内容end ======================================
 */


/**
 *  =========================== 定义Jquery插件begin ======================================
 */
(function($) {
	/*
	 * 创建弹出框父模板
	 */
	$.createModalTpl =function(id){
//		 alert(modalTplhtml);
		 id = id+"Tpl";
		 var dom = document.body;
		 if($.checkHasCreateModal(id)){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id",id);
			 sc.innerHTML =modalTplhtml;
			 dom.appendChild(sc);
		 }
		 return id;
	 };
	 /*
	 * 创建删除弹出框子模板
	 */
	 $.createDelModalTpl =function(id,content){
		 id = id+"DelTpl";
		 var dom = document.body;
		 if($.checkHasCreateModal(id+"DelTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id",id+"DelTpl");
			 sc.innerHTML =content;
			 dom.appendChild(sc);
		 }
		 return id;
	 };
	 /*
	 * 创建消息提示弹出框子模板
	 */
	 $.createMsgModalTpl =function(id,content){
		 id = id+"MsgTpl";
		 var dom = document.body;
		 if($.checkHasCreateModal(id+"MsgTpl")){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id",id+"MsgTpl");
			 sc.innerHTML =content;
			 dom.appendChild(sc);
		 }
		 return id;
	 };
	 /*
	 * 创建创建数据表提示弹出框子模板
	 */
	 $.createTableModalTpl =function(tplName){
		 var dom = document.body;
		 if($.checkHasCreateModal(tplName)){
			 var sc = document.createElement("script");
			 sc.setAttribute("type","text/x-jsrender");
			 sc.setAttribute("id",tplName);
			 sc.innerHTML =modalCreateTableTplhtml;
			 dom.appendChild(sc);
		 }
		 return tplName;
	 };
	 /**
	  * 验证模板是否已经创建
	  */
	 $.checkHasCreateModal =function(id){
		 
		 var falg =true;
		 $("body").find("script").each(function(){ 
			 if(id==$(this).attr("id")){
				 falg = false;
			 }
		}); 
		return falg;
	 };
	 
	 /**
	  * id 弹出框modal的唯一性字段
	  * type  那种弹出框 1,删除；2,消息；3,复杂弹出框
	  * title 弹出框表头
	  * tplName 引用的模板名称，当type为1、2的时候，此字段可以为空字符串
	  * btn 扩展按钮对象数组 ，格式为 例:[{"name":"按钮1","fun":"btnsFun1"},{"name":"确认","fun":"btnsFun2"}];
	  * 
	  * 调用例子
	  * $.myTip('myModal','1','删除提示','delModalTpl','btn');
	  * $.myTip('myModal','2','删除提示','delModalTpl','btn');
	  * $.rcuTip('myModal','3','弹出框测试','createTableTpl','btn');
	  */
	 $.rcuTip =function(id,type,title,tplName,btn,data){
		 /*
		  * 创建模板
		  */
		 var modalTplId = $.createModalTpl(id);
		 $.createDelModalTpl(id,"确认删除么");
		 $.createMsgModalTpl(id,"提示信息")
		 $.createTableModalTpl(tplName);
		 
		
		 
		 /*
		  * 封装data数据
		  */
		 var tempId =id+"Modal";
	//	 btn =[{"name":"按钮1","fun":"btnsFun1()"},{"name":"确认","fun":"btnsFun2()"}];
		 if(type==1){
			 title="删除提示框";
			 tplName = "#"+id+"DelTpl";
			 btn =	[{"name":"确定","fun":"btnsFun1"}];
		 }else if(type==2){
			 title="信息提示框";
			 tplName = "#"+id+"MsgTpl";
			 btn =	[];
		 }else if(type==3){
			 tplName  ="#"+tplName;
		 }else{
			 tplName = "#"+id+"MsgTpl";
		 }
		 var modalData = {modal:{
			 "id": tempId,
			 "type":type,
			 "tpl": tplName,
			 "btn":btn,
			 "title":title
		 },
		 changeManager: function() {
			 $.observable(this).setProperty({
				 manager: modal
			 });
		 }};
		 var data = {"modalManager":modalData}
		 modalData.manager = modalData.modal;
		 
		 if ($('#'+tempId).length>0) {
			 $('#'+tempId).modal('show');
		 } else {
			 /*
			  * 渲染数据
			  */
			 var template = $.templates("#"+modalTplId);
			 var data = {"modalManager":modalData}
			 var htmlOutput = template.render(modalData);
			 $("body").append(htmlOutput);
			 /*
			  * 弹出框的展示
			  */
			 $('#'+tempId).modal('show');
		 }
	 };
	 
})(jQuery);
/**
 *  =========================== 定义Jquery插件end ======================================
 */



/**
 *  =========================== 公用方法 begin======================================
 */

/*
 * 封装调用方法
 */
function openTip(id,type,title,inserTplId,btn,data){
	$.rcuTip(id,type,title,inserTplId,btn,data);
}

/*
 * 封装关闭方法
 */
function closeTip(tempId){
	$('#'+tempId).modal('hide');
}
/**
 *  =========================== 公用方法 end======================================
 */
