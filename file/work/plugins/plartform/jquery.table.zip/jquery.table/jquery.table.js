/**
 * 使用方法: $("#workArea").table({ rowClick : function(e,row,rowData){}, columns:[ {
 * header:"xx", data:"name", hidden:true }, { ...} ] ,operations:[ { cmd:""
 * ,label:"" ,type:"button/link/icon" } ] ,checked:true // 是否带复选框 ,editable:true //
 * 是否可编辑 ,selectable:"single" //single:表格单选；multi：表格多选 ,indexable:true //是否显示序号
 * ,onload:function(){} });
 * 
 */

jQuery.jsRenderTemplate.register({
	id : "plugin.tableTemplate",
	url : "resources/plugins/jquery.table/jquery.table.html"
});

(function($) {
	"use strict";
	$.fn.table = function(options) {
		var self = $(this);
		options = $.extend({
			columns : [],
			data : [],
			callback : {
				beforeEdit : function($tr, $td) { // 返回true继续执行blur事件，返回false不执行，editable为true是有效。
					return true;
				},
				afterEditorBlur : function($tr, $td, originalValue, value) { // blur事件后调用，editable为true是有效。
					return value;
				}
			}
		}, options);

		var booleanEval = function(expression, dataContext) {
			if (!expression)
				return true;
			//***OA定制***增加当前登录人通配符
			  if(expression.indexOf("{curUser}")!==-1){
				  expression=expression.replace(/{curUser}/g,"'"+pageConfig.currentUserInfo.currentUserAccount+"'"); 
			  }
			  //***OA定制***增加当前登录人通配符---end
			var tmplString = "{{if " + expression + "}}true{{/if}}";
			var tmpl = $.templates(tmplString);
			var html = tmpl.render(dataContext);
			return html == "true";
		};

		var tablePanel = self;
		if (options.link === true) {
			$.jsRenderTemplate.link("plugin.tableTemplate", self, options);
		} else {
			$.jsRenderTemplate.render("plugin.tableTemplate", self, options,
					null, {
						booleanEval : booleanEval
					});
		}
		tablePanel.find("#bodyDiv").height(
				tablePanel.find(".modal-body").height());
		if (options.id) {
			tablePanel = $("#" + options.id);
		}

		if (options.editable === true) {
			var textEditor;
			var getTextEditor = function() {
				if (!textEditor) {
					textEditor = $("<input type='text'>");
				}
				textEditor.blur(function() {
					var self = $(this);
					var value = self.val();
					value = value ? $.trim(value) : "";
					var originalValue = self.data("originalValue");
					var $tr = self.parent().parent();
					var $td = self.parent();
					if ($.isFunction(options.callback.afterEditorBlur)) {
						value = options.callback.afterEditorBlur.call(this,
								$tr, $td, originalValue, value);
					}
					if (originalValue != value) {
						$tr.addClass("edited");
						$td.addClass("sub_edited");
					}
					$td.text(value);
				});
				return textEditor;
			};
			tablePanel.find("tbody").on(
					"dblclick",
					"tr td",
					function(e) {
						var self = $(this);
						// beforeEdit为false不触发双击事件；
						if ($.isFunction(options.callback.beforeEdit)) {
							var continues = options.callback.beforeEdit.call(
									this, self.parent(), self);
							if (!continues) {
								return;
							}
						}
						// 如果当前td内存在input则不触发双击事件；
						if (self.children('input').length > 0) {
							return;
						}
						var colIndex = self.attr("colIndex");
						var columnDef = options.columns[parseInt(colIndex)];
						if (columnDef && columnDef.editable === false) {
							return;
						}
						var textEd = getTextEditor();
						var text = self.text();
						text = text ? $.trim(text) : "";
						var headerRow = tablePanel.find("thead tr");
						if (headerRow.attr("adjusted") == undefined) {
							headerRow.find("th").each(function(ind, ele) {
								var header = $(ele);
								header.css("width", header.outerWidth());
							});
							headerRow.attr("adjusted", "true");
						}
						textEd.width(self.width() - 14);
						self.html(textEd);
						textEd.val(text).focus();
						textEd.data("originalValue", text);
					});
		}

		/**
		 * 绑定tr的单击事件。
		 */
		tablePanel.find("tbody")
				.on(
						"click",
						"tr",
						function(e) {
							var self = $(this);
							if (options.selectable) {
								if (options.selectable == "single") {
									/*
									 * 2.允许单选。
									 */
									if (self.hasClass('active')) {
										self.removeClass("active").find(
												'input.tableCheck').prop(
												'checked', false);
									} else {
										tablePanel.find("tbody tr.active")
												.removeClass("active").find(
														'input.tableCheck')
												.prop('checked', false);
										/*
										 * 设置本行选中样式
										 */
										self.addClass("active").find(
												'input.tableCheck').prop(
												'checked', true);
									}
								} else if (options.selectable == "multi") {
									/*
									 * 3.允许多选。
									 */
									var self = $(this);
									if (self.hasClass('active')) {
										self.removeClass("active").find(
												'input.tableCheck').prop(
												'checked', false);
										tablePanel.find(".tableCheckAll").prop(
												'checked', false);
									} else {
										self.addClass("active").find(
												'input.tableCheck').prop(
												'checked', true);
										// 所有行都选中，那么需要选中全选按钮
										if (tablePanel.find("tbody tr").not(
												'.active').length == 0) {
											tablePanel.find(".tableCheckAll")
													.prop('checked', true);
										}
									}
								}
							}
							/*
							 * 触发行点击回调
							 */
							if (options.rowClick) {
								var rowIndex = self.attr("rowIndex");
								options.rowClick(e, self,
										options.data[rowIndex]);
							}
						});

		/**
		 * 绑定tr的双击事件。
		 */
		tablePanel.find("tbody").on("dblclick", "tr", function(e) {
			if (options.rowDblClick) {
				var rowIndex = $(this).attr("rowIndex");
				options.rowDblClick.call(this, options.data[rowIndex]);
			}
		});

		/**
		 * 绑定全选按钮点击事件： 1、如果选中，找到所有未选中的行触发点击事件； 2、如取消选中，找到所有已选中的行触发点击事件。
		 */
		tablePanel.find(".tableCheckAll").click(function(e) {
			var self = $(this);
			if (self.is(':checked')) {
				tablePanel.find("tbody tr").not('.active').trigger('click');
			} else {
				tablePanel.find("tbody tr.active").trigger('click');
			}
		});

		if (options.pagination) {
			var gotToPageButton = tablePanel.find("#gotoPage");

			gotToPageButton
					.prev()
					.blur(
							function(e) {
								var self = $(this);
								var cIndex = parseInt(self.val());
								if (isNaN(cIndex)
										|| (cIndex < 1 || cIndex > options.totalPages)) {
									self.val(options.pageIndex);
								}
							});

			gotToPageButton
					.click(function() {
						var cIndex = parseInt(gotToPageButton.prev().val());
						if (!(isNaN(cIndex) && (cIndex < 1 || cIndex > options.totalPages))) {
							options.pagination(parseInt(tablePanel.find(
									"#pageSize").val()), cIndex);
						}
					});

			tablePanel.find("#firstPage").click(function() {
				gotToPageButton.prev().val(1);
				gotToPageButton.click();
			});

			tablePanel.find("#lastPage").click(function() {
				gotToPageButton.prev().val(options.totalPages);
				gotToPageButton.click();
			});

			tablePanel.find("#prevPage").click(function() {
				if (options.pageIndex > 1) {
					gotToPageButton.prev().val(options.pageIndex - 1);
					gotToPageButton.click();
				}
			});

			tablePanel.find("#nextPage").click(function() {
				if (options.pageIndex < options.totalPages) {
					gotToPageButton.prev().val(options.pageIndex + 1);
					gotToPageButton.click();
				}
			});

			tablePanel.find("#pageSize").change(function() {
				tablePanel.find("#firstPage").click();
			});

			if (options.pageIndex == 1) {
				tablePanel.find("#firstPage").addClass("disabled");
				tablePanel.find("#prevPage").addClass("disabled");
			}

			if (options.pageIndex == options.totalPages
					|| options.totalPages == 0) {
				tablePanel.find("#lastPage").addClass("disabled");
				tablePanel.find("#nextPage").addClass("disabled");
			}
		}

		if (options.onload) {
			options.onload(tablePanel);
		}
	};

	$.fn.serviceTable = function(service, serviceParamFunction, tableSetting,
			dataObject) {
		var self = $(this);
		var showTable = function() {
			var baseParam = serviceParamFunction();
			var serviceParam = $.isArray(baseParam) ? baseParam : [ baseParam ];
			serviceParam.push({
				callback : function(ret) {
					if (typeof ret == "string") {
						ret = JSON.parse(ret);
					}
					if (dataObject) {
						dataObject['data'] = ret;
					}
					tableSetting.data = ret.data ? ret.data : ret;
					self.table(tableSetting);
				}
			});
			service.apply(null, serviceParam);
		};
		showTable();
	};

	$.fn.pagenationTable = function(service, serviceParamFunction,
			tableSetting, pageSize, pageIndex, orderBy, dataObject) {
		var self = $(this);
		var showPagenationTable = function(pageSize, pageIndex) {
			var baseParam = serviceParamFunction();
			var serviceParam = $.isArray(baseParam) ? baseParam : [ baseParam ];
			serviceParam.push((pageIndex - 1) * pageSize);
			serviceParam.push(pageSize);
			serviceParam.push(orderBy ? orderBy : "");
			serviceParam.push({
				callback : function(ret) {
					if (dataObject) {
						dataObject['data'] = ret;
					}
					var defaultTableOpts = {
						data : ret.data,
						selectable : "single",
						rowClick : function(e, self, rowData) {
						},
						"totalSize" : ret.totalSize,
						"totalPages" : Math.ceil(ret.totalSize / pageSize),
						"pageSize" : pageSize,
						"pageIndex" : pageIndex,
						"pagination" : showPagenationTable,
						checked : true,
						onload : function(tablePanel) {
						}
					};
					var tableOpts = $
							.extend({}, defaultTableOpts, tableSetting);
					self.table(tableOpts);
				}
			});
			service.apply(null, serviceParam);
		};
		showPagenationTable(pageSize, pageIndex);
	};
	$.fn.noPagenationTable = function(service,serviceParamFunction,tableSetting,pageSize,pageIndex,orderBy,dataObject){
	  var self = $(this);
	  var showNoPagenationTable = function(pageSize,pageIndex) {
		  var baseParam = serviceParamFunction();
		  var serviceParam = $.isArray(baseParam)?baseParam:[baseParam];
		  serviceParam.push((pageIndex-1)*pageSize);
		  serviceParam.push(pageSize);
		  serviceParam.push(orderBy?orderBy:"");
		  serviceParam.push({callback : function(ret) {
			  if(dataObject) {
				  dataObject['data'] = ret;
			  }
				var defaultTableOpts = {
						data:ret.data,selectable:"single",rowClick:function(e,self,rowData){},
						checked:true,
						onload:function(tablePanel){}
				};
				var tableOpts = $.extend({},defaultTableOpts,tableSetting);
				self.table(tableOpts); 
		  }});	
		  service.apply(null,serviceParam);
	  };
	  showNoPagenationTable(pageSize,pageIndex);
  };
  $.fn.pagenationGroupTable = function(service,serviceParamFunction,tableSetting,pageSize,pageIndex,orderBy,groupId,dataObject){
	  var self = $(this);
	  var showPagenationTable = function(pageSize,pageIndex) {
		  var baseParam = serviceParamFunction();
		  var serviceParam = $.isArray(baseParam)?baseParam:[baseParam];
		  serviceParam.push((pageIndex-1)*pageSize);
		  serviceParam.push(pageSize);
		  serviceParam.push(orderBy?orderBy:"");
		  serviceParam.push(groupId?groupId:"");
		  serviceParam.push({callback : function(ret) {
			  if(dataObject) {
				  dataObject['data'] = ret;
			  }
				var defaultTableOpts = {
						data:ret.data,selectable:"single",rowClick:function(e,self,rowData){},
						"totalSize":ret.totalSize,"totalPages":Math.ceil(ret.totalSize/pageSize),
						"pageSize":pageSize,"pageIndex":pageIndex,"pagination":showPagenationTable,checked:true,
						onload:function(tablePanel){}
				};
				var tableOpts = $.extend({},defaultTableOpts,tableSetting);
				self.table(tableOpts); 
		  }});	
		  service.apply(null,serviceParam);
	  };
	  showPagenationTable(pageSize,pageIndex);
  };
  $.fn.noPagenationGroupTable = function(service,serviceParamFunction,tableSetting,pageSize,pageIndex,orderBy,groupId,dataObject){
	  var self = $(this);
	  var showNoPagenationTable = function(pageSize,pageIndex) {
		  var baseParam = serviceParamFunction();
		  var serviceParam = $.isArray(baseParam)?baseParam:[baseParam];
		  serviceParam.push((pageIndex-1)*pageSize);
		  serviceParam.push(pageSize);
		  serviceParam.push(orderBy?orderBy:"");
		  serviceParam.push(groupId?groupId:"");
		  serviceParam.push({callback : function(ret) {
			  if(dataObject) {
				  dataObject['data'] = ret;
			  }
				var defaultTableOpts = {
						data:ret.data,selectable:"single",rowClick:function(e,self,rowData){},checked:true,
						onload:function(tablePanel){}
				};
				var tableOpts = $.extend({},defaultTableOpts,tableSetting);
				self.table(tableOpts); 
		  }});	
		  service.apply(null,serviceParam);
	  };
	  showNoPagenationTable(pageSize,pageIndex);
  };
})(jQuery);