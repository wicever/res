;(function($) {
  if ( $.fn.table) {
    $.extend($.fn.table.i18n, {
    	i18nFirstPage : 'Home',
    	i18nPrevPage  : 'Previous',
    	i18nNextPage : 'Next',
    	i18nLastPage : 'Last',
    	i18nTotal : 'Total',
    	i18nPage : 'Page',
    	i18nSize : 'Records',
    	i18nGoto : 'Goto',
    	i18nPerPage : 'Per page',
    	i18nOperation : 'Operation',
    	i18nIndex : 'Serial number'
    });
  }
})(jQuery);
