;(function($) {
  if ( $.fn.table) {
    $.extend($.fn.table.i18n, {
    	i18nFirstPage : '首頁',
    	i18nPrevPage  : '上一頁',
    	i18nNextPage : '下一頁',
    	i18nLastPage : '末頁',
    	i18nTotal : '總共',
    	i18nPage : '頁',
    	i18nSize : '條',
    	i18nGoto : '第',
    	i18nPerPage : '每頁',
    	i18nOperation : '操作',
    	i18nIndex : '序號'
    });
  }
})(jQuery);