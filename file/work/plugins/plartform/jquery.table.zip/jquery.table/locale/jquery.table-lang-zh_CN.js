;(function($) {
  if ( $.fn.table) {
    $.extend($.fn.table.i18n, {
    	i18nFirstPage : '首页',
    	i18nPrevPage  : '上一页',
    	i18nNextPage  : '下一页',
    	i18nLastPage : '末页',
    	i18nTotal : '总共',
    	i18nPage : '页',
    	i18nSize : '条',
    	i18nGoto : '第',
    	i18nPerPage : '每页',
    	i18nOperation : '操作',
    	i18nIndex : '序号'
    });
  }
})(jQuery);
