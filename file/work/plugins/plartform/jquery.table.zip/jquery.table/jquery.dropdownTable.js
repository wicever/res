jQuery.jsRenderTemplate.register({
	id:"plugin.dropdownTable",
	url:"resources/plugins/jquery.table/jquery.dropdownTable.html"
});
/**
 * 比$.dwrTree多添加了两个必填参数: id,生成控件的ID, 其它参数使用方法同$.dwrTree， name: 用于表单值的提交
 */

(function($) {
	"use strict";
	$.fn.dropdownTableAgo = function(options){
		var self = $(this);
		$.jsRenderTemplate.render("plugin.dropdownTable",self,options);
		var dropTable = self.find("#dropDownTree_" + options.id);
		
		modelDesignService.getProfiles({
			callback : function(ret) {
				dropTable.table({
					columns:[{header:"表名",data:"name",hidden:false}],hideTh:true,selectable:"single",
					data:ret,rowClick:function(e,self,rowData){
						$("#dropDownTree_display_value_" + options.id).val(rowData.name);
						$("#dropDownTree_display_id_"+ options.id).val(rowData.id);
						$("#dropTree_" + options.id).removeClass("open");
					}
				}); 
				
			}
		});
	};
	
	$.fn.dropdownTable = function(options){
		var self = $(this);
		$.jsRenderTemplate.render("plugin.dropdownTable",self,options);
		var dropTable = self.find("#dropDownTree_" + options.id);
		
		dropTable.table({
			columns:options.columns,hideTh:true,selectable:"single",
			data:options.data,rowClick:function(e,self,rowData){
				$("#dropDownTree_display_value_" + options.id).val(rowData.name);
				$("#dropDownTree_display_id_"+ options.id).val(rowData.id);
				$("#dropTree_" + options.id).removeClass("open");
			}
		}); 
	};
	
	
	
})(jQuery);



