package com.hd.rcugrc.product.oa.widget.form;

import static com.hd.rcugrc.data.crud.criteria.Comparison.eq;

import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;

import com.hd.rcugrc.bpm.FlowDefinition;
import com.hd.rcugrc.bpm.FlowDefinitionService;
import com.hd.rcugrc.bpm.FlowInstance;
import com.hd.rcugrc.bpm.FlowRuntimeService;
import com.hd.rcugrc.bpm.Operator;
import com.hd.rcugrc.bpm.StepDefinition;
import com.hd.rcugrc.data.crud.criteria.OrderBy;
import com.hd.rcugrc.form.dao.model.impl.ModelFormInfoBean;
import com.hd.rcugrc.page.engine.ControlPropertyValue;
import com.hd.rcugrc.page.engine.CustomControl;
import com.hd.rcugrc.page.widget.form.AbstractFormControl;
import com.hd.rcugrc.product.oa.archive.service.ArchivelaterService;
import com.hd.rcugrc.product.oa.common.service.OaBaseFunctionService;
import com.hd.rcugrc.product.oa.common.util.SpringUtil;
import com.hd.rcugrc.product.oa.common.util.WebQueryOpen;
import com.hd.rcugrc.product.oa.docbusinesstype.dwr.BaseDocBusinessTypeBean;
import com.hd.rcugrc.product.oa.docbusinesstype.entity.DocBusinessTypeEntity;
import com.hd.rcugrc.product.oa.docbusinesstype.service.DocBusinessTypeService;
import com.hd.rcugrc.product.oa.oaAttention.service.ProductAttentionService;
import com.hd.rcugrc.product.oa.oaOpinionSort.service.OaOpinionSortService;
import com.hd.rcugrc.product.oa.oaReceiptManage.service.OaReceiptManageService;
import com.hd.rcugrc.product.oa.oaSignReport.service.OaSignReportManageService;
import com.hd.rcugrc.product.oa.oaevaluationrecord.entity.EvaluationRecordEntity;
import com.hd.rcugrc.product.oa.oaevaluationrecord.service.EvaluationRecordService;
import com.hd.rcugrc.product.oa.oasendtoreadlog.dwr.SendToReadLogBean;
import com.hd.rcugrc.product.oa.oasendtoreadlog.entity.SendToReadLogEntity;
import com.hd.rcugrc.product.oa.oasendtoreadlog.service.SendToReadLogService;
import com.hd.rcugrc.product.oa.relateddoc.dwr.RelatedDocBean;
import com.hd.rcugrc.product.oa.relateddoc.entity.RelatedDocEntity;
import com.hd.rcugrc.product.oa.relateddoc.service.RelatedDocService;
import com.hd.rcugrc.product.oaou.docconfig.service.DocConfigService;
import com.hd.rcugrc.product.oaou.documenttransform.dao.DocSendLogDao;
import com.hd.rcugrc.product.oaou.documenttransform.entity.DocSendLogEntity;
import com.hd.rcugrc.product.oaou.documenttransform.sendlogservice.DocSendLogService;
import com.hd.rcugrc.security.context.AuthenticationHelper;
import com.hd.rcugrc.security.hierarchy.service.HierarchySwitchService;
import com.hd.rcugrc.security.user.Group;
import com.hd.rcugrc.security.user.MutableLevelInfoService;
import com.hd.rcugrc.security.user.MutableUserInfoService;
import com.hd.rcugrc.security.user.Role;
import com.hd.rcugrc.security.user.RoleInfoService;
import com.hd.rcugrc.security.user.User;
import com.hd.rcugrc.security.user.UserInfoService;
import com.hd.rcugrc.security.user.dwr.Level;
import com.hd.rcugrc.tools.dict.service.DictService;
import com.hd.rcugrc.tools.dict.service.DictValue;
import com.hd.rcugrc.web.dwr.ListRange;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class OaFlowFormBasicInfoControl extends AbstractFormControl {

	private FlowRuntimeService workflowService;
	private SendToReadLogService sendToReadLogService;
	private EvaluationRecordService evaluationRecordService;
	private RelatedDocService relatedDocService;
	private ProductAttentionService productAttentionService;
	private DocConfigService docConfigService;
	private RoleInfoService roleInfoService;
	private ArchivelaterService archivelaterService;
	private FlowDefinitionService flowService;
	private DictService dictService;
	private UserInfoService userInfoService;
	private MutableLevelInfoService levelService;
	private DocBusinessTypeService docBusinessTypeService;
	private MutableUserInfoService userService;
	private OaOpinionSortService oaOpinionSortService;
	private DocSendLogService  docSendLogService;
	private DocSendLogDao docSendLogDao;
	private OaReceiptManageService oaReceiptManageService;
	private OaSignReportManageService oaSignReportManageService;
	private OaBaseFunctionService oaBaseFunctionService;
	private HierarchySwitchService hierarchySwitchService;
	
	public DocBusinessTypeService getDocBusinessTypeService() {
		return docBusinessTypeService;
	}

	public void setDocBusinessTypeService(DocBusinessTypeService docBusinessTypeService) {
		this.docBusinessTypeService = docBusinessTypeService;
	}
	
	public MutableLevelInfoService getLevelService() {
		return levelService;
	}

	public void setLevelService(MutableLevelInfoService levelService) {
		this.levelService = levelService;
	}
	
	public FlowRuntimeService getWorkflowService() {
		return workflowService;
	}

	public void setWorkflowService(FlowRuntimeService workflowService) {
		this.workflowService = workflowService;
	}

	public SendToReadLogService getSendToReadLogService() {
		return sendToReadLogService;
	}

	public void setSendToReadLogService(SendToReadLogService sendToReadLogService) {
		this.sendToReadLogService = sendToReadLogService;
	}

	public EvaluationRecordService getEvaluationRecordService() {
		return evaluationRecordService;
	}

	public void setEvaluationRecordService(EvaluationRecordService evaluationRecordService) {
		this.evaluationRecordService = evaluationRecordService;
	}

	public RelatedDocService getRelatedDocService() {
		return relatedDocService;
	}

	public void setRelatedDocService(RelatedDocService relatedDocService) {
		this.relatedDocService = relatedDocService;
	}

	public ProductAttentionService getProductAttentionService() {
		return productAttentionService;
	}

	public void setProductAttentionService(ProductAttentionService productAttentionService) {
		this.productAttentionService = productAttentionService;
	}
	
	public DocConfigService getDocConfigService() {
		return docConfigService;
	}

	public void setDocConfigService(DocConfigService docConfigService) {
		this.docConfigService = docConfigService;
	}
	
	public RoleInfoService getRoleInfoService() {
		return roleInfoService;
	}

	public void setRoleInfoService(RoleInfoService roleInfoService) {
		this.roleInfoService = roleInfoService;
	}
	
	public ArchivelaterService getArchivelaterService() {
		return archivelaterService;
	}

	public void setArchivelaterService(ArchivelaterService archivelaterService) {
		this.archivelaterService = archivelaterService;
	}
	
	public FlowDefinitionService getFlowService() {
		return flowService;
	}

	public void setFlowService(FlowDefinitionService flowService) {
		this.flowService = flowService;
	}

	public DictService getDictService() {
		return dictService;
	}

	public void setDictService(DictService dictService) {
		this.dictService = dictService;
	}
	
	public UserInfoService getUserInfoService() {
		return userInfoService;
	}

	public void setUserInfoService(UserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}

	public MutableUserInfoService getUserService() {
		return userService;
	}
	@Resource
	public void setUserService(MutableUserInfoService userService) {
		this.userService = userService;
	}
	
	public OaOpinionSortService getOaOpinionSortService() {
		return oaOpinionSortService;
	}

	public void setOaOpinionSortService(OaOpinionSortService oaOpinionSortService) {
		this.oaOpinionSortService = oaOpinionSortService;
	}
	
	public DocSendLogService getDocSendLogService() {
		return docSendLogService;
	}
	@Resource
	public void setDocSendLogService(DocSendLogService docSendLogService) {
		this.docSendLogService = docSendLogService;
	}
	
	public DocSendLogDao getDocSendLogDao() {
		return docSendLogDao;
	}
	@Resource
	public void setDocSendLogDao(DocSendLogDao docSendLogDao) {
		this.docSendLogDao = docSendLogDao;
	}
	
	public OaReceiptManageService getOaReceiptManageService() {
		return oaReceiptManageService;
	}
	@Resource
	public void setOaReceiptManageService(OaReceiptManageService oaReceiptManageService) {
		this.oaReceiptManageService = oaReceiptManageService;
	}
	
	public OaSignReportManageService getOaSignReportManageService() {
		return oaSignReportManageService;
	}
	@Resource
	public void setOaSignReportManageService(OaSignReportManageService oaSignReportManageService) {
		this.oaSignReportManageService = oaSignReportManageService;
	}

	public OaBaseFunctionService getOaBaseFunctionService() {
		return oaBaseFunctionService;
	}

	public void setOaBaseFunctionService(OaBaseFunctionService oaBaseFunctionService) {
		this.oaBaseFunctionService = oaBaseFunctionService;
	}

	public HierarchySwitchService getHierarchySwitchService() {
		return hierarchySwitchService;
	}

	public void setHierarchySwitchService(HierarchySwitchService hierarchySwitchService) {
		this.hierarchySwitchService = hierarchySwitchService;
	}

	@Override
	protected void outputWriteableControlHtml(Map<String, Object> context, Map<String, Object> localContext,
			CustomControl control, Map<String, ControlPropertyValue> props, PrintWriter writer) throws Exception {
		//布局页面
		String layoutUrl = (String) getPropValue(props,"layoutUrl","");
		if(!"".equals(layoutUrl)){
			writer.print("<style>");
			writer.print(".form-section{display:none;}\n");
			writer.print("#basic_control{display:none;}");
			writer.print("</style>");
		}
		writer.print("<script>");
		writer.print("var cp_oaBasicInfo = {};\n");
		
		//流程信息
		FlowDefinition flow = (FlowDefinition) context.get("flow");
		String flowId = flow.getId();
		printFlowInfo(flow,writer);
		
		//子流程信息
		long instId = 0;
		FlowInstance inst = (FlowInstance) context.get("inst");
		printSubFlowInfo(flowId,instId,inst,writer);
		
		//环节信息
		StepDefinition step = (StepDefinition) context.get("stepDefinition");
		String stepId = step.getStepId();
		printStepInfo(instId,step,writer);
		
		//环节基本信息
		if(inst!=null){
			instId = inst.getId();
		}
		String stepName = "";
		if(instId==0){
			stepName = "起草";
		}
		if(step!=null){
			stepName = step.getName();
		}else{
			stepName = "结束";
		}
		
		//待阅
		ModelFormInfoBean form = (ModelFormInfoBean) context.get("form");
		String formId = form.getId();
		String beanId = "0";
		Object beanIdTmp = context.get("beanId");
		if(beanIdTmp!=null){
			beanId = beanIdTmp.toString();
		}
		printReadLog(formId,beanId,writer);
		
		//公文评价
		printDocEvaluation(beanId,flowId,writer);
		
		//关联文档
		if(instId != 0){
			printRelatedDoc(instId,flowId,writer);
		}		
		
		//是否关注   
		// 【"model:"】解决个人工作作台【我的关注】中。[关注]按钮问题
		boolean isAttention = productAttentionService.checkIsNotAttention(instId, "model:"+formId);
		writer.print("cp_oaBasicInfo.cp_isAttention = " + isAttention + ";\n");
		
		//文档管理员信息
		String account = AuthenticationHelper.getCurrentUser();
		com.hd.rcugrc.security.user.User user = userInfoService.getUserByAccount(account);
		String deptId = user.getParentId()+"";
		printDocManager(deptId,writer);
		
		//管理员成员信息
		printAdminUser(writer);
		
		//是否可以全权限编辑
		printIsFullAuthEdit(user,writer);
		
		//归档信息
		printArchiveInfo(formId, beanId, account, deptId, flowId, stepId, writer);
		
		//数据字典参数/值
		printPishiArray(writer);
		
		//获取业务类型	
		if(stepName.equals("起草") || stepName.equals("开始") || instId==0){
			printBusinessType(writer,context);
		}
		
		//获取用户信息
		User userByAccount = userInfoService.getUserByAccount(account);
		User[] users = new User[1];
		users[0] = userByAccount;
		JSON json = this.wrapUserObject(users);
		JSONObject user_json = (JSONObject)json;
		writer.print("cp_oaBasicInfo.cp_userByAccount = " + user_json + ";\n");
		
		//获取查询级别
		printQueryLevel(writer);
		
		//获取用户所在公司
		/**修改为所有表单页面上均可使用cp_oaBasicInfo.cp_userDept属性
		   date：2018-10-20
		   author：xhx
		*/
		printUserUnit(writer,account);

		
		pringOaOpinion(writer);
		
		//判断当前用户是否是系统管理员
		writer.print("cp_oaBasicInfo.cp_isUserHasRole = " + AuthenticationHelper.isUserHasRole("ADMINISTRATOR") + ";\n");
		
		String javaBeanId = (String) getPropValue(props,"beanId","");
		if(!"".equals(javaBeanId)){
			WebQueryOpen webQueryOpen = (WebQueryOpen) SpringUtil.getBean(javaBeanId);
			webQueryOpen.outputWriteableControlHtml(context, localContext, control, props, writer);
		}
		//分级授权所属机构
		long cp_belongedOrgId = -1;
		com.hd.rcugrc.security.user.Group group = hierarchySwitchService.findHierarchyGroupIdByUser(account);
		if(group != null){
			cp_belongedOrgId = group.getId();
		}
		writer.print("cp_oaBasicInfo.cp_belongedOrgId = " + cp_belongedOrgId + ";\n");
		
		//获取公文发送人员
		printDocumentSender(writer,context,beanId,instId);
		
		if(!"".equals(layoutUrl)){
			writer.print("$.jsRenderTemplate.register({"+
							"id:\"template.flowform.layout\","+
							"url:\""+layoutUrl+"\""+
						"});\n");
		}
		Object mode = context.get("mode");
		if (mode != null && mode.toString().equals("CREATE")) {
			String uuid = oaBaseFunctionService.getUUID();
			writer.print("$(\"#uuid\").val(\""+uuid+"\");\n");
		}
		writer.print("</script>");
		
	}

	protected JSON wrapUserObject(
			com.hd.rcugrc.security.user.User[] beans) {
		if (beans == null && beans.length == 0) {
			return null;
		}
		JSONArray josnArray = new JSONArray();
		for(User bean : beans){
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("id",bean.getId());
			jsonObject.put("parentId",bean.getParentId());
			jsonObject.put("account",bean.getAccount());
			jsonObject.put("name",bean.getName());
			jsonObject.put("description",bean.getDescription());
			jsonObject.put("email",bean.getEmail());
			jsonObject.put("phone",bean.getPhone());
			jsonObject.put("fax",bean.getFax());
			jsonObject.put("props",bean.getProps());
			jsonObject.put("weight",bean.getWeight());

			// 生成全路径
			com.hd.rcugrc.security.user.Group p = userService
					.getGroupById(bean.getParentId());
			StringBuilder path = new StringBuilder();
			StringBuilder ids = new StringBuilder();
			while (p != null && p.getId() != -1) {
				path.insert(0, p.getName());
				path.insert(0, '/');
				ids.insert(0, Long.toString(p.getId()));
				ids.insert(0, '/');
				p = userService.getGroupById(p.getParentId());
			}
			jsonObject.put("fullpathId", ids.toString());
			jsonObject.put("fullpath", path.toString());
			if(beans.length == 1) {
				return jsonObject;
			}
			josnArray.add(jsonObject);
		}
		return josnArray;
	}
	
	private void printUserUnit(PrintWriter writer, String account) {
		// TODO Auto-generated method stub
		Group sonGroup = AuthenticationHelper.getUserDeptWithLevel(account, "SUB_COMPANY", userInfoService);
		Group group = AuthenticationHelper.getUserDeptWithLevel(account, "COMPANY", userInfoService);
		Group prantGroup = AuthenticationHelper.getUserDeptWithLevel(account, "GROUP", userInfoService);
		if(sonGroup != null){
			JSONObject sonGroup_json = JSONObject.fromObject(sonGroup);
			writer.print("cp_oaBasicInfo.cp_userDept = '" + sonGroup_json + "';\n");
		}else if(group != null && sonGroup == null){
			JSONObject group_json = JSONObject.fromObject(group);
			writer.print("cp_oaBasicInfo.cp_userDept = '" + group_json + "';\n");
		}else if(prantGroup != null && group == null && sonGroup == null ){
			JSONObject prantGroup_json = JSONObject.fromObject(prantGroup);
			writer.print("cp_oaBasicInfo.cp_userDept = '" + prantGroup_json + "';\n");
		}
	}

	/**
	 * 获取流程信息
	 * @param flow
	 * @param writer
	 */
	private void printFlowInfo(FlowDefinition flow, PrintWriter writer){
		String flowName = flow.getName();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String createDate = df.format(flow.getCreationTime().toDate());
		writer.print("cp_oaBasicInfo.cp_flowName = '" + flowName + "';\n");
		writer.print("cp_oaBasicInfo.cp_createDate = '" + createDate + "';\n");

        JSON flowAttrs = JSONObject.fromObject("{}");
        if(flow != null){
            Map<String, String> flowProps = flow.getProps();
            if(flowProps != null){
                flowAttrs = JSONObject.fromObject(flowProps);
            }
        }
        writer.print("cp_oaBasicInfo.cp_flowAttrs = " + flowAttrs.toString() + ";\n");
	}
	
	/**
	 * 获取子流程信息
	 * @param flowId
	 * @param instId
	 * @param inst
	 * @param writer
	 */
	private void printSubFlowInfo(String flowId, long instId, FlowInstance inst, PrintWriter writer){
		boolean isSubFlow = false;
		long parentFlowEntryId = instId;
		String parentFlowId = flowId;
		if (inst!=null && inst.isSubflow()) {
			isSubFlow = true;
			parentFlowEntryId = inst.getParentInfo().getFlowInstanceId();
			FlowInstance parentFlowEntry = workflowService.getFlowInstance(parentFlowEntryId);
			parentFlowId = parentFlowEntry.getFlowId();
		}
		writer.print("cp_oaBasicInfo.cp_isSubFlow = " + isSubFlow + ";\n");
		writer.print("cp_oaBasicInfo.cp_parentFlowEntryId = " + parentFlowEntryId + ";\n");
		writer.print("cp_oaBasicInfo.cp_parentFlowId = '" + parentFlowId + "';\n");
	}
	
	/**
	 * 获取环节信息
	 * @param instId
	 * @param step
	 * @param writer
	 */
	private void printStepInfo(long instId, StepDefinition step, PrintWriter writer){
		String stepName = "";
		if(instId==0){
			stepName = "起草";
		}
		if(step!=null){
			stepName = step.getName();
		}else{
			stepName = "结束";
		}
		writer.print("cp_oaBasicInfo.cp_stepName = '" + stepName + "';\n");
		
		JSON flowNodeAttrs = JSONObject.fromObject("{}");
		if(step != null){
			Map<String, String> stepProps = step.getProps();
			if(stepProps != null){
				flowNodeAttrs = JSONObject.fromObject(stepProps);
			}
		}
		writer.print("cp_oaBasicInfo.cp_flowNodeAttrs = " + flowNodeAttrs.toString() + ";\n");
	}
	
	/**
	 * 获取待阅
	 * @param formId
	 * @param beanId
	 * @param writer
	 */
	private void printReadLog(String formId, String beanId, PrintWriter writer){
		List<SendToReadLogEntity> list = sendToReadLogService.findSendToReadLogsByParam(formId, beanId);
		List<SendToReadLogBean> readBeanList = new ArrayList<SendToReadLogBean>();
		if(list!=null && !list.isEmpty()){
			for (SendToReadLogEntity sendToReadLogEntity : list) {
				SendToReadLogBean bean = new SendToReadLogBean();
				try {
					PropertyUtils.copyProperties(bean,sendToReadLogEntity);
				} catch (Exception e) {
					e.printStackTrace();
				}
				readBeanList.add(bean);
			}
		}
		JSON readLog = JSONArray.fromObject("[]");
		if(!readBeanList.isEmpty()){
			readLog = JSONArray.fromObject(readBeanList);
		}
		writer.print("cp_oaBasicInfo.cp_readLog = " + readLog.toString() + ";\n");
	}
	
	/**
	 * 获取公文评价信息
	 * @param beanId
	 * @param flowId
	 * @param writer
	 */
	private void printDocEvaluation(String beanId, String flowId, PrintWriter writer){
		boolean hasDocEvaluation = false;
		String docEvaluationId = "";
		List<EvaluationRecordEntity> erlist = evaluationRecordService.findEvaluationRecordListByParam(Long.parseLong(beanId), flowId);
		if(erlist!=null && !erlist.isEmpty()){
			hasDocEvaluation = true;
			docEvaluationId = erlist.get(0).getId()+"";
		}
		writer.print("cp_oaBasicInfo.cp_hasDocEvaluation = " + hasDocEvaluation + ";\n");
		writer.print("cp_oaBasicInfo.cp_docEvaluationId = '" + docEvaluationId + "';\n");
	}
	
	/**
	 * 获取关联文档信息
	 * @param instId
	 * @param flowId
	 * @param writer
	 */
	private void printRelatedDoc(long instId, String flowId, PrintWriter writer){
		FlowInstance instance = workflowService.getFlowInstance(instId);
		if(instance.isSubflow()){
			instance = workflowService.getFlowInstance(instance.getParentInfo().getFlowInstanceId());
		}
		List<RelatedDocEntity> rdlist = relatedDocService.findRelatedDocListById(instance.getId(), instance.getFlowId());
		List<RelatedDocBean> relatedBeanList = new ArrayList<RelatedDocBean>();
		
		if(rdlist!=null && !rdlist.isEmpty()){
			for (RelatedDocEntity relatedDocEntity : rdlist) {
				RelatedDocBean bean = new RelatedDocBean();
				try {
					PropertyUtils.copyProperties(bean,relatedDocEntity);
				} catch (Exception e) {
					e.printStackTrace();
				}
				relatedBeanList.add(bean);
			}
		}
		JSON relatedDoc = JSONArray.fromObject("[]");
		if(!relatedBeanList.isEmpty()){
			relatedDoc = JSONArray.fromObject(relatedBeanList);
		}
		writer.print("cp_oaBasicInfo.cp_relatedDoc = " + relatedDoc.toString() + ";\n");
	}
	
	private void whlie(boolean subflow) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * 获取文档管理员
	 * @param deptId
	 * @param writer
	 */
	private void printDocManager(String deptId, PrintWriter writer){
		Operator[] operators = docConfigService.getDocumentManagers(deptId);
		JSON docManager = JSONArray.fromObject("[]");
		if(operators!=null && operators.length>0){
			docManager = JSONArray.fromObject(operators);
		}
		writer.print("cp_oaBasicInfo.cp_docManager = " + docManager.toString() + ";\n");
	}
	
	/**
	 * 获取管理员成员
	 * @param writer
	 */
	private void printAdminUser(PrintWriter writer){
		String roleCode = "ADMINISTRATOR";
		Role role = roleInfoService.getRole(roleCode);
		User[] users = roleInfoService.getAssignedUsers(role);
		JSON adminUsers = JSONArray.fromObject("[]");
		if(users!=null && users.length>0){
			adminUsers = this.wrapUserObject(users);
			//adminUsers = JSONArray.fromObject(users);
		}
		writer.print("cp_oaBasicInfo.cp_adminUsers = " + adminUsers.toString() + ";\n");
	}
	
	/**
	 * 用户是否可以全权限编辑
	 * @param user
	 * @param writer
	 */
	private void printIsFullAuthEdit(com.hd.rcugrc.security.user.User user,PrintWriter writer){
		String isFullAuthEdit = "false";
		Role[] roles = roleInfoService.getAssignedRoles(user);
		for (Role role : roles) {
			if("ADMINISTRATOR".equals(role.getCode()) || "SUB_ADMIN".equals(role.getCode()) || "G-1_USER_GROUP_COMPANY_DOCUMENT".equals(role.getCode())){
				isFullAuthEdit = "true";
				break;
			}
		}
		writer.print("cp_oaBasicInfo.cp_isFullAuthEdit = " + isFullAuthEdit + ";\n");
	}
	
	/**
	 * 获取归档信息
	 * @param formId
	 * @param beanId
	 * @param account
	 * @param deptId
	 * @param flowId
	 * @param stepId
	 * @param writer
	 */
	private void printArchiveInfo(String formId, String beanId, String account, String deptId,
			String flowId, String stepId, PrintWriter writer){
		String strformId = "";
		if(formId.startsWith("model:")){
			strformId = formId;
		}else{
			strformId = "model:"+formId;
		}
		int stateArchivelater = archivelaterService.getStateByBean_id(strformId, Long.parseLong(beanId));
		writer.print("cp_oaBasicInfo.cp_stateArchivelater = " + stateArchivelater + ";\n");
		
		int state;
		if (archivelaterService.getRoleByCurrentAcount(account, deptId)) {
			state = stateArchivelater;
		} else {
			state = 3;// 非管理员、延时归档角色
		}
		writer.print("cp_oaBasicInfo.cp_state = " + state + ";\n");
		
		String isShowAlterArchiveBtn = findExtFlowInfo(flowId,stepId,"isShowAlterArchiveBtn");
		writer.print("cp_oaBasicInfo.cp_isShowAlterArchiveBtn = '" + isShowAlterArchiveBtn + "';\n");
	}
	
	/**
	 * 获取配置的数据字典key/value
	 * @param writer
	 */
	private void printPishiArray(PrintWriter writer){
		DictValue[] dictValues = dictService.getDictValues("oainterface");
		JSON pishiArray = JSONArray.fromObject("[]");
		if(dictValues!=null && dictValues.length>0){
			pishiArray = JSONArray.fromObject(dictValues);
		}
		writer.print("cp_oaBasicInfo.cp_pishiArray = " + pishiArray.toString() + ";\n");
	}
	
	/**
	 * 获取业务类型
	 * @param writer
	 * @param context 
	 */
	private void printBusinessType(PrintWriter writer, Map<String, Object> context){
		SecurityContextHolderAwareRequestWrapper request = (SecurityContextHolderAwareRequestWrapper) context.get("request");
		if(request.getParameter("docType") != null){
			Long docBusinessType_id = (long) Integer.parseInt(request.getParameter("docType")) ;
			DocBusinessTypeEntity docBusinessTypeEntity = docBusinessTypeService.getDocBusinessTypeEntity(docBusinessType_id);
			if(docBusinessTypeEntity != null) {
				String docBusinessType = '"'+docBusinessTypeEntity.toString()+'"';
				writer.print("cp_oaBasicInfo.cp_baseDocBusinessType = " + docBusinessType + ";\n");
			}
		}
	}
	
	/**
	 * 获取查询级别列表
	 * @param writer
	 */
	private void printQueryLevel(PrintWriter writer){
		String type = "U" ;
		com.hd.rcugrc.security.user.Level[] levelList;
		levelList = levelService.findLevel(OrderBy.orderBy(OrderBy.asc("index")), 0, -1,eq("type", type));
		Level[] levelresult = new Level[levelList.length];
		for (int i = 0; i < levelList.length; i++) {
			levelresult[i] = wrap(levelList[i]);
		}
		JSON levelArray = JSONArray.fromObject("[]");
		if(levelresult!=null && levelresult.length>0){
			levelArray = JSONArray.fromObject(levelresult);
		}
		writer.print("cp_oaBasicInfo.cp_levelList = " +  levelArray.toString() + ";\n");
	}
	
	private void pringOaOpinion(PrintWriter writer){
		ListRange lr = oaOpinionSortService.getOpinion();
		Object[] os = lr.getData();
		JSON opinionArray = JSONArray.fromObject("[]");
		if(os!=null && os.length>0){
			opinionArray = JSONArray.fromObject(os);
		}
		writer.print("cp_oaBasicInfo.cp_oaOpinion = " +  opinionArray.toString() + ";\n");
	}

	private String findExtFlowInfo(String flowId, String stepId, String extProp) {
		FlowDefinition flowDefinition = flowService.getFlowDefinition(flowId);
		if(null != flowDefinition){
			StepDefinition stepDefinition = flowDefinition.getStep(stepId);
			if(null != stepDefinition){
				Map<String, String> props = stepDefinition.getProps();
				if(props != null){
					if(props.containsKey(extProp)){
						return "1";
					}
				}
			}
		}
		
		return "";
	}
	
	protected Level wrap(com.hd.rcugrc.security.user.Level level) {
		if (level == null) {
			return null;
		}
		Level l = new Level();
		l.setId(Long.toString(level.getId()));
		l.setTenantId(level.getTenantId());
		l.setType(level.getType());
		l.setCode(level.getCode());
		l.setName(level.getName());
		l.setIndex(level.getIndex());
		return l;
	}
	
	private BaseDocBusinessTypeBean toDocBusinessTypeBean(DocBusinessTypeEntity docBusinessTypeEntity){
		BaseDocBusinessTypeBean baseDocBusinessTypeBean = new BaseDocBusinessTypeBean();
		try {
			PropertyUtils.copyProperties(baseDocBusinessTypeBean,docBusinessTypeEntity);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("toDocBusinessTypeBean error"+e.getMessage());
			
		} 
		return baseDocBusinessTypeBean;
	}
	
	/**
	 *    输出公文发送人员
	 * @param writer
	 */
	private void printDocumentSender(PrintWriter writer, Map<String, Object> context,String beanId,Long instId){
		JSONArray jsonArray = new JSONArray();
		if(!beanId.equals(0) && Long.valueOf(beanId) > 0 && instId > 0) {
			List<DocSendLogEntity> sendLogList = docSendLogDao.findSendDocumentList(Long.valueOf(beanId),instId);	
			if(sendLogList.size() > 0) {
				DocSendLogEntity docSendLogEntity = sendLogList.get(0);
				
				String senderAccount = docSendLogEntity.getCreatorAccount();
				String senderName = docSendLogEntity.getCreatorName();
				
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("senderAccount", senderAccount);
				jsonObject.put("senderName", senderName);
				jsonArray.add(jsonObject);
				
			}
		}
		writer.print("cp_oaBasicInfo.cp_docSender = " +  jsonArray.toString() + ";\n");
	}
	
}
