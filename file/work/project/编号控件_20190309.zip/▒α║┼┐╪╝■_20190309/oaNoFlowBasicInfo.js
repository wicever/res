/*
  OA非流程类页面公用js
  在 产品非流程页面模板（G_1_noFlowPageTemplate/G_1_oaNoFlowPage）中引用
*/
var cp_isNewDoc;
$(document).ready(function() {
  try{

    $.jsRenderTemplate.render("template.noflowform.layout",$(".layout-section"),{}, function(){
      $(".page_content").append($(".container").detach());
      setTimeout(function(){
    	  NoFlowForm.richTextFieldPatch();
      }, 1000);
      $(".form-horizontal").append($(".page-footer").detach());
      $(".form-actions").append($("#option-buttons").detach());
      $(".form-horizontal").show();
      //面包屑处理
      $(".page-crumb").text($(".page-title").text());
      //非流程模板渲染后扩展方法
      if(typeof(noFlowFormRenderTemplateAfterCustom) == "function"){
        noFlowPageRenderTemplateAfterCustom();
      }
    });
  }catch(e){
  }
  
  //是否新文档
  cp_isNewDoc = NoFlowForm.getQueryString(location.href,"id") == "" ? true : false;
  if(cp_isNewDoc){
	  $.ajax({
	      type: 'POST',
	      url: "/rest/BaseFunctionController/getUUID",
	      async:false, //同步执行，执行完后触发页面加载完事件
	      success: function (data) {
	        if(data.uuid){
	        	if($("input[id='ds1$uuid']")[0]){
	        		$("input[id='ds1$uuid']").val(data.uuid);
	        	}else{
	        		alert("当前页面没有创建uuid控件，请检查！")
	        	}
	        }
	      }
	    });
  }
  //页面加载完后触发事件
  $(document).trigger("oa.page.load.ready");
  //退出按钮
  $('#close').on('click', function() {
	  NoFlowForm.closeWindow();
  });

  window['_submitPageflowForm'] = submitPageflowForm;
  window['submitPageflowForm'] = ajaxSubmitPageflowForm; // 修改使用ajax提交代码

  //提交成功后触发本事件，绑定事件提示保存成功，点击确定关闭按钮
  $(document).bind("after.workflow.ajaxSubmitPageflowForm", function(event,scope,result) {
	//非流程模板保存后扩展方法
	if(typeof(noFlowFormSaveAfterCustom) == "function"){
		noFlowFormSaveAfterCustom(event,scope,result);
	}
		
    $.seniorDialog({
      title : "提示",
      buttons:[{label:"确定",clazz:"", click:function(){
    	  NoFlowForm.closeWindow();
        }},"cancel"],
      onload:function(dom){
        dom.find(".modal-body").append('保存成功。');
      }
    }, 5000);
  })
  
});

var NoFlowForm = {
	  createNew : function(){
	  	var noFlowForm = {};
	  	return noFlowForm;
	  },
	  
	  //非流程表单点击保存后执行的公共方法
  	  updateFormDataOnSave : function(){
  		var now = NoFlowForm.format(new Date(),"yyyy-MM-dd hh:mm:ss");
  		if(cp_isNewDoc){
  			if($("input[id='ds1$creationTime']")[0]){
  				if($("input[id='ds1$creationTime']").val()==""){
  					$("input[id='ds1$creationTime']").val(now);
  				}
  			}
  			if($("input[id='ds1$lastModifiedTime']")[0]){
  				if($("input[id='ds1$lastModifiedTime']").val()==""){
  					$("input[id='ds1$lastModifiedTime']").val(now);
  				}
  			}
  			if($("input[id='ds1$deleted']")[0]){
  				if($("input[id='ds1$deleted']").val()==""){
  					$("input[id='ds1$deleted']").val(0);
  				}
  			}
  			if($("input[id='ds1$creatorAccount']")[0]){
  				if($("input[id='ds1$creatorAccount']").val()==""){
  					$("input[id='ds1$creatorAccount']").val(pageConfig.currentUserInfo.currentUserAccount);
  				}
  			}
  			if($("input[id='ds1$creatorName']")[0]){
  				if($("input[id='ds1$creatorName']").val()==""){
  					$("input[id='ds1$creatorName']").val(pageConfig.currentUserInfo.currentUserName);
  				}
  			}
  			if($("input[id='ds1$createDeptId']")[0]){
  				if($("input[id='ds1$createDeptId']").val()==""){
  					$("input[id='ds1$createDeptId']").val(pageConfig.currentUserInfo.currentUserDeptId);
  				}
  			}
  			if($("input[id='ds1$createDeptName']")[0]){
  				if($("input[id='ds1$createDeptName']").val()==""){
  					$("input[id='ds1$createDeptName']").val(pageConfig.currentUserInfo.currentUserDeptName);
  				}
  			}
  			if($("input[id='ds1$modifyEmpAccount']")[0]){
  				if($("input[id='ds1$modifyEmpAccount']").val()==""){
  					$("input[id='ds1$modifyEmpAccount']").val(pageConfig.currentUserInfo.currentUserAccount);
  				}
  			}
  			if($("input[id='ds1$modifyEmpName']")[0]){
  				if($("input[id='ds1$modifyEmpName']").val()==""){
  					$("input[id='ds1$modifyEmpName']").val(pageConfig.currentUserInfo.currentUserName);
  				}
  			}
  			if($("input[id='ds1$modifyDeptId']")[0]){
  				if($("input[id='ds1$modifyDeptId']").val()==""){
  					$("input[id='ds1$modifyDeptId']").val(pageConfig.currentUserInfo.currentUserDeptId);
  				}
  			}
  			if($("input[id='ds1$modifyDeptName']")[0]){
  				if($("input[id='ds1$modifyDeptName']").val()==""){
  					$("input[id='ds1$modifyDeptName']").val(pageConfig.currentUserInfo.currentUserDeptName);
  				}
  			}
  			if($("input[id='ds1$belongedOrgId']")[0]){
  				$("input[id='ds1$belongedOrgId']").val(cp_belongedOrgId);
  			}
  			if($("input[id='ds1$endType']")[0]){
  				$("input[id='ds1$endType']").val(0);
  			}
  		}else{
  			if($("input[id='ds1$lastModifiedTime']")[0]){
  				$("input[id='ds1$lastModifiedTime']").val(now);
  			}
  			if($("input[id='ds1$modifyEmpAccount']")[0]){
  				$("input[id='ds1$modifyEmpAccount']").val(pageConfig.currentUserInfo.currentUserAccount);
  			}
  			if($("input[id='ds1$modifyEmpName']")[0]){
  				$("input[id='ds1$modifyEmpName']").val(pageConfig.currentUserInfo.currentUserName);
  			}
  			if($("input[id='ds1$modifyDeptId']")[0]){
  				$("input[id='ds1$modifyDeptId']").val(pageConfig.currentUserInfo.currentUserDeptId);
  			}
  			if($("input[id='ds1$modifyDeptName']")[0]){
  				$("input[id='ds1$modifyDeptName']").val(pageConfig.currentUserInfo.currentUserDeptName);
  			}
  		}
  	  },
	  
	  /**
	   * 获取url参数值
	   * url：链接地址
	   * paras：参数名称
	   */
	  getQueryString : function(url,paras){
	    var paraString = url.substring(url.indexOf("?") + 1, url.length).split("&");
	    var paraObj = {}
	    for (i = 0; j = paraString[i]; i++) {
	      paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=") + 1, j.length);
	    }
	    var returnValue = paraObj[paras.toLowerCase()];
	    if (typeof (returnValue) == "undefined") {
	      return "";
	    } else {
	      return returnValue;
	    }
	  },
	  
	  closeWindow : function (){
		//非流程模板关闭窗口扩展方法
		if(typeof(noFlowFormCloseCustom) == "function"){
			noFlowFormCloseCustom();
			return false;
		}
			
	    if(window.top==window){ //新窗口打开时直接关闭窗口
	      window.opener.location = window.opener.location;
	      window.location.href = "about:blank";
	      window.close();
	    }
	  },
	  
	  /**
	   *对Date的扩展，将 Date 转化为指定格式的String
	   *月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
	   *年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
	   *例子：
	   *(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
	   *(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
	   */
	  format : function (date,fmt) {
	    var o = {
	      "M+": date.getMonth() + 1, //月份
	      "d+": date.getDate(), //日
	      "h+": date.getHours(), //小时
	      "m+": date.getMinutes(), //分
	      "s+": date.getSeconds(), //秒
	      "q+": Math.floor((date.getMonth() + 3) / 3), //季度
	      "S": date.getMilliseconds() //毫秒
	    };
	    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
	    for (var k in o)
	      if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
	    return fmt;
	  },
	  
	  //富文本控件补丁
	  richTextFieldPatch : function(){
	      $(".rs_ed_editor_iframe").each(function(i){
	    	  var head = $(this).contents().find('head');
	    	  var body = $(this).contents().find('body');
	    	  head.html('<link type="text/css" rel="stylesheet" href="/resources/lib/hd/widget/css/editor.css">');
	    	  body.attr("class","rs_ed_scroll");
	      })
	  }
}