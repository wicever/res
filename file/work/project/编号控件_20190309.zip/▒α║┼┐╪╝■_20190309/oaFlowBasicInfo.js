/*
  OA流程类页面公用js
  在 产品流程页面模板（G_1_flowPageTemplate/G_1_oaFlowPage）中引用
*/

/**
 * 流程审批页面JS
 */
//OA选人
document.write('<script src="/resources/plugins/jquery.seniorSelector.user/jquery.seniorSelector.oaUser.js"></script>');
document.write('<script src="/resources/plugins/jquery.seniorSelector.user/jquery.seniorSelector.oaExternalUser.js"></script>');
//对话框组件
document.write('<link rel="stylesheet" type="text/css" href="/resources/oa/common/css/productDialog.css">');
document.write('<script src="/resources/oa/common/js/productDialog.js"></script>');
//归档
document.write('<script src="/dwr/interface/dwrArchiveService.js"></script>');
//扩展
document.write('<script src="/resources/oa/custom/js/oaDocManager_custom.js"></script>');
document.write('<script src="/dwr/interface/tenantService.js"></script>');
document.write('<script src="/dwr/interface/dwrOaDocNumberProjectService.js"></script>');
document.write('<script src="/dwr/interface/dwrHierarchySwitchService.js"></script>');
document.write('<script src="/dwr/interface/dwrHdOaDispatchServiceP.js"></script>');
var interfereStepHtml = getInterfereStepDialog();
document.write(interfereStepHtml);
//手写批示相关
document.write('<script src="/resources/oa/common/js/sxps/oaSxpsInit.js"></script>');
//打印模式
if(location.href.indexOf("mode=print")!=-1){
  document.write('<link rel="stylesheet" type="text/css" href="/resources/oa/common/css/print.css">');
}
//全权限编辑模式
var isFullAuthEdit = location.href.indexOf("fullAuthEdit.htm") != -1 ? true : false;
var dataWhenLoad = {};
if(isFullAuthEdit){
  document.write('<link rel="stylesheet" type="text/css" href="/resources/oa/common/css/fullauthedit.css">');
}
//记录MAC地址
/*if(location.href.indexOf("create.htm")!=-1 || location.href.indexOf("edit.htm")!=-1){
	document.write('<iframe id="ifrGetRemoteMacAddr" name="ifrGetRemoteMacAddr" src="/user/product/oa/common/jsp/getRemoteMacAddr.jsp" style="display: none;"></iframe>');
}*/
//定义文书管理员
var WdRoles = "" ;
//定义系统管理员
var secRole = "" ;
//定义当前用户
var local_user = "" ;

var grcFlowForm;
var FlowForm = {
  createNew : function(){
    var flowForm = {};

    if(!cp_oaBasicInfo){
      alert("当前页面缺少OA流程页面基础信息控件，请在页面设计器添加！")
    }
    flowForm.flowName = cp_oaBasicInfo.cp_flowName;
    flowForm.createDate = null;
    flowForm.createDateStr = cp_oaBasicInfo.cp_createDate;
    $("#framework_flow").text(flowForm.flowName);
    $("#framework_time").text(flowForm.createDateStr);

    flowForm.stepName = cp_oaBasicInfo.cp_stepName;
    //审批环节
    $("#framework_node").text(flowForm.stepName);
    //修改编号字段只读
    if($("#oanumber").length >0){
      $("#oanumber").attr("readonly",true);
    }
    if($("#fullNumber").length > 0){
      $("#fullNumber").attr("readonly",true);
    }
    flowForm.fileTitle = "";
    if(pageConfig.controls){
      for(var key in pageConfig.controls){
        if(pageConfig.controls[key].type=="title"){
          var id = pageConfig.controls[key].id;
          if($("#"+id)[0]){
            flowForm.fileTitle = $("#"+id).val();
          }
          break;
        }
      }
    }
    //流程
    $("#framework_title").text(flowForm.fileTitle);
    flowForm.attachId = "";
    if(pageConfig.controls){
      for(var key in pageConfig.controls){
        if(pageConfig.controls[key].type=="doc"){
          flowForm.attachId = pageConfig.controls[key].id;
          break;
        }
      }
    }
    if(flowForm.attachId != ""){
      if(!$("#"+flowForm.attachId)[0]){
        alert("您的页面没有创建id为"+flowForm.attachId+"的Word文档控件V5，请检查！");
      }
    }

    //子流程判断
    flowForm.isSubFlow = false;
    if(cp_oaBasicInfo.cp_isSubFlow){
      flowForm.isSubFlow = true;
    }
    flowForm.parentFlowEntryId = cp_oaBasicInfo.cp_parentFlowEntryId;
    flowForm.parentFlowId = cp_oaBasicInfo.cp_parentFlowId;
    //获取流程附加属性
    flowForm.flowNodeAttrs = new Map();
    var flowNodeAttrsTmp = cp_oaBasicInfo.cp_flowNodeAttrs;
    for(var key in flowNodeAttrsTmp){
      flowForm.flowNodeAttrs.put(key,flowNodeAttrsTmp[key]);
    }
    //是否可以添加关联文档
    flowForm.addRelatedDoc = false;
    if(flowForm.flowNodeAttrs.contain("addRelatedDoc") && flowForm.flowNodeAttrs.get("addRelatedDoc")=="true"){
      flowForm.addRelatedDoc = true;
    }
    //获取阅知日志
    flowForm.readLogController = false;	//流程页面阅知日志开关
    flowForm.hasReadLog = false;
    if(flowForm.readLogController){
      var readLogTmp = cp_oaBasicInfo.cp_readLog;
      if(readLogTmp && readLogTmp.length > 0){
        $("#saveActionId").after(renderReadLog(readLogTmp));
        flowForm.hasReadLog = true;
      }
    }

    //获取公文评价信息
    flowForm.hasDocEvaluation = false;
    if(cp_oaBasicInfo.cp_hasDocEvaluation){
      flowForm.hasDocEvaluation = true;
    }
    flowForm.docEvaluationId = cp_oaBasicInfo.cp_docEvaluationId;

    //获取Mac地址绑定配置
    /*flowForm.macAddress = "";
    var queryConditions = {
        "deleted":0,
        "leader_id":pageConfig.currentUserInfo.currentUserAccount
    }
    dwrBaseFunctionService.commonQuery("oa_mac_config",JSON.stringify(queryConditions),
      { callback: function(data){
        if(data && data.length > 0){
          flowForm.macAddress = data[0].mac_address;
        }
      }
    });*/

    //业务办理页签单击事件
    flowForm.businessProcess = function(){
      //发文定制
      if(grcFlowForm.flowNodeAttrs.data.taoda == "true" && $("#framework_node").text() != "开始"){
        var dateValue = $("#dispatch_date").val();

//				var year = dateValue.substring(0,4);
//              	var month = dateValue.substring(4,6);
//              	var day = dateValue.substring(6,8);
//				$("#dispatch_date_view span").text(year+"年"+month+"月"+day+"日");
        //$("#dispatch_date_view span").text(dateValue);
      }
      $("#framework-content").show();
      $("#mainBodyFrame").hide();
      $("#workFlowMonitor").hide();
      //华电办文说明
      $("#mainBwsmF").hide();
    }

    //正文页签点击事件
    flowForm.mainBody = function(){
      //华电办文说明
      $("#mainBwsmF").hide();
      //hasRedTitle=true，有红头模板
      if(flowForm.attachId && pageConfig.controls[grcFlowForm.attachId].attrs["hasRedTitle"]){
        if($("#"+flowForm.attachId).val() == "" || $("#"+flowForm.attachId).val() == "[]"){
          if($("#instId").val() == "0" || $("#instId").val() == undefined || $("#instId").val() == null || $("#instId").val() == ""){
            if(pageForm.getFieldValue("doc_title") == ""){
              alert("标题为空，请先填写标题");
              $("#business-area").css("display","block");
              grcFlowForm.businessProcess();
            }else{
              javascript:dwr.engine.setAsync(false);
              controlMenu.doSave(true, function(cbscope, retdata){
                // 流程表单 保存 后的回调方法
                $(document).trigger("after.workflow.doSave", [cbscope, retdata]);
              });
              javascript:dwr.engine.setAsync(true);

              flowForm.openRedheadChoose();
              //	alert("文档未保存，请保存文档再选择红头");
              //	return;
            }
          }else{
            flowForm.openRedheadChoose();
          }
        }else{
          showAndHidePageContent(flowForm.attachId);
        }
      }else{
        showAndHidePageContent(flowForm.attachId);
      }
    }

    flowForm.openRedheadChoose = function(){
      dwrRedheadConfigService.getRedheadConfig(
          $("#docType").val()||$("#doc_type").val()||"",
          pageConfig.currentUserInfo.currentUserDeptId,
          pageConfig.currentUserInfo.currentUserAccount,
          {
            callback : function(data) {
              var redInfo = data.redInfo;
              var Id;
              var title;
              var htmb;
              var weight;
              var selectStyle = '<table id="" class="table_border table-condensed">';
              selectStyle = selectStyle + '<tbody>';
              for(var i=0;i<redInfo.length;i++){
                Id = redInfo[i].id;
                title = redInfo[i].title;
                htmb = redInfo[i].htmb;
                weight = redInfo[i].weight;
                var row = '<tr><td class="" onclick="chooseChange(this)" style="cursor:pointer" value="'+htmb+'">'+title+'</td></tr>';
                selectStyle = selectStyle + row;
              }
              selectStyle = selectStyle+'</tbody></table>'

              //$(".modal-body").html(selectStyle);
              $.seniorDialog({
                title:"红头模板选择",
                size:"sm",// lg: 大框，sm: 小框, '':默认为中等
                height:250,		// 弹现框高度
                buttons:[		//弹出框按钮
                  {label:"确定",clazz:"btn-primary", click:function(modalDialog,evt){redOkClick(modalDialog)}},	// 按钮定义，label:按钮文本;	clazz:按钮样式;	click: 按钮单击事件, autoClose: 是否自动关闭
                  "cancel"	//组件内嵌的按钮:取消
                ],
                onload:function(dialog){
                  dialog.find(".modal-body").append(selectStyle);
                  $("select#status").change(function(){
                    changeFiledStyle($(this).val());
                  });
                }
              });
              for(var i = 0 ; i <$(".modal-body").find("tr").length ; i ++ ){
                if($(".modal-body").find("tr:eq("+i+")").text() == "办文说明"){
                  $(".modal-body").find("tr:eq("+i+")").css("display","none");
                }
              }
            }
          });
    }

    //流程跟踪页签单击事件
    flowForm.flowTrace = function(){
      if($("#workFlowMonitor").attr("src") == undefined || $("#workFlowMonitor").attr("src") == null || $("#workFlowMonitor").attr("src")==""){
        var flowId = $("#flowId").val();
        if(flowId==null){
          var paraArr = location.search.substring(1).split('&');
          for(var i = 0;i < paraArr.length;i++){
            if("flowId" == paraArr[i].split('=')[0]){
              flowId = paraArr[i].split('=')[1];
            }
          }
        }
        var entryId = $("#instId").val();
        var formId = $("#formId").val();
        var beanId = $("#beanId").val();
        var key = new Date().getTime();
        if(flowForm.isSubFlow){
          $("#workFlowMonitor").attr("src",contextPath+"/bpm/logs4.htm?instId="+entryId+"&flowId="+flowId+"&formId="+formId+"&beanId="+beanId+"&rkey="+key);
        }else{
          $("#workFlowMonitor").attr("src",contextPath+"/bpm/logs2.htm?instId="+entryId+"&flowId="+flowId+"&formId="+formId+"&beanId="+beanId+"&rkey="+key);
        }
      }

      $("#framework-content").hide();
      //流程跟踪页签再次点击显示
      $("#workFlow").css("display","block");

      $("#workFlowMonitor").show();
      $("#mainBodyFrame").hide();
      //华电办文说明
      $("#mainBwsmF").hide();
      //全权限编辑日志
      if($("#workFlowMonitor")[0] && $("#workFlowMonitor")[0].contentWindow.grcFlowTrace){
        $("#workFlowMonitor")[0].contentWindow.grcFlowTrace.showFullAuthEditLog();
      }
    }

    //关注
    if($("#instId").val()!="0"){
      if(!cp_oaBasicInfo.cp_isAttention){
        $('#control2_view').append('<button type="button" class="btn btn-default" id="myAttention" onclick="attentionFlowForm();">关注</button>');
      }else{
        $('#control2_view').append('<button type="button" class="btn btn-default" id="myAttentionCancel" onclick="cancelAttentionFlowForm();">取消关注</button>');
      }

    }

    //选择常用意见
    flowForm.selectOpinion = function(element){
      var sOpinion = $(element).text();
      var opinionField = $(".processform-approvelOpinion textarea");
      if(opinionField[0]){
        var curOpinion = opinionField.val();
        opinionField.val(curOpinion+sOpinion);
        saveAllOpinion(opinionField[0]);
      }
    }

    //加载暂存意见
    flowForm.loadSavedOpinion = function(){
      var opinionField = $(".processform-approvelOpinion textarea");
      if(opinionField[0]){
        if(opinionField.size()>1 && !isFullAuthEdit){
          alert("当前环节存在多个意见签署框，请检查！")
          return;
        }
        var fieldId = opinionField[0].id.split("$")[0];
        var opinionType = 4;
        var entryId = parseInt($("#instId").val());
        var stepSerialNumber = parseInt($("#stepSN").val());
        var formId = $("#formId").val();
        var beanId = $("#beanId").val();
        dwrBaseFunctionService.getExtOpinionByFlowAndStep(beanId,entryId,stepSerialNumber,formId,fieldId,opinionType,{
          callback :function(data){
            if(data){
              opinionField.val(data);
              saveAllOpinion(opinionField[0]);
            }
          }
        });
      }
    }

    flowForm.initDataWhenLoad = function(){
      var tmpData = controlMenu.form.serializeArray()
      for(var i = 0;i < tmpData.length;i ++){
        dataWhenLoad[tmpData[i].name]=tmpData[i].value;
      }
      //setTimeout(function(){
      if(typeof(slCtl) != "undefined" && $("#indidocgroupid")[0]){
        var list = slCtl.Content.Files.FileList;
        var fileNames = [];
        for(var i = 0;i < list.length;i ++){
          fileNames.push(list[i].FileName);
        }
        dataWhenLoad["indidoc"] = fileNames.join(",");
      }
      //}, 5000);
      $("select").each(function(){//下拉框
        if(this.id){
          if(this.id=="queryLevel"){
            return true;
          }
          dataWhenLoad[this.id+"_selecttext"] = $("#"+this.id+" option:selected").text();
        }
      })
      var radioNames = [];//单选钮
      $("input[type='radio']").each(function(){
        if($.inArray(this.name,radioNames)==-1){
          radioNames.push(this.name);
        }
      })
      for(var i = 0;i < radioNames.length;i ++){
        var checkedRadio = $("input[name='"+radioNames[i]+"']:checked");
        var val = "";
        if(checkedRadio[0]){
          val = checkedRadio.parent().text()
        }
        dataWhenLoad[radioNames[i]+"_selecttext"] = val;
      }
      var checkboxNames = [];//复选框
      $("input[type='checkbox']").each(function(){
        if($.inArray(this.name,checkboxNames)==-1){
          checkboxNames.push(this.name);
        }
      })
      for(var i = 0;i < checkboxNames.length;i ++){
        var checkedBox = $("input[name='"+checkboxNames[i]+"']:checked");
        var val = "";
        if(checkedBox[0]){
          checkedBox.each(function(){
            val += "," + $(this).parent().text();
          })
        }
        if(val!=""){val = val.substr(1);}
        dataWhenLoad[checkboxNames[i]+"_multiselecttext"] = val;
      }
    }

    flowForm.updateFormData = function(data,option){
      var creationTimeIndex = -1;
      var lastModifiedTimeIndex = -1;
      var deletedIndex = -1;
      var creatorAccountIndex = -1;
      var creatorNameIndex = -1;
      var createDeptIdIndex = -1;
      var createDeptNameIndex = -1;
      var modifyEmpAccountIndex = -1;
      var modifyEmpNameIndex = -1;
      var modifyDeptIdIndex = -1;
      var modifyDeptNameIndex = -1;
      var belongedOrgIdIndex = -1;
      var endTypeIndex = -1;
      var flowStateIndex = -1;
      for(var i = 0;i < data.length;i ++){
    	if(data[i].name == "creationTime"){
    		creationTimeIndex = i;
        }
        if(data[i].name == "lastModifiedTime"){
          lastModifiedTimeIndex = i;
        }
        if(data[i].name == "deleted"){
          deletedIndex = i;
        }
        if(data[i].name == "creatorAccount"){
          creatorAccountIndex = i;
        }
        if(data[i].name == "creatorName"){
          creatorNameIndex = i;
        }
        if(data[i].name == "createDeptId"){
          createDeptIdIndex = i;
        }
        if(data[i].name == "createDeptName"){
          createDeptNameIndex = i;
        }
        if(data[i].name == "modifyEmpAccount"){
          modifyEmpAccountIndex = i;
        }
        if(data[i].name == "modifyEmpName"){
          modifyEmpNameIndex = i;
        }
        if(data[i].name == "modifyDeptId"){
          modifyDeptIdIndex = i;
        }
        if(data[i].name == "modifyDeptName"){
          modifyDeptNameIndex = i;
        }
        if(data[i].name == "belongedOrgId"){
          belongedOrgIdIndex = i;
        }
        if(data[i].name == "endType"){
          endTypeIndex = i;
        }
        if(data[i].name == "flowState"){
          flowStateIndex = i;
        }
      }
      var now = FlowForm.format(new Date(),"yyyy-MM-dd hh:mm:ss");
      if(lastModifiedTimeIndex != -1){
        data[lastModifiedTimeIndex].value = now;
      }else{
        data.push({name: 'lastModifiedTime', value: now});
      }
      if(creationTimeIndex != -1){
    	if(data[creationTimeIndex].value == ""){
    		data[creationTimeIndex].value = now;
    	}
      }else{
        data.push({name: 'creationTime', value: now});
      }
      if(deletedIndex != -1){
        if(data[deletedIndex].value == ""){
          data[deletedIndex].value = 0;
        }
      }else{
        data.push({name: 'deleted', value: 0});
      }
      var account = pageConfig.currentUserInfo.currentUserAccount;
      if(creatorAccountIndex != -1){
        if(data[creatorAccountIndex].value == ""){
          data[creatorAccountIndex].value = account;
        }
      }else{
        data.push({name: 'creatorAccount', value: account});
      }
      var userName = pageConfig.currentUserInfo.currentUserName;
      if(creatorNameIndex != -1){
        if(data[creatorNameIndex].value == ""){
          data[creatorNameIndex].value = userName;
        }
      }else{
        data.push({name: 'creatorName', value: userName});
      }
      var deptId = pageConfig.currentUserInfo.currentUserDeptId;
      if(createDeptIdIndex != -1){
        if(data[createDeptIdIndex].value == ""){
          data[createDeptIdIndex].value = deptId;
        }
      }else{
        data.push({name: 'createDeptId', value: deptId});
      }
      var deptName = pageConfig.currentUserInfo.currentUserDeptName;
      if(createDeptNameIndex != -1){
        if(data[createDeptNameIndex].value == ""){
          data[createDeptNameIndex].value = deptName;
        }
      }else{
        data.push({name: 'createDeptName', value: deptName});
      }
      var meAccount = pageConfig.currentUserInfo.currentUserAccount;
      if(modifyEmpAccountIndex != -1){
        if(data[modifyEmpAccountIndex].value == ""){
          data[modifyEmpAccountIndex].value = meAccount;
        }
      }else{
        data.push({name: 'modifyEmpAccount', value: meAccount});
      }
      var meUserName = pageConfig.currentUserInfo.currentUserName;
      if(modifyEmpNameIndex != -1){
        if(data[modifyEmpNameIndex].value == ""){
          data[modifyEmpNameIndex].value = meUserName;
        }
      }else{
        data.push({name: 'modifyEmpName', value: meUserName});
      }
      var modifyDeptId = pageConfig.currentUserInfo.currentUserDeptId;
      if(modifyDeptIdIndex != -1){
        if(data[modifyDeptIdIndex].value == ""){
          data[modifyDeptIdIndex].value = modifyDeptId;
        }
      }else{
        data.push({name: 'modifyDeptId', value: modifyDeptId});
      }
      var modifyDeptName = pageConfig.currentUserInfo.currentUserDeptName;
      if(modifyDeptNameIndex != -1){
        if(data[modifyDeptNameIndex].value == ""){
          data[modifyDeptNameIndex].value = modifyDeptName;
        }
      }else{
        data.push({name: 'modifyDeptName', value: modifyDeptName});
      }
      if(belongedOrgIdIndex != -1){
        if(data[belongedOrgIdIndex].value == ""){
          data[belongedOrgIdIndex].value = cp_oaBasicInfo.cp_belongedOrgId;
        }
      }else{
        data.push({name: 'belongedOrgId', value: cp_oaBasicInfo.cp_belongedOrgId});
      }
      var endType = 0;
      if(option=="submit" && $(".workflowsubmit_content").find(".workflowsubmit_row_checked").text().indexOf("结束") > -1){
        endType = 1;
      }
      if(endTypeIndex != -1){
        data[endTypeIndex].value = endType;
      }else{
        data.push({name: 'endType', value: endType});
      }
      if(!grcFlowForm.isSubFlow){
    	var flowState = grcFlowForm.stepName;
    	if(option=="submit"){
    		flowState = $(".workflowsubmit_row_checked .workflowsubmit_content_zxr_destStepName").text();
    	}
        if(flowStateIndex != -1){
          data[flowStateIndex].value = flowState;
        }else{
          data.push({name: 'flowState', value: flowState});
        }
      }
    }

    var formatCreateDate = function(date){
      var tDate = new Date();
      var todayStr = FlowForm.format(tDate,"yyyy-MM-dd");
      tDate.setDate(tDate.getDate()-1);
      var yesterdayStr = FlowForm.format(tDate,"yyyy-MM-dd");
      tDate.setDate(tDate.getDate()-1);
      var dbYesterdayStr = FlowForm.format(tDate,"yyyy-MM-dd");

      var dateStr = FlowForm.format(date,"yyyy-MM-dd");
      switch(dateStr)
      {
        case todayStr:
          return "今天";
        case yesterdayStr:
          return "昨天";
        case dbYesterdayStr:
          return "前天";
        default:
          var startTime = date.getTime();
          var endTime = new Date().getTime();
          var dates = Math.abs((startTime - endTime))/(1000*60*60*24);
          return Math.ceil(dates)+"天前";
      }
    }

    return flowForm;
  },

  /**
   * 获取url参数值
   * url：链接地址
   * paras：参数名称
   */
  getQueryString : function(url,paras){
    var paraString = url.substring(url.indexOf("?") + 1, url.length).split("&");
    var paraObj = {}
    for (i = 0; j = paraString[i]; i++) {
      paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=") + 1, j.length);
    }
    var returnValue = paraObj[paras.toLowerCase()];
    if (typeof (returnValue) == "undefined") {
      return "";
    } else {
      return returnValue;
    }
  },

  /**
   *对Date的扩展，将 Date 转化为指定格式的String
   *月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
   *年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
   *例子：
   *(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
   *(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
   */
  format : function (date,fmt) {
    var o = {
      "M+": date.getMonth() + 1, //月份
      "d+": date.getDate(), //日
      "h+": date.getHours(), //小时
      "m+": date.getMinutes(), //分
      "s+": date.getSeconds(), //秒
      "q+": Math.floor((date.getMonth() + 3) / 3), //季度
      "S": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
      if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
  }
}
//判断是否是商密，如果是则替换附件下载链接为商密下载
function updateDownloadUrlBySecurityType() {
  var securitytype = $("#security_grade").val();
  if(securitytype == "3" || securitytype == "1") {
    var template_download = $(".template-download");
    for(var i=0; i<template_download.length; i++) {
      var a = $(template_download[i]).children('td').eq(1).children('p').children('span').children('a');
      var href = $(a).attr("href");
      //参数
      var Id = href.split("=")[1];
      var userId = $("#creator_id").val();
      var texts = "?Id="+Id+"&type=fj&businessSecretUser="+userId+"&secrecyTerm="+securitytype;
      //替换文件名的下载URL
      $(a).attr("download",a.text());
      $(a).attr("href","/rest/oainterface/businessSecret/downBusinessSecretFile"+texts);


      var d = $(template_download[i]).children('td').eq(3).children('a.download');
      //替换下载的下载URL
      $(d).attr("href","/rest/oainterface/businessSecret/Test");
    }
  }
}

var OASM = "";
$(document).ready(function() {
  try{
    $("body").append($(".form-section").detach());
    $("body").append($("#basic_control").detach());
    $.jsRenderTemplate.render("template.flowform.layout",$(".form-horizontal"),{}, function(){
      $("#framework-content").append($(".form-section").detach());
      $(".form-horizontal").append($("#basic_control").detach());
      $(".form-group").append($("#control2_view").detach());
      $("#opinion-controls-section").append($("#opinion-controls").detach());
      $(".form-section").show();
      setTimeout(function(){
        renderLayoutCallback();
        eventBinding();
      }, 1000);
    });
  }catch(e){
    setTimeout(function(){
      renderLayoutCallback();
      eventBinding();
    }, 1000);
  }
});

function renderLayoutCallback(){
  $('.tooltip-title').tooltip();
  //打印模式
  if(FlowForm.getQueryString(location.href,"mode")=="print"){
    var html = getPrintControl();
    $(".container").before(html);
  }
  if($("#instId").val() != "0" && $("#instId").val() != undefined && $("#instId").val() != null && $("#instId").val() != ""){
    if(cp_oaBasicInfo.cp_flowAttrs.cannotSendToRead!=="true"){
      $('#control2_view').append('<button type="button" class="btn btn-default" id="sendtoread" onclick="sendToRead();">知会</button>');
    }
    $('#control2_view').append('<button type="button" class="btn btn-default" id="print" onclick="printFlowForm();">打印</button>');
  }

  grcFlowForm = FlowForm.createNew();

  //top取初始化
  /*setTimeout(function(){
    $("#framework_title").text(grcFlowForm.fileTitle);
    $("#framework_flow").text(grcFlowForm.flowName);
    $("#framework_node").text(grcFlowForm.stepName);
    $("#framework_time").text(grcFlowForm.createDateStr);
  }, 1000);*/

  /*获取当前部门文档管理员 start*/
  //当前部门ID
  var docManagerTmp = cp_oaBasicInfo.cp_docManager;
  if(docManagerTmp.length > 0){
    WdRoles = docManagerTmp[0].code ;
    for(var i = 1 ; i < docManagerTmp.length ; i ++){
      WdRoles = WdRoles + "," + docManagerTmp[i].code ;
    }
  }else{
    WdRoles = "";
  }
  /*获取当前部门文档管理员 end*/
  //系统管理员
  var adminUserTmp = cp_oaBasicInfo.cp_adminUsers;
  if(adminUserTmp.length > 0){
    secRole = adminUserTmp[0].account ;
  }
  if(adminUserTmp.length > 1){
    for(var i = 1 ; i < adminUserTmp.length ; i ++){
      secRole = secRole + "," + adminUserTmp[i].account ;
    }
  }

  //保存按钮增加事件，更改待办标题
  if($("#framework_node").length>0 && $("#framework_node").val()!="开始" && $("#framework_node").val()!="起草"){

    $(document).bind("after.workflow.doApprove",function(){
      for( var item in pageForm.settings.pageConfig.controls){
        if(pageForm.settings.pageConfig.controls[item].type=="title"){
          var newTitle = $("#"+item).val();
          break;
        }
      }
      var number = "";
      if($("#oanumber").val() != undefined && $("#oanumber").val() != null){
        number = $("#oanumber").val();
      }
      dwrBaseFunctionService.fnChangeTodoTitle($("#instId").val(),$("#activeStepId").val(),newTitle,number,$("#beanId").val(),$("#formId").val().split(":")[1],function(data){

      });
    });
    $(document).bind("after.workflow.addOperator",function(){
      for( var item in pageForm.settings.pageConfig.controls){
        if(pageForm.settings.pageConfig.controls[item].type=="title"){
          var newTitle = $("#"+item).val();
          break;
        }
      }
      var number = "";
      if($("#oanumber").val() != undefined && $("#oanumber").val() != null){
        number = $("#oanumber").val();
      }
      dwrBaseFunctionService.fnChangeTodoTitle($("#instId").val(),$("#activeStepId").val(),newTitle,number,$("#beanId").val(),$("#formId").val().split(":")[1],function(data){

      });
    });

  }


  //当前用户
  local_user = pageConfig.currentUserInfo.currentUserAccount;

  if($("#stepDescriptorIsStart").val()=="true" && $("#instId").val() != "0" && !grcFlowForm.isSubFlow &&
      ($("#deleted")[0] && $("#deleted").val() != "2") && location.href.indexOf("view.htm")==-1
      && $("#creatorAccount").val()==local_user){
    $('#control2_view').append('<button type="button" class="btn btn-default" id="trash" onclick="trashFlowForm();">作废</button>');
  }

  if((secRole.indexOf(local_user) > -1 || WdRoles.indexOf(local_user) > -1) && (($("#stepDescriptorIsStart").val()=="true" && grcFlowForm.isSubFlow) || $("#stepDescriptorIsStart").val()=="false") &&
      !(cp_oaBasicInfo.cp_isSubFlow && $("#stepDescriptorIsEnd").val()=="true")){
    $('#control2_view').append('<button type="button" class="btn btn-default" id="reshuffle" onclick="adminReshuffle();">特送</button>');
  }
  if(cp_oaBasicInfo.cp_isFullAuthEdit && location.href.indexOf("mode=sendtoread")==-1 && location.href.indexOf("mode=readed")==-1 &&
      !($("#stepDescriptorIsStart").val()=="true" && !grcFlowForm.isSubFlow && ($("#stepSN").val()=="-1" || $("#stepSN").val()=="0"))){
    $('#control2_view').append('<button type="button" class="btn btn-default" id="fullauthedit" onclick="fullAuthEdit();">全权限编辑公文</button>');
  }

  //判断归档按钮、延时归档按钮显示---start

  var currentAccount=pageConfig.currentUserInfo.currentUserAccount;
  if($("#framework_node").text()=="结束"){
    if(pageConfig.id == 'oaSignReportNew' || pageConfig.id == 'hdoaReceiptFlow'){
      var archiveDocParam = [{
        "formId":$("#formId").val(),
        "beanId":parseInt($("#beanId").val()),
        "instId":parseInt($("#instId").val()),
        "belongedorgId":parseInt($("#belongedOrgId").val())
      }];
      dwrArchiveService.archiveDoc(archiveDocParam,{callback:function(data){
          waitbar.hide();
          if (data) {
            $.tip("归档成功");
            $("#archive").hide();
            window.location.reload(true);
          }else{
            $.tip("归档失败，请联系管理员！");
          }
        },
        exceptionHandler : function(errorString, exception) {
          waitbar.hide();
          $.tip("后台报错，请联系管理员！");
        }
      });
    }else{
      if(cp_oaBasicInfo.cp_state==0){//流程结束、文档管理员、未归档未延时展示延时归档按钮
        $('#control2_view').append('<button type="button" class="btn btn-default" id="archiveLater" cmd="archiveLater">延时归档</button>');
        //延时归档按钮点击方法
        if($("button[cmd='archiveLater']").length > 0){
          $("button[cmd='archiveLater']").on("click",function(){
            var waitbar = showWaitbar(jQuery, "正在操作，请稍后...");
            dwrArchiveService.archiveLater($("#doc_title").val(),currentAccount,$("#formId").val(),$("#instId").val(),$("#beanId").val(),$("#belongedOrgId").val(),{
              callback:function(success){
                waitbar.hide();
                if(success){
                  $.tip("延时归档成功");
                  $("#archiveLater").hide();
                }else{
                  $.tip("延时归档失败，请联系管理员！");
                }
              },
              exceptionHandler : function(errorString, exception) {
                waitbar.hide();
                $.tip("后台报错，请联系管理员！");
              }
            });
          });
        }
      }else if(cp_oaBasicInfo.cp_state==1){//流程结束、文档管理员、未归档已延时展示归档按钮
        $('#control2_view').append('<button type="button" class="btn btn-default" id="archive" cmd="archive">归档</button>');
        //归档按钮点击方法
        if($("button[cmd='archive']").length > 0){
          $("button[cmd='archive']").on("click",function(){
            var waitbar = showWaitbar(jQuery, "正在操作，请稍后...");
            var archiveDocParam = [{
              "formId":$("#formId").val(),
              "beanId":parseInt($("#beanId").val()),
              "instId":parseInt($("#instId").val()),
              "belongedorgId":parseInt($("#belongedOrgId").val())
            }];
            dwrArchiveService.archiveDoc(archiveDocParam,{callback:function(data){
                waitbar.hide();
                if (data) {
                  $.tip("归档成功");
                  $("#archive").hide();
                  window.location.reload(true);
                }else{
                  $.tip("归档失败，请联系管理员！");
                }
              },
              exceptionHandler : function(errorString, exception) {
                waitbar.hide();
                $.tip("后台报错，请联系管理员！");
              }

            });
          });
        }
      }
    }
  }
  /*
  if($("#mode").val()=="EDIT"){
    //环节上配置的延时归档按钮显示-------环节上配置了、处理状态、未归档、未延时归档时显示延时归档按钮
    if(cp_oaBasicInfo.cp_isShowAlterArchiveBtn=="1"){
      if(cp_oaBasicInfo.cp_stateArchivelater==0){
        $('#control2_view').append('<button type="button" class="btn btn-default" id="archiveLater" cmd="archiveLater">延时归档</button>');
        //延时归档按钮点击方法
        if($("button[cmd='archiveLater']").length > 0){
          $("button[cmd='archiveLater']").on("click",function(){
            var waitbar = showWaitbar(jQuery, "正在操作，请稍后...");
            dwrArchiveService.archiveLater($("#doc_title").val(),currentAccount,$("#formId").val(),$("#instId").val(),$("#beanId").val(),$("#belongedOrgId").val(),{
              callback:function(success){
                waitbar.hide();
                if(success){
                  $.tip("延时归档成功");
                  $("#archiveLater").hide();
                }else{
                  $.tip("延时归档失败，请联系管理员！");
                }
              },
               exceptionHandler : function(errorString, exception) {
                 waitbar.hide();
                 $.tip("后台报错，请联系管理员！");
               }

            });
          });
        }
      }
    }
  }
  */
  //判断归档按钮、延时归档按钮显示---end

  if(grcFlowForm.readLogController){
    if(grcFlowForm.hasReadLog){
      $('#control2_view').append('<button type="button" class="btn btn-default" id="sendtoreadlog" onclick="sendToReadLog();">知会记录</button>');
    }
  }

  if(grcFlowForm.flowNodeAttrs.contain("docEvaluation") && grcFlowForm.flowNodeAttrs.get("docEvaluation")=="true"){
    if($("#instId").val() != "0" && !grcFlowForm.hasDocEvaluation){
      $('#control2_view').append('<button type="button" class="btn btn-default" id="evaluation" onclick="docEvaluation();">公文评价</button>');
    }
  }
  if(grcFlowForm.hasDocEvaluation){
    $('#control2_view').append('<button type="button" class="btn btn-default" id="btnViewEva" onclick="viewEvaluation();">查看公文评价</button>');
  }
  $(document).trigger("workflow.btn.Loaded");

  //加载暂存意见
  grcFlowForm.loadSavedOpinion();

  //意见提示信息没有意见时文字隐藏
  if(!$(".accordion-body textarea")[0]){
    $(".processform-approvelOpinion .accordion-group").hide();
  }

  $("button[cmd='workflow$encancel']").text("撤回");
  $("button[cmd='workflow$close']").text("关闭");

  //起草环节隐藏退回按钮
  if($("#stepId").length > 0 && $("#stepId").val().split(".")[1]=="1"){
    $("div#control2_view button").each(function(i,e){
      if($(e).html().indexOf("驳回")!=-1){
        if($(e).html().indexOf("直送") != -1){

        }else{
          $(e).hide();
        }
      }

    })
  }

  //流程设计器，勾线驳回则显示驳回按钮。
  $("button[cmd='workflow$rollback_product']").css("display","none");
  if(cp_oaBasicInfo.cp_flowNodeAttrs.rollBack && !isFullAuthEdit){
    $("button[cmd='workflow$rollback_product']").show();
  }
  if(isFullAuthEdit){
    grcFlowForm.initDataWhenLoad();
  }


  //驳回方法
  if($("button[cmd='workflow$rollback_product']").length > 0){
    $("button[cmd='workflow$rollback_product']").on("click",function(){
      var contentHtml = '<div class="rollback_product_option" style="text-align:center;margin:10px 0 10px 0;">';
      contentHtml +='<input type="radio" name="rollbacktype" value="interfere" checked="true" >重走流程';
      contentHtml += '&nbsp;&nbsp;';
      contentHtml +='<input type="radio" name="rollbacktype" value="return_interfere" >直接提交到本环节';
      contentHtml +='</div>';
      contentHtml +='<div class="rollback_product_content">';
      contentHtml +='<table>';
      contentHtml +='<thead>';
      contentHtml +='<tr>';
      contentHtml +='<th style="width:70%;" >环节名称</th>';
      contentHtml +='<th style="width:30%;">处理人</th>';
      contentHtml +='<th style="display:none;">驳回</th>';
      contentHtml +='</tr>';
      contentHtml +='</thead>';
      contentHtml +='<tbody>';
      for (var j = 0; j < FlowForm.rollbackSteps.length; j++) {
        var step = FlowForm.rollbackSteps[j];
        var checkHtml = '';
        if(j==0){
          checkHtml='checked="true"';
        }
        contentHtml +='<tr>';
        contentHtml +='<td>'+step[1]+'</td>';
        contentHtml +='<td>'+step[3]+'</td>';
        contentHtml +='<td style="display:none;"><input type="radio" name="rollbackvalue" action-name="'+step[1]+'" action-user="'+step[2]+'" value="'+step[0]+'" '+checkHtml+'></td>';
        contentHtml +='</tr>';
      }
      contentHtml +='</tbody>';
      contentHtml +='</table>';
      contentHtml +='</div>';
      var config = {
        title:"驳回",
        buttons:[{
          label:"确定",
          clazz:"btn-primary",
          click:function(){
            var fnSetPriorityExtFun = "oaSetPriorityCustomFun";
            if(typeof window[fnSetPriorityExtFun] =="function" ){
              eval(fnSetPriorityExtFun+"()");
            }

            var stepid = $("input[name='rollbackvalue']:checked").val();
            var stepname = $("input[name='rollbackvalue']:checked").attr("action-name");
            var step = {id:stepid,name:stepname};
            controlMenu.doRollback(step, function(cbscope, retdata){
              // 流程表单  提交 后的回调方法
              $(document).trigger("after.workflow.doRollback", [cbscope, retdata]);
            });
          },
          autoclose:true
        },
          "cancel"],
        afterShow:function(dialog){
          $(".rollback_product_content tbody tr").on("click",function(){
            $(".rollback_product_content tbody .selected").removeClass("selected");
            $(this).addClass("selected");
            $("input[name='rollbackvalue']",this).attr('checked', 'true');
          });
        }
      };
      productDialog(contentHtml,config);

    });
  }

  //业务类型字段赋值
  if($("#docType").length > 0){
    var docType = getUrlParam("docType");
    if(docType !== "" && docType !== null){
      $("#docType").val(docType);
    }
  }
  //业务类型字段赋值
  if($("#doc_type").length > 0){
    var docType = getUrlParam("docType");
    if(docType !== "" && docType !== null){
      $("#doc_type").val(docType);
    }
  }

  //加签减签按钮隐藏
  $("[cmd='workflow$removeOperator']").css("display","none");
  $("[cmd='workflow$addOperator']").css("display","none");
  $("[cmd='workflow$viewLog']").css("display","none");

  //加签减签按钮样式调整
  $("[cmd='workflow$addSubFlowOperator']").attr("class","btn btn-primary");
  $("[cmd='workflow$removeSubFlowOperator']").attr("class","btn btn-primary");
  $("#control2_view").prepend($("[cmd='workflow$removeSubFlowOperator']"));
  $("#control2_view").prepend($("[cmd='workflow$addSubFlowOperator']"));


  //待阅变已阅
  if(FlowForm.getQueryString(location.href,"mode")=="sendtoread"){
    $("#grcsp_comments_panel").show();
    $(".accordion-body").html('<div rscc="gjisMS_sign" '
        + 'id="gjisMS_sign_view" class="hd-list">'
        + '<input type="hidden" id="opinionControlId" value="hdOaOpinion">'
        + '<input type="hidden" id="opinionControlFieldId" name="opinionControlFieldId" value="gjisMS_sign,gjisMS_sign">'
        + '</div>'
        + '<div class="timeline_opinion">'
        + '<textarea id="gjisMS_sign$_opinion_popup_content" '
        + '	 name="gjisMS_sign$_opinion_popup_content" '
        + '		 class="form-control signContext"'
        + '			 onblur="saveAllOpinion(this);" value="">'
        + '</textarea></div>'
        + '<input id="gjisMS_sign" name="gjisMS_sign" type="hidden" '
        + '	 value=""> ');
    $('#control2_view').append('<button type="button" class="btn btn-default" id="btnSendToRead" onclick="updateReadToReaded();">标记为已阅</button>');
  }

  //将关闭按钮放在最后边
  if($("#control2_view").length>0 && $("button[cmd='workflow$close']").length>0){
    $("#control2_view").append($("button[cmd='workflow$close']"));
  }

  //待办通知方式
  if(location.href.indexOf("edit.htm")!=-1 || location.href.indexOf("create.htm")!=-1){
    var messageRemind = [];
    messageRemind.push('<span>待办通知方式：');
    messageRemind.push('<input type="checkbox" id="messageRemindSMS" name="messageRemindSMS"> 蓝信');
    messageRemind.push('<input type="checkbox" id="messageRemindMail" name="messageRemindMail"> 邮件');
    messageRemind.push('</span>');
    $("#control2_view").after(messageRemind.join("\n"));
  }

  checkZuofeiState();//setTimeout("checkZuofeiState()",300);
  var pishiArray = cp_oaBasicInfo.cp_pishiArray;
  $.each(pishiArray,function(p,piopt) {
    if(piopt.id=="OASM") {
      OASM = piopt.param0;
    }
  });
  if(OASM=="true"){
    updateDownloadUrlBySecurityType();//setTimeout("updateDownloadUrlBySecurityType()",3000);
  }
  //隐藏平台的关注按钮
  if($("button[cmd='workflow$myAttention']").length>0){
    $("button[cmd='workflow$myAttention']").hide();
  }
  
  richTextFieldPatch();
}

function checkZuofeiState(){
  if ($("#deleted").length > 0 && $("#deleted").val()=="2") {
    $("input").attr("disabled",true);
    $("button:not(#myAttentionCancel):not([cmd='workflow$close'])").remove();
    $("select").attr("disabled",true);
    $("a").attr("disabled",true);
    //流程跟踪页签不能加disabled
    $("a[href='#flowTrace']").attr("disabled",false);
    $("a[href='#business-area']").attr("disabled",false);
    if($(".tab-content caption").text().indexOf("(已作废)")==-1){
      $(".tab-content caption").html($(".tab-content caption").text()+"(已作废)");
    }

    if($("#creatorAccount").val()==pageConfig.currentUserInfo.currentUserAccount){
      $("button[cmd='workflow$close']").before('<button type="button" class="btn btn-default" cmd="workflow$trashregain">恢复</button>');
      $("button[cmd='workflow$close']").before('<button type="button" class="btn btn-default" cmd="workflow$trashdelete">永久删除</button>');
      $("button[cmd='workflow$trashregain']").on("click",function(){
        var formId = $("#formId").val().split(":")[1];
        var beanId = parseInt($("#beanId").val());
        var activeStepId = parseInt($("#activeStepId").val());
        var instid = parseInt($("#instId").val());
        dwrBaseFunctionService.trashFlowFormReagain(formId,beanId,activeStepId,instid,{
          callback :function(data){
            if(data){
              alert("该文件恢复成功!");
              window.opener.location.reload();
              self.close();
            }else{
              alert("该文件恢复失败，请重试!");
              return;
            }
          }
        });
      });
      $("button[cmd='workflow$trashdelete']").on("click",function(){
        if(!confirm("永久删除后将不可恢复，确认要删除吗？")){
          return false;
        }
        var formId = $("#formId").val().split(":")[1];
        var beanId = parseInt($("#beanId").val());
        var activeStepId = parseInt($("#activeStepId").val());
        var instid = parseInt($("#instId").val());
        dwrBaseFunctionService.neverDelete(formId,beanId,activeStepId,instid,{
          callback :function(data){
            if(data){
              alert("永久删除成功!");
              window.opener.location.reload();
              self.close();
            }else{
              alert("永久删除失败，请重试!");
              return;
            }
          }
        });
      });
    }

  }
}
function showAndHidePageContent(attachId){
  if($("#mainBodyFrame").attr("src") == undefined || $("#mainBodyFrame").attr("src") == null || $("#mainBodyFrame").attr("src") == ""||$("#hd_doc_select").val()=="1"){
    //华电业务类型变更定制
    if($("#hd_doc_select").val()=="1"){
      $("#hd_doc_select").val("2");
    }


    $("#mainBodyFrame").attr("src","/user/product/oa/common/jsp/oaDocManager.jsp?id="+attachId);
  }else{
    if($("#mainBodyFrame")[0].contentWindow.$.managerNtko != undefined && $("#mainBodyFrame")[0].contentWindow.$.managerNtko != null ){
      if($("#mainBodyFrame")[0].contentWindow.$.managerNtko._setNtkoBookmarkValue != undefined && $("#mainBodyFrame")[0].contentWindow.$.managerNtko._setNtkoBookmarkValue != null && $("#mainBodyFrame")[0].contentWindow.$.managerNtko._setNtkoBookmarkValue != ""){
        if(setNtkoBookmarkValueCustom !== undefined && setNtkoBookmarkValueCustom !== null && setNtkoBookmarkValueCustom !== ""){
          var returnBookmark = setNtkoBookmarkValueCustom(this, this.ntko);
          if("draft" == returnBookmark){
            $("#mainBodyFrame")[0].contentWindow.$.managerNtko._setNtkoBookmarkValue();
          }else if("taoda" == returnBookmark){

          }else{

          }
        }else{
          $("#mainBodyFrame")[0].contentWindow.$.managerNtko._setNtkoBookmarkValue();
        }

      }
    }
  }

  $("#framework-content").hide();
  $("#mainBodyFrame").show();
  $("#workFlowMonitor").hide();
  //华电办文说明
  $("#mainBwsmF").hide();
}

function redOkClick(modalDialog){
  if($(".tableCheck").attr("value") == undefined ||$(".tableCheck").attr("value") == null || $(".tableCheck").attr("value") == ""){
    alert("未选择红头！");
  }
  else{
    var id = $(".tableCheck").attr("value");
    var title = pageForm.getFieldValue(pageForm.getFieldNamesOfType('title'));
    if(pageForm.getField(grcFlowForm.attachId)){
      // 复制当前选到的这个范本 作为正文 赋值到正文域
      dwrRedheadConfigService.getFileResource(id,title,$("#formId").val(),grcFlowForm.attachId,$("#instId").val(),
          {callback: function(return_fileinfo) {
              if( ! $.isArray(return_fileinfo)){
                return;
              };

              // 定义一个附件需要的json
              var fileinfos = [];

              $(return_fileinfo).each(function(_index ,_el ){
                var fileinfo = {"id": _el.id,
                  "tmpfileId": _el.tmpfileId,
                  "name":_el.name,
                  "creationTime": _el.creationTime,
                  "lastModifiedTime": _el.lastModifiedTime,
                  "lastAccessTime": _el.lastAccessTime,
                  "size": _el.size,
                  "mimeType": _el.mimeType,
                  "category": "ZW",
                  "props": {
                    "attachAuth": "[]"
                  }
                }

                fileinfos.push(fileinfo);
              });

              var copy_zw_str = $.toJSON(fileinfos);
              // 兼容性----------
              //window.parent.contractInfoFrame.pageForm.setFieldValue(contractText_dn, copy_zw_str);
              pageForm.setFieldValue(grcFlowForm.attachId, copy_zw_str);
              showAndHidePageContent(grcFlowForm.attachId);
            }});
    }

    modalDialog.modal('hide');
  }
}

function chooseChange(obj){
  $(".tableCheck").attr("class","");
  $(".active").attr("class","");
  $(obj).attr("class","tableCheck");
  $(obj.parentNode).attr("class","active");

}

//根据部门ID获取部门负责人
function getDeptBossheads(deptId){
  var userList = new Array();
  javascript:dwr.engine.setAsync(false);
  dwrDeliverApprovalService.getDeptBossheadByDeptId(deptId,{
    callback :function(data){
      userList = data;
    }
  });
  return userList;
}

//设置部门负责人值  nameField姓名字段,accountField:账户字段
function setDeptBoss(nameField,accountField,currentUserDeptId){
  //获取当前部门负责人
  if($("#"+nameField).length > 0){
    $("#"+nameField).attr("readOnly","readOnly");
    $("#"+nameField).css("border","0px");
    //如果有值则跳过
    if($("#"+nameField).val() != ""){
      return;
    }
    //调用获取部门负责人列表方法 参数currentUserDeptId为当前部门ID，可以通过pageConfig中获取
    var userList = getDeptBossheads(currentUserDeptId);
    //用于存放部门负责人名称
    var bossNames = new Array();
    //用于存放部门负责人账户
    var bossAccount = new Array();
    //判断部门负责人列表是否为空
    if(userList != "" && userList.length > 0){
      //将部门负责人数据取出分别存放
      for(var i = 0 ; i< userList.length; i++){
        bossNames.push(userList[i].name);
        bossAccount.push(userList[i].account);
      }
    }
    //进行赋值
    if(bossNames.length > 0 ){
      $("#"+nameField).val(bossNames.join(","));
      $("#"+accountField).val(bossAccount.join(","));
    }
  }
}

//校验标题是否重复	查询条件对象 ： condition
//参考样例   {"name" : "数据库标题字段",	"op" : "eq","stringValue":"标题的值" }
function checkFormTitleIsRepeat(condition){
  var searchCondition = [];
  //表单ID（表单设计器中的ID）
  var formId = "";
  //流程entry ID
  var entryId = "" ;
  var res = false;
  if($("#formId").length > 0 ){
    formId = $("#formId").val();
  }

  if($("#instId").length > 0){
    entryId = $("#instId").val();
  }
  //表单id为空或者标题为空则退出
  if(formId === ""){
    return res;
  }
  if(condition != null ){
    if(condition.length != undefined && condition.length != null &&  condition.length != ""){
      for(var i=0;i<condition.length;i++){
        searchCondition.push(condition[i]);
      }
    }else{
      searchCondition.push(condition);
    }


  }
  javascript:dwr.engine.setAsync(false);
  //调用dwr获取数据，返回值为true则说明有重复的，返回值为false则说明没有重复的
  dwrBaseFunctionService.checkFormTitleToRepeat(formId,entryId,searchCondition,{
    callback :function(data){
      res = data;
    }
  });
  return res;
}

//根据查询条件返回业务单文件数量	查询条件对象 ： condition
//参考样例   {"name" : "数据库标题字段",	"op" : "eq","stringValue":"条件值" }
function getBusinessFormCountByCustomCondition(condition){
  var searchCondition = [];
  //表单ID（表单设计器中的ID）
  var formId = "";
  //流程entry ID
  var entryId = "" ;
  var res = false;
  if($("#formId").length > 0 ){
    formId = $("#formId").val();
  }

  if($("#instId").length > 0){
    entryId = $("#instId").val();
  }
  //表单id为空或者标题为空则退出
  if(formId === ""){
    return res;
  }
  if(condition != null ){
    searchCondition.push(condition);
  }
  javascript:dwr.engine.setAsync(false);
  //调用dwr获取数据，返回值为true则说明有重复的，返回值为false则说明没有重复的
  dwrBaseFunctionService.getBusinessEntryCountByCustomCondition(formId,entryId,searchCondition,{
    callback :function(data){
      res = data;
    }
  });
  return res;
}

//校验意见是否必填
function checkRequiredOpinionFields(){
  var validator = $("form").validate();
  var settings = validator.settings;
  var opinionFields = getCurrentNodeRequiredOpinion();
  var res = false;
  if(opinionFields === undefined || opinionFields.length === 0 ) return false;
  for(var a = 0 ;a < opinionFields.length; a++){
    if($("#" + opinionFields[a] + "\\$_opinion_popup_content").val() === ""){
      settings.rules[opinionFields[a]] = {required : false};
      return true;

    }
    if($("#" + opinionFields[a] + "\\$_opinion_popup_content").val() !== ""){
      delete settings.rules[opinionFields[a]];
    }
  }
  return false;
}

//获取当前环节必填意见字段
function getCurrentNodeRequiredOpinion(){
  var opinionFields = new Array();
  //判断是否有意见区域
  if($(".timeline_opinion textarea").length == 0 ){
    return;
  }
  $(".timeline_opinion textarea").each(function(){
    var fieldName = $(this)[0].id.substring(0,$(this)[0].id.indexOf("$"));
    var isRequired = checkFieldIsRequired(fieldName);
    if(isRequired){
      opinionFields.push(fieldName);
    }
  })
  return opinionFields;
}

//检查字段是否必填
function checkFieldIsRequired(fieldName){
  var validator = $("form").validate();
  var settings = validator.settings;
  if(fieldName == ""){
    return false;
  }
  for(a in settings.rules){
    if(a === fieldName){
      return true;
    }
  }
  return false;
}

function eventBinding(){
  //隐藏正文书签
  $("[role='mainBody']").hide();
  //提交按钮的时候，切换到第一个页签，避免IE下ntko控件遮挡弹出框。

  $(".form-actions").find("button").click(grcFlowForm.businessProcess);
  $('button[cmd="workflow$save"]').click(function(){
    grcFlowForm.businessProcess;

    //setTimeout(function(){
    if($("#instId").val() != "0"){
      if($("#sendtoread")[0] == undefined){
        if(cp_oaBasicInfo.cp_flowAttrs.cannotSendToRead!=="true"){
          $('#control2_view').append(
              $('<button type="button" class="btn btn-default" id="sendtoread" onclick="sendToRead();">知会</button>').fadeIn(300)
          );
        }
      }
      if($("#print")[0] == undefined){
        $('#control2_view').append(
            $('<button type="button" class="btn btn-default" id="print" onclick="printFlowForm();">打印</button>').fadeIn(300)
        );
      }

      if($("#trash")[0] == undefined && $("#stepDescriptorIsStart").val()=="true" && !grcFlowForm.isSubFlow
          && $("#creatorAccount").val()==local_user){
        $('#control2_view').append(
            $('<button type="button" class="btn btn-default" id="trash" onclick="trashFlowForm();">作废</button>').fadeIn(300)
        );
      }
    }
    //意见暂存start
    var opinion = "";
    var fieldId = "";
    var opinionField = [];
    if(pageConfig.controls){
      for(var key in pageConfig.controls){
        if(pageConfig.controls[key].controlType=="hdOaOpinion"){
          opinionField.push(pageConfig.controls[key].id);
        }
      }
    }
    var data = pageForm.form.serializeArray();
    for(var i = 0;i < data.length;i ++){
      var input = $("[id='"+data[i].name+"$_opinion_popup_content']")[0];
      if($.inArray(data[i].name,opinionField) != -1 && input && input.value!=""){
        fieldId = data[i].name;
        if($("#"+fieldId).val()=="null"){
          saveAllOpinion(input);
        }
        opinion = $("#"+fieldId).val();
        //扩展意见表中content字段新增opertype属性 wangjiyang
        var opinionBefore=opinion.substring(0,opinion.lastIndexOf(","));
        var opinionAfter=opinion.substring(opinion.lastIndexOf( ","));
        opinion=opinionBefore+',"opertype":"User"'+opinionAfter
      }
    }
    var formId = $("#formId").val();
    var beanId = $("#beanId").val();
    var entryId = $("#instId").val();
    var stepSerialNumber = $("#stepSN").val();
    if(opinion!="" && fieldId!=""){  //如果意见域为空或者没有意见域则不保存（表单上一个环节最多只有一个意见域，因此保存放循坏外）
      dwrBaseFunctionService.saveExtOpinion(opinion,formId,fieldId,beanId,parseInt(entryId),parseInt(stepSerialNumber),4,{
        callback :function(data){
          return;
        }
      });
    }

    //意见暂存end
    var curUrl = window.location.href;
    if(curUrl.indexOf("edit.htm") == -1 && !isFullAuthEdit){
      var entryId = $("#instId").val();	//wyl修改保存页面刷新数据丢失
      var key = Math.round(Math.random() * 1000000);
      var url = '/bpm/edit.htm?docCategoryId=1&instId='+ entryId + "&rkey=" + key;
      if(!!entryId && entryId != 0){
        $(window).unbind('beforeunload');
        $(window).attr('location', url);
      }
    }
    if(isFullAuthEdit){
      dataWhenLoad = {};
      grcFlowForm.initDataWhenLoad();
    }
    //}, 1000);

  });

  //开发排查问题工具
  //业务类型
  //setTimeout(function(){
  $('button[cmd="workflow$ywlx"]').click(function(){
    var entryId = $("#doc_type").val();
    var url = '/wp/docBusinessCategory/docBusinessTypeView.htm?id=' + entryId;
    var win = window.open(url, "查看业务类型");
    if (!win) {
      alert('弹出窗口已被拦截，请手工设置为允许弹出窗口！');
    } else {
      win.focus();
    }
  });
  $('button[cmd="workflow$gwpz"]').click(function(){
    var deptId = $("#create_dept_id").val();
    var deptCode = $("#create_dept_code").val();
    var deptName = $("#create_dept_name").val();//?deptId=1000&deptName=慧点科技test&deptCode=smartdot
    var url = '/user/product/oa/docconfig/loadDocument?deptId=' + deptId+'&deptName='+deptName+'&deptCode='+deptCode;
    var win = window.open(url, "查看公文配置");
    if (!win) {
      alert('弹出窗口已被拦截，请手工设置为允许弹出窗口！');
    } else {
      win.focus();
    }
  });
  $('button[cmd="workflow$bh"]').click(function(){
    var beanId = $("#id").val();
    var formId = $("#formId").val().substring($("#formId").val().indexOf(":")+1);
    dwrOaDocNumberProjectService.getNumberInfo(beanId,formId,{
      callback : function(data) {
        var expressions = jQuery.parseJSON(data);
        if(expressions == null){
          alert("编号为空!");
        }else{
          var url = '/wp/numberConfiguration/numberConfigView.htm?id=' + expressions.numConfigId;
          var win = window.open(url, "查看编号配置");
          if (!win) {
            alert('弹出窗口已被拦截，请手工设置为允许弹出窗口！');
          } else {
            win.focus();
          }
        }
      }
    })
  });

  $('button[cmd="workflow$cklc"]').click(function(){
    var flowId = $("#flowId").val();
    var url = '/admin/flowNew/designer2.jsp?flowId='+flowId;
    var win = window.open(url, "查看编号配置");
    if (!win) {
      alert('弹出窗口已被拦截，请手工设置为允许弹出窗口！');
    } else {
      win.focus();
    }
  })
  $('button[cmd="workflow$cstd"]').click(function(){
    var url1 = document.location.href.toString();
    var arrUrl = url1.split("//");
    var start = arrUrl[1].split("/");
    var ht = arrUrl[0]+"//"+start[0];
    var head = document.getElementsByTagName('head')[0];
    var script1 = document.createElement('script');script1.type = 'text/javascript';
    script1.src = ht+'/dwr/interface/dwrBugInfoService.js';
    head.appendChild(script1);
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = ht+'/resources/oa/bugInfo/js/bugInfo.js';
    head.appendChild(script);

  })
  //}, 3000);

  $("#grcsp_processform_sidebar").prepend('<div class="btn-toolbar hd-toolbar" id="saveAndClose"></div>');
  $("#saveAndClose").append($("button[cmd='workflow$close']"));
  $("#saveAndClose").append($("button[cmd='workflow$save']"));
  $("button[cmd='workflow$close']").css("float","right");
  $("button[cmd='workflow$save']").css("float","right");
  //开发排查问题工具
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="workflow$cklc">查看流程</button>');
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="workflow$gwpz">公文配置</button>');
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="workflow$ywlx">业务类型</button>');
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="">红头</button>');
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="workflow$bh">编号</button>');
  $('#control2_view').append('<button type="button" class="btn btn-primary" style="background-color: #3c763d;display:none;" cmd="workflow$cstd">提单时错误信息</button>');


  //页面加载完后触发事件
  $(document).trigger("oa.page.load.ready");
}
function devFlowInfo(){
  $('button[cmd="workflow$ywlx"]').show();
  $('button[cmd="workflow$gwpz"]').show();
  $('button[cmd="workflow$bh"]').show();
  $('button[cmd="workflow$cklc"]').show();
  $('button[cmd="workflow$cstd"]').show();
}


/**
 *
 */

function isNeedCommitZW(objJson){
  //判断是否起草正文
  if($("#mainBodyFrame")[0].contentWindow.$ != undefined && $("#mainBodyFrame")[0].contentWindow.$ != null && $("#mainBodyFrame")[0].contentWindow.$ != ""){
    var objNtko = $("#mainBodyFrame")[0].contentWindow.$.managerNtko;
    //判断是否正文是否编辑状态
    if(objNtko.settings.mode == "edit"){
      //判断是否正文需要保存
      if(objNtko.ntko.ActiveDocument.Saved == true){

      }else{
        var jsonValue = JSON.parse(objJson);
        //保存正文
        if(jsonValue.confirm != undefined && jsonValue.confirm != null && jsonValue.confirm != "" ){
          if(jsonValue.confirm == "true"){
            if(jsonValue.confirmInfo != undefined && jsonValue.confirmInfo != null && jsonValue.confirmInfo != ""){

              confirmSaveZWNtko(objNtko,jsonValue.confirmInfo);
            }else{
              confirmSaveZWNtko(objNtko,"正文未保存，是否保存？");
            }
          }else if(jsonValue.confirm == "false"){
            confirmSaveZWNtko(objNtko);
          }
        }else{
          confirmSaveZWNtko(objNtko);
        }
      }

    }
  }


  return;
}

function confirmSaveZWNtko(objNtko,confirmInfo){
  /*if(confirmInfo == undefined || confirmInfo == null || confirmInfo == ""){
    return saveZWNtko(objNtko);
  }else{
    if(confirm(confirmInfo)){
      return saveZWNtko(objNtko);
    }
  }*/
  return saveZWNtko(objNtko);
  //return;
}

function saveZWNtko(objNtko){


  var ret = objNtko.ntko.SaveToURL(objNtko.settings.contextPath+ objNtko.settings.saveUrl, 'file', 'tmpfileId=' + objNtko.file.tmpfileId,
      objNtko.file.name);
  var result = $.parseJSON(ret);
  if (!result || result.error != false) {
    alert("正文保存失败！");
    return false;
  }else {
    draftFile = $.extend({}, objNtko.file);
    draftFile.tmpfileId = result.file.id;
    draftFile.name = result.file.name;
    draftFile.lastModifiedTime = result.file.lastModifiedTime;
    draftFile.lastAccessTime = result.file.lastAccessTime;
    draftFile.size = result.file.size;
    draftFile.mimeType = result.file.mimeType;
    objNtko.file = draftFile;
    objNtko._saveFile(draftFile);
    objNtko._sendResult();
  }

  return "";
}

//打印页面
function printFlowForm(){
  /*//自定义打印界面
  var tdTitleBoon = true ;
  var url = null ;
  dwrHdOaDispatchServiceP.findHdOaDispatchById($("#beanId").val(),
    {callback:function(ret){
      if(ret && ret.data[0].DOCTABLETITTLE != null){
        tdTitleBoon = false ;
      }
    },async:false
  });

  if($("#printPageId").length>0 && $("#printPageId").val()!==''){
    url = "/bpm/view.htm?instId="+$("#instId").val()+"&flowId="+$("#flowId").val()+"&entryId="+$("#instId").val()+"&pageId="+$("#printPageId").val();
  }else{
    url = "/bpm/view.htm?instId="+$("#instId").val();
  }

  if(tdTitleBoon){
    url = url +"&tdTitle=" + encodeURIComponent($(".tdTitle").text()) ;
  }

  window.open(url);*/

  //华电uat需求修改 打印成pdf
  var beanId = $("#beanId").val();
  var indidocgroupid=document.getElementById("indidocgroupid").value;
  var groupid=document.getElementById(indidocgroupid).value;
  var doctitle=document.getElementById("doc_title").value;
  var instId = parseInt($("#instId").val());
  var flowId = $("#flowId").val();
  var entryId = $("#instId").val();
  var pdfUrl;
  if($("#formId").val()=='model:oaReceiptManage'){
    var pageId = $("#pageId").val()+"Print1";
    // pdfUrl = "http://172.20.55.15:8888/bpm/view.htm?docCategoryId=1&instId="+instId;
    pdfUrl = "http://"+location.host +"/bpm/view.htm?instId="+instId+"&flowId="+flowId+"&entryId="+entryId+"&pageId="+pageId+"&isArchive=true";
  }else if($("#formId").val()=='model:oaSignReport'){
    var pageId = $("#pageId").val()+"HD";
    pdfUrl = "http://"+location.host +"/bpm/view.htm?instId="+instId+"&flowId="+flowId+"&entryId="+entryId+"&pageId="+pageId+"&isArchive=true";
  }else if($("#formId").val()=='model:hdoaDispatchManage'){
    var pageId = "G_1_oaDispatchPrint";
    pdfUrl = "http://"+location.host +"/bpm/view.htm?instId="+instId+"&flowId="+flowId+"&entryId="+entryId+"&pageId="+pageId+"&isArchive=true";
  }
  //下载生成pdf文件
  var url=contextPath + "/rest/oainterface/printGeneratePdf?pdfUrl=" + pdfUrl + "&doctitle=" + encodeURI(encodeURI(doctitle));
  window.open(url);
}

function getPrintControl(){
  var arr = [];
  arr.push('<div id="print-control">');
  arr.push('<div class="print-content">');
  arr.push('<button id="print-btn" type="button" onclick="printcld();"><span class="icon-print"></span><span data-string-id="indiplatform.tylc.dayin">打印</span></button>');
  arr.push('</div>');
  arr.push('</div>');
  return arr.join("\n");
}

function printcld(){
  if(typeof fnPrintCldCustom == "function"){
    fnPrintCldCustom();
  }
  window.print();
}

//作废
function trashFlowForm(){
  if(confirm("请确认是否作废？")){
    var formId = $("#formId").val().split(":")[1];
    var beanId = parseInt($("#beanId").val());
    var activeStepId = parseInt($("#activeStepId").val());
    var instid = parseInt($("#instId").val());
    var docTitle = $("#framework_title").text();

    if(docTitle==""){
      for(key in pageConfig.controls){
        if(pageConfig.controls[key].type=="title"){
          docTitle=pageForm.getFieldValue(pageConfig.controls[key].id);
          break;
        }
      }
    }
    var docType = $("#docTableTittle").val();
    docType = docType.replace($("#belonged_org_name").val(),"");
    dwrBaseFunctionService.trashFlowForm(formId,beanId,activeStepId,instid,docTitle,docType,{
      callback :function(data){
        if(data && data.result=="1"){
          if(typeof fnTrashFlowCustom == "function"){
            fnTrashFlowCustom($("#instId").val(),$("#beanId").val(),pageForm,pageConfig);
          }
          alert("该文件作废成功!");
          window.opener.location.reload();
          self.close();
        }else{
          alert("该文件作废失败,请重试!");
          return;
        }
      }
    });
  }
}

//阅知
function sendToRead(){
  var deptid= $("#belongedOrgId").val().length==0?"G-1":"G"+$("#belongedOrgId").val();
  var deptname = $("#belonged_org_name").length==0?"组织机构":$("#belonged_org_name").val();
  $().seniorOaExternalUserSelector({
    rootData:{id : deptid, pId : null, name : deptname, isParent : true},
    selection : 'multi',
    tabCfg : 'user,personalusergroup',
    grzCfg : 'yes',
    defaults : [],
    onOkClick : function(result) {
      if(result.length>0){
        var jsonStr = JSON.stringify(result);
        var formId = $("#formId").val();
        var beanId = $("#beanId").val();
        var entryId = parseInt($("#instId").val());
        var stepSerialNumber = parseInt($("#activeStepId").val());
        var flowId = $("#flowId").val();
        var flowName = grcFlowForm.flowName;
        var stepName = grcFlowForm.stepName;
        var fileTitle = grcFlowForm.fileTitle ? grcFlowForm.fileTitle : $("#doc_title").val();
        var appId = "" ;
        var appName = "" ;

        dwrBaseFunctionService.saveSendToReadInfo(jsonStr,formId,beanId,entryId,stepSerialNumber,flowName,stepName,fileTitle,appId,appName,{
          callback :function(data){
            if(data && data.result=="succeed"){
              if(grcFlowForm.readLogController){
                showSendToReadLog();
              }
              alert("知会成功!");
            }else{
              alert("知会失败!");
            }
            return;
          }
        });
      }
    }
  });
}

//提交操作，OA通用校验方法
function oaCommonValidate(){
  //Mac地址绑定校验
  /*var macAddrConfig = grcFlowForm.macAddress;
  if(macAddrConfig!=""){
    if($("#ifrGetRemoteMacAddr").contents().find("#userMacAddr").val()==""){
      $.tip('无法获取当前电脑Mac地址（疑为浏览器ActiveX控件未启用），不能进行该操作！');
      return false;
    }
    var currMacAddr = $("#ifrGetRemoteMacAddr").contents().find("#userMacAddr").val();
    if(macAddrConfig!=currMacAddr){
      $.tip('当前电脑Mac地址与系统维护的Mac地址不一致，不能进行该操作！');
      return false;
    }
  }*/

  var fnSetPriorityExtFun = "oaSetPriorityCustomFun";
  if(typeof window[fnSetPriorityExtFun] =="function" ){
    eval(fnSetPriorityExtFun+"()");
  }
  if(cp_oaBasicInfo.cp_stepName=="开始" || cp_oaBasicInfo.cp_stepName=="起草"){
    var beanId = $("#beanId").val() ;
    var formId = $("#formId").val().split(":")[1] ;
    var docNum = null ;
    if(beanId != "" && beanId != null){
      dwrOaDocNumberProjectService.getNumberInfo(beanId,formId,
          {callback:function(ret){
              if(ret!="null"){
                docNum = JSON.parse(ret).docNum;
              }
            },async:false
          });
    }

    if((cp_oaBasicInfo.cp_flowNodeAttrs.autoNumber||cp_oaBasicInfo.cp_flowNodeAttrs.editNumber) && docNum == null){
      controlMenu.actionId.val(controlMenu.saveActionId.val());
      baseDocBusinessTypeId = $("#docType").val()||$("#doc_type").val()||"";
      var dataSeri = controlMenu.form.serializeArray();
      dwrOaDocNumberProjectService.autoSaveDocNumber($("#formId").val(),  $("#beanId").val(), pageConfig.currentUserInfo.currentUserDeptId,
          pageConfig.currentUserInfo.currentUserAccount,baseDocBusinessTypeId,"",dataSeri,{callback:function(data){
              //location.href = location.href;
              if(data.data.error != "true"){
                $("#oanumber").val(JSON.parse(data.data.fields).oanumber);
                pageForm.setFieldValue("oanumber",JSON.parse(data.data.fields).oanumber);
                if($("#oashow").length>0){
                  $("#oashow").css("display","none");
                }
                $("#oanumber").css("display","");
                $("#status").css("display", "none");
                $("#aftFix").css("display", "none");
                if(data.data.error != undefined && data.data.error != null && data.data.error != ""){
                  alert(data.data.errorMsg);
                  return;
                }
                var step = data.currentSteps[0];
                controlMenu.entryId.val(step[0]);
                controlMenu.currentStepId.val(step[1]);
                $("#instId").val(step[0]);
                $("#currentStepId").val(step[1]);
                if($("#beanId") != undefined){
                  $("#beanId").val(JSON.parse(data.data.fields).beanId);
                }
                if($("#id") != undefined){
                  $("#id").val(JSON.parse(data.data.fields).beanId);
                }
                controlMenu.mode.val('EDIT');
                controlMenu.actionId.val('');
                if (typeof (pageForm) !== 'undefinded') {
                  pageForm.setFieldValues(ret.data.fields);
                  pageForm.saveFieldValues();
                }
              }
            },async:false})
    }
  }
  return true;
}

//阅知日志表格
function renderReadLog(data){
  var arr = [];
  arr.push('<div id="sendtoreadlogdiv" class="panel panel-default">');
  arr.push('<div class="panel-heading" style="display:none;">');
  arr.push('<h4 class="panel-title">');
  arr.push('<a class="accordion-toggle" href="#currentList" data-toggle="collapse" data-parent="#accordion">知会记录</a>');
  arr.push('</h4>');
  arr.push('</div>');
  arr.push('<div class="panel-collapse collapse in" id="currentList">');
  arr.push('<div class="panel-body">');
  arr.push('<table id="" class="table_border table-condensed">');
  arr.push('<thead>');
  arr.push('<tr>');
  arr.push('<th width="">序号</th>');
  arr.push('<th width="">发送人</th>');
  arr.push('<th width="">发送时间</th>');
  arr.push('<th width="">接收人</th>');
  arr.push('<th width="">阅读状态</th>');
  arr.push('<th width="">阅读时间</th>');
  arr.push('</tr>');
  arr.push('</thead>');
  arr.push('<tbody>');

  for(var i = 0;i < data.length;i ++){
    var sendTime = FlowForm.format(data[i].sendTime,"yyyy-MM-dd hh:mm:ss");
    var isRead = data[i].isRead==0?"未读":"已读";
    var readTime = data[i].readTime==null?"":FlowForm.format(data[i].readTime,'yyyy-MM-dd hh:mm:ss');

    arr.push('<tr rowindex="'+i+'" id="'+data[i].id+'">');
    arr.push('<td colindex="0" model="num">'+(i+1)+'</td>');
    arr.push('<td colindex="1" model="CREATOR_NAME">'+data[i].creatorName+'</td>');
    arr.push('<td colindex="1" model="send_time">'+sendTime+'</td>');
    arr.push('<td colindex="1" model="user_name">'+data[i].userName+'</td>');
    arr.push('<td colindex="1" model="is_read">'+isRead+'</td>');
    arr.push('<td colindex="1" model="read_time">'+readTime+'</td>');
    arr.push('</tr>');
  }

  arr.push('</tbody>');
  arr.push('</table>');
  arr.push('</div>');
  arr.push('</div>');
  arr.push('</div>');
  return arr.join("\n");
}

function timejsonToTime(timejson){
  var year = (1900+timejson.year)+"";
  var month = timejson.month+1;
  month = month>9?(month+""):("0"+month);
  var day = timejson.day;
  day = day>9?(day+""):("0"+day);
  var hours = timejson.hours;
  hours = hours>9?(hours+""):("0"+hours);
  var minutes = timejson.minutes;
  minutes = minutes>9?(minutes+""):("0"+minutes);
  var seconds = timejson.seconds;
  seconds = seconds>9?(seconds+""):("0"+seconds);
  return year+"-"+month+"-"+day+" "+hours+":"+minutes+":"+seconds;
}

//显示阅知记录对话框
function sendToReadLog(){
  $.seniorDialog({
    title : "知会记录 ",
    height : '310',
    contentId:"sendtoreadlogdiv",
    buttons : [ {
      label : "确定",
      clazz : "btn-primary",
      click : function(modalDialog, evt) {
        modalDialog.modal('hide');
      },
      autoClose : false
    }, "cancel" ],
    autoDestroy:true
  });
}

//显示阅知记录
function showSendToReadLog(){
  grcFlowForm.hasReadLog = false;
  dwrBaseFunctionService.findSendToReadLogsByParam($("#formId").val(),$("#beanId").val(),
      { callback: function(data){
          if(data && data.length > 0){
            if($("#sendtoreadlogdiv")[0]){$("#sendtoreadlogdiv").remove();}
            $("#saveActionId").after(renderReadLog(data));
            grcFlowForm.hasReadLog = true;
          }
        }
      });

  if(grcFlowForm.hasReadLog && !$("#sendtoreadlog")[0]){
    $('#control2_view').append(
        $('<button type="button" class="btn btn-default" id="sendtoreadlog" onclick="sendToReadLog();">知会记录</button>').fadeIn(300)
    );
  }
}

//公文评价
var evaMap = new Map();
function docEvaluation(){
  javascript:dwr.engine.setAsync(false);
  dwrBaseFunctionService.findEvaluationConfigListByParam(
      { callback: function(data){
          if(data && data.length > 0){
            data = sortBySortNumber(data);
            renderDocEvaluation(data);
          }
        }
      });
  javascript:dwr.engine.setAsync(true);
  $.seniorDialog({
    title : "公文评价 ",
    height : '310',
    contentId:"docevaluationdiv",
    buttons : [ {
      label : "确定",
      clazz : "btn-primary",
      click : function(modalDialog, evt) {
        //提交评价
        $.ajax({
          type: 'POST',
          url: contextPath + "/rest/product/oa/evaluationrecord/save",
          async:false,
          data: {
            "beanId":$("#beanId").val(),
            "creatorAccount":pageConfig.currentUserInfo.currentUserAccount,
            "creatorName":pageConfig.currentUserInfo.currentUserName,
            "createDeptId":pageConfig.currentUserInfo.currentUserDeptId,
            "createDeptName":pageConfig.currentUserInfo.currentUserDeptName,
            "fileTitle":grcFlowForm.fileTitle,
            "fraction":$(".modal-body [name='fldzjdf']").val(),
            "deductionItem":JSON.stringify(getDeductionItem()),
            "fileLink":"/bpm/view.htm?instId="+grcFlowForm.parentFlowEntryId,
            "partDeptId":$("#create_dept_id")[0] ? $("#create_dept_id").val() : "",
            "partDeptName":$("#create_dept_name")[0] ? $("#create_dept_name").val() : "",
            "deductionNumber":evaMap.get("deductionNumber"),
            "flowId":$("#flowId").val()
          },
          success: function (data) {
            //console.log(data)
            if(data.stat=="success"){

              alert("评价成功！");
              //评价完毕隐藏
              $("#evaluation").hide();
              $('#control2_view').append(
                  $('<button type="button" class="btn btn-default" id="btnViewEva" onclick="viewEvaluation();">查看公文评价</button>').fadeIn(300)
              );
            }else{
              alert("评价失败！");
            }
          }
        });
        modalDialog.modal('hide');
      },
      autoClose : false
    }, "cancel" ],
    autoDestroy:true
  });
}

function getDeductionItem(){
  var arr = $("[name='fldkoufenxiang']:checked");
  var res = [];
  for(var i = 0;i < arr.size();i ++){
    var tmp = {};
    tmp.index = i+1;
    tmp.id = arr[i].value;
    tmp.deductionName = evaMap.get(arr[i].value);
    res.push(tmp);
  }
  return res;
}

function renderDocEvaluation(data){
  var arr = [];
  arr.push('<div id="docevaluationdiv" class="dialog_msg">');
  arr.push('<table width="100%" align="center" border="0">');
  arr.push('<tbody>');
  arr.push('<tr height="25px"><td style = "text-align-last: center;"><b><span data-string-id="indiplatform.gwpj.wdbt">文档标题：</span></b></td><td width="420px"><span id="biaoti" align="left">'+grcFlowForm.fileTitle+'</span></td></tr>');
  arr.push('<tr height="25px"><td style = "text-align-last: center;border-right:0px;"><b><span data-string-id="indiplatform.gwpj.kfxm">扣分项目：</span></b></td><td style="border-left: 0px;"></td></tr>');
  arr.push('<tr>');
  arr.push('<td colspan="2">');
  var total = 0;
  for(var i = 0;i < data.length;i ++){
    evaMap.put(data[i].id+"",data[i].deductionName);
    arr.push('<label>');
    arr.push('<input type="checkbox" name="fldkoufenxiang" value="'+data[i].id+'" onclick="fnJiSuan(this,'+data[i].fraction+')">');
    arr.push((i+1)+'、'+data[i].deductionName+'(减'+data[i].fraction+'分)');
    arr.push('</label><br />');
    total += parseFloat(data[i].fraction);
  }
  arr.push('</td>');
  arr.push('</tr>');
  arr.push('<tr height="25px"><td style = "text-align-last: center;"><b><span data-string-id="indiplatform.gwpj.zjdf">总计得分：</span></b></td><td><input name="fldzjdf" value="'+total+'" size="2" onfocus="this.blur();"><span data-string-id="indiplatform.gwpj.fen">分</span></td></tr>');

  arr.push('</tbody>');
  arr.push('</table>');
  arr.push('</div>');
  if($("#docevaluationdiv")[0]){$("#docevaluationdiv").remove();}
  $("#saveActionId").after(arr.join("\n"));
}

function sortBySortNumber(arr){
  var colId="sortNumber";
  //对json进行升序排序函数
  var asc = function(x,y)
  {
    return (x[colId] > y[colId]) ? 1 : -1
  }
  return arr.sort(asc);
}

function fnJiSuan(ele,fraction){
  var total = $(".modal-body [name='fldzjdf']").val();
  var res;
  if(ele.checked){
    res = parseFloat(total)-parseFloat(fraction);
    //扣分数
    if(evaMap.contain("deductionNumber")){
      var deductionNumber = evaMap.get("deductionNumber");
      evaMap.put("deductionNumber",(parseFloat(deductionNumber)+parseFloat(fraction))+"");
    }else{
      evaMap.put("deductionNumber",fraction);
    }
  }else{
    res = parseFloat(total)+parseFloat(fraction);
    //扣分数
    var deductionNumber = evaMap.get("deductionNumber");
    evaMap.put("deductionNumber",(parseFloat(deductionNumber)-parseFloat(fraction))+"");
  }
  $(".modal-body [name='fldzjdf']").val(res);
}

function viewEvaluation(){
  if(grcFlowForm.docEvaluationId == ""){
    dwr.engine.setAsync(false);
    dwrBaseFunctionService.findEvaluationRecordListByParam(parseInt($("#beanId").val()),$("#flowId").val(),
        { callback: function(data){
            if(data && data.length > 0){
              grcFlowForm.hasDocEvaluation = true;
              grcFlowForm.docEvaluationId = data[0].id;
            }
          }
        });
    dwr.engine.setAsync(true);
  }

  window.open("/wp/oaEvaluationRecord/oaEvaluaEecordEdit.htm?id="+grcFlowForm.docEvaluationId);
}

//待办通知方式
function oaMessageRemindCustomFun(successors){
  var sendSMS = $("#messageRemindSMS")[0].checked;
  var sendMail = $("#messageRemindMail")[0].checked;
  if(sendSMS || sendMail){
    $.ajax({
      type: 'POST',
      url: contextPath+"/bpm/product/oa/messageRemind",
      async:true, //异步取值
      data: {
        "formId": $("#formId").val(),
        "beanId": $("#beanId").val(),
        "flowId": $("#flowId").val(),
        "instId": $("#instId").val(),
        "sendSMS": sendSMS,
        "sendMail": sendMail,
        "successors": successors
      },
      success: function (data) {
        return;
      }
    });
  }

  if(OASM=="true"){
    var zwId = "";
    var zwName = "";
    var hjgId = "";
    var hjgName = "";
    var idType = "id";

//		var z = cp_oaBasicInfo.cp_hdOaDispatchList.data[0].ATTACH;//	.parseJSON();
//
//		/*alert(z.length);*/
//		var zw = JSON.parse(z);
//
//		/*alert(zw.length);*/
//		for(var i=0;i<zw.length;i++) {
//			if(zw[i].category == "ZW") {
//				if(zw[i].id==0) {
//					hjgId = zw[i].tmpfileId;
//					idType = "tmp";
//				}else {
//					hjgId = zw[i].id;
//				}
//				hjgName = zw[i].name;
//			}
//			if(zw[i].category == "QG") {
//				if(zw[i].id==0) {
//					zwId = zw[i].tmpfileId;
//					idType = "tmp";
//				}else {
//					zwId = zw[i].id;
//				}
//				zwName = zw[i].name;
//			}
//		}
    var indidocgroupid=document.getElementById("indidocgroupid").value;
    var attachmentsId = document.getElementById(indidocgroupid).value;
    $.ajax({
      type: 'POST',
      url: contextPath+"/rest/oainterface/businessSecret/makeAllBusinessSecretFileById",
      async:true, //异步取值
      data: {
        "zwId": zwId,
        "zwName": zwName,
        "attachmentsId": attachmentsId,
        "hjgId": hjgId,
        "hjgName": hjgName,
        "idType": idType
      },
      success: function (data) {
        return;
      }
    });
  }
}

//待阅变已阅
function updateReadToReaded(){
  var id = FlowForm.getQueryString(location.href,"id");
  var isMs = FlowForm.getQueryString(location.href,"isMs");
  //获取待阅中的意见
  var opinion;
  if($("#gjisMS_sign").val()!=""){
    opinion = JSON.parse($("#gjisMS_sign").val());
    dwrBaseFunctionService.updateReadedById(parseInt(id),parseInt(isMs),opinion.signContent,{
      callback :function(data){
        $(window).unbind('beforeunload');
        alert("您已经阅读完此待阅项！");
        location.href = location.href.replace("&mode=sendtoread","");
        window.close();
        return;
      }
    });
  }else{
    dwrBaseFunctionService.updateReadedById(parseInt(id),parseInt(isMs),"",{
      callback :function(data){
        $(window).unbind('beforeunload');
        alert("您已经阅读完此待阅项！");
        location.href = location.href.replace("&mode=sendtoread","");
        window.close();
        return;
      }
    });
  }

}

//管理员撤转---现改名在【特送】
function adminReshuffle(){
  var id = $("#instId").val();
  var userTree = null;
  var curUser = {};
  curUser.id = pageConfig.currentUserInfo.currentUserId;
  $.seniorDialog({title:"特送",buttons:[{label:"确定", click:function(dialog){
        var fnSetPriorityExtFun = "oaSetPriorityCustomFun";
        if(typeof window[fnSetPriorityExtFun] =="function" ){
          eval(fnSetPriorityExtFun+"()");
        }
        var currentStepId = dialog.find("#currentStepId").val();
        var tagetStepId = dialog.find("#step").val();
        var selectedOperator = userTree.getCheckedNodes(true);
        var steptype = $('#stepPanel select').find("option:selected").attr("steptype");
        var isEnd = (steptype=="结束");
        var isStart = (steptype=="起始");
        (isStart || isEnd) && (selectedOperator.length = 0);
        if(!currentStepId || !tagetStepId || (selectedOperator.length ==0 && !isEnd && !isStart)) {
          $.tip("请选择数据！");
          return;
        }
        var operators = [];
        if(isStart){
          operators.push({
            $dwrClassName: 'OperatorBean',
            type : 'User',
            code : $("#creatorAccount").val(),
            name : $("#creatorName").val()
          });
        }else{
          for(var i = 0; i < selectedOperator.length;i++){
            operators.push({
              $dwrClassName: 'OperatorBean',
              type : 'User',
              code : selectedOperator[i].attrs.props.account,
              name : selectedOperator[i].name
            });
          }
        }
        //console.log(id);
        //console.log(currentStepId);
        //console.log(tagetStepId);
        //console.log(operators);

        //Formdat
        var formDataArray = new Array();
        var priority = new Object();
        priority['name'] = "priority" ;
        priority['value'] = $("#priority").val();
        formDataArray.push(priority);

        dwrWorkflowListService.interveneToStep(id, currentStepId, tagetStepId, operators,formDataArray, {
          callback : function(ret) {
            tipAndClose();
          },
          exceptionHandler : function(errorString, exception) {
            $.tip("error");
          },
        });
        dialog.modal("hide");
      }},"cancel"],onload:function(dialog){
      dialog.find(".modal-body").append($.templates("#interfereStepDialog").render());
      dwrWorkflowListService.getCurrentSteps(id,function(ret){
        if(ret.length==0){
          var newret = {};
          newret["id"]="0";
          newret["stepName"]="结束";
          ret.push(newret);
        }
        dialog.find("#currentStepPanel").append('<div id="currentStepIddiv" style="height: 30px; padding: 5px;"><span>'+ret[0].stepName+'</span><input type="hidden" id="currentStepId" value="'+ret[0].id+'" /></div>');
      });
      dwrWorkflowListService.getEntryStepDescriptorList(id,function(ret){
        dialog.find("#stepPanel").append($.templates("<select id=\"step\" name=\"step\" class=\"form-control\"><option value=\"\"></option>{{for options}}<option value=\"{{:stepId}}\" steptype=\"{{:type}}\">{{:name}}</option>{{/for}}</select>")
            .render({options:ret}));

        dialog.find("#stepPanel select").change(function(opt1){
          var steptype = $('#stepPanel select').find("option:selected").attr("steptype");
          if(steptype==="结束"){
            $("#operator").parent().parent().hide();
          }else{
            $("#operator").parent().parent().show();
            if(steptype==="起始"){
              $("#operator").hide();
              $("#span_operator_draftor").show();
            }else{
              $("#span_operator_draftor").hide();
              $("#operator").show();
            }
          }
        });

      });
//		设置层级权限过滤
      var rootId= $("#belongedOrgId").length==0?"G-1":"G"+$("#belongedOrgId").val();
      var rootName = $("#belonged_org_name").length==0?"组织机构":$("#belonged_org_name").val();

      userTree = dialog.find("#operator").dwrTree({
        dwrCall:tenantService.getTenantUserTreeNodes,
        baseParam: [ 'GU', 'weight asc' ],
        autoParam: ['id'],
        expandedLevel:2,
        setting:{
          check: {
            enable: true,
            chkStyle: "checkbox",
            radioType: "all"
          },
          async:{
            dataFilter:function(treeId, parentNode, newNodes) {
              //var userId = 'U' + curUser.id;
              for(var i = 0, l = newNodes.length; i < l; i++) {
                var node = newNodes[i];
                if(!node.id.startsWith("U")) {
                  node.nocheck = true;
                }
                /* if(node.id == userId) {
                     node.checked = true;
                 }*/
              }
              return newNodes;
            }
          }
        },
        data:[{id: rootId,name: rootName,isParent: true,nocheck: true}]
      });
      dialog.find("#operator").parent().append("<div id='span_operator_draftor' style='display:none;height: 30px;padding: 5px;'><span >"+$("#creator_name").val()+"</span></div>");


    }});
}

//全权限编辑公文
function fullAuthEdit(){
  var url = location.href;
  if(url.indexOf("edit.htm")!=-1){
    url = url.replace("edit.htm","fullAuthEdit.htm");
  }else if(url.indexOf("view.htm")!=-1){
    url = url.replace("view.htm","fullAuthEdit.htm");
  }
  location.href = url;
}

function tipAndClose(){
  var sec = 3;
  var info = "撤转成功！";
  $.tip(info + '</br>' + sec + '秒后自动关闭', sec* 10000);
  setInterval(function(){
    if(sec>0){
      sec--;
      $('.message .bg-info').html(info + '</br>'+ sec+ '秒后自动关闭')  //更新提示信息
    }

  },1000);
  if (window.opener) {
    if(jQuery.isFunction(window.opener.fnGetSiteMenu)){
      window.opener.getSiteByClick('CONSOLE');
    }else if(jQuery.browser.versionNumber <= 8 && typeof(opener.fnGetSiteMenu) !== "undefined"){
      //增加针对IE8的父页面刷新
      opener.getSiteByClick('CONSOLE');
    }else{
      //增加针对不是从个人工作台打开的待办列表页面刷新
      window.opener.location.href = window.opener.location.href ;
    }

    setTimeout(function() {
      window.opener = window;
      //判断是chrome浏览器
      if(jQuery.browser.name === 'chrome'){
        window.location.href = "about:blank";
      }
      window.close();
    },sec*1050);
  }
}

function getInterfereStepDialog(){
  var html = [];
  html.push('<script id="interfereStepDialog" type="text/x-jsrender">');
  html.push('<form action="#" class="form-horizontal">');
  html.push('<div class="form-group">');
  html.push('<label class="col-md-3 control-label">当前处理环节</label>');
  html.push('<div class="col-md-6">');
  html.push('<div id="currentStepPanel"></div>');
  html.push('</div>');
  html.push('</div>');
  html.push('<div class="form-group">');
  html.push('<label class="col-md-3 control-label">调整后处理环节</label>');
  html.push('<div class="col-md-6">');
  html.push('<div id="stepPanel"></div>');
  html.push('</div>');
  html.push('</div>');
  html.push('<div class="form-group">');
  html.push('<label class="col-md-3 control-label">调整后处理人</label>');
  html.push('<div class="col-md-6">');
  html.push('<div id="operator"></div>');
  html.push('</div>');
  html.push('</div>');
  html.push('</form>');
  html.push('</script>');
  return html.join("\n");
}

//获取url中的参数
function getUrlParam(name){
  // 用该属性获取页面 URL 地址从问号 (?) 开始的 URL（查询部分）
  var url = window.location.search;
  // 正则筛选地址栏
  var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
  // 匹配目标参数
  var result = url.substr(1).match(reg);
  //返回参数值
  return result ? decodeURIComponent(result[2]) : null;
}

//关注
function attentionFlowForm(){
  dwrBaseFunctionService.createAttention($("#instId").val(),$("#formId").val(),{callback:function(){
      $.tip("关注成功");
    }
  });
  $("#myAttention").remove();
  //$('button[cmd="product$myAttention"]').remove();
  $('#control2_view').append('<button type="button" class="btn btn-default" id="myAttentionCancel" onclick="cancelAttentionFlowForm();">取消关注</button>');
}

//取消关注
function cancelAttentionFlowForm(){
  dwrBaseFunctionService.cancelAttention($("#instId").val(),$("#formId").val(),{callback:function(){
      $.tip("取消关注成功");
    }
  });
  $("#myAttentionCancel").remove();
  //$('button[cmd="product$myAttentionCancel"]').remove();
  $('#control2_view').append('<button type="button" class="btn btn-default" id="myAttention" onclick="attentionFlowForm();">关注</button>');
}

//富文本控件补丁
function richTextFieldPatch(){
    $(".rs_ed_editor_iframe").each(function(i){
      var head = $(this).contents().find('head');
  	  var body = $(this).contents().find('body');
  	  head.html('<link type="text/css" rel="stylesheet" href="/resources/lib/hd/widget/css/editor.css">');
  	  body.attr("class","rs_ed_scroll");
    })
}

function creatSign(){

}

/**
 * 格式化时间
 * @param fmt
 * @param date
 * @returns
 */
function dateFtt(fmt,date){
  var o = {
    "M+" : date.getMonth()+1,                 //月份
    "d+" : date.getDate(),                    //日
    "h+" : date.getHours(),                   //小时
    "m+" : date.getMinutes(),                 //分
    "s+" : date.getSeconds(),                 //秒
    "q+" : Math.floor((date.getMonth()+3)/3), //季度
    "S"  : date.getMilliseconds()             //毫秒
  };
  if(/(y+)/.test(fmt))
    fmt=fmt.replace(RegExp.$1, (date.getFullYear()+"").substr(4 - RegExp.$1.length));
  for(var k in o)
    if(new RegExp("("+ k +")").test(fmt))
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
  return fmt;
}
