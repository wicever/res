/**
 * OA编号
 *
 * 扩展函数：numberStyleSettingCustom
 * 用途：可用于自定义编号相关配置参数。如：编号样式、年份、编号位长度。
 * 样例：
    function numberStyleSettingCustom(oaNumberPlugin){
         //编号样式
         oaNumberPlugin.settings.numberStyle = "FW";
         //编号位长度
         oaNumberPlugin.settings.numberLength  = "3";
         //年份
         oaNumberPlugin.settings.year  = "2018";
         //编号规则,以下规则结果：FW〔2018〕001
         oaNumberPlugin.settings.numberRule  = "{STYLE}{BEFORE}{YEAR}{AFTER}{NUMBER}";
         //样式前缀
         oaNumberPlugin.settings.beforeStyle  = "〔";
         //样式后缀
         oaNumberPlugin.settings.afterStyle  = "〕";
         //获取编号事件，如：非流程、流程页面加载成功事件：oa.page.load.ready
         oaNumberPlugin.settings.getEvent  = "oa.page.load.ready";
         //更新编号事件,如:流程提交成功事件：after.workflow.doApprove，非流程保存成功事件：after.workflow.ajaxSubmitPageflowForm
         oaNumberPlugin.settings.updateEvent  = "after.workflow.doApprove";
    }
 */

(function($) {
  "use strict";
  if ($.fn.oaNumber) {
    return;
  }

  $.fn.oaNumber = function(options) {
    var opts = $.extend({}, $.fn.oaNumber.defaults, options);
    return this.each(function() {
      var $this = $(this);
      var f = $this.data('hdWidget');
      if (!f) {
        f = new oaNumberPlugin(this, opts);
        f._init();
        $this.data('hdWidget', f);
      }
      return f;
    });
  };

  $.fn.oaNumber.defaults = {

  };

  var oaNumberPlugin = function(element, options) {
    this.element = element;
    this.el = $(this.element);
    this.settings = options || {};
  };
  oaNumberPlugin.prototype._init = function() {


    if(this.settings.readonly !== true) {
      this.el.addClass('form-control');
    } else {
       this.el.addClass('form-control-static');
    }
    $(this.el).attr("readOnly","readOnly");

    if(typeof(numberStyleSettingCustom) == "function"){
      numberStyleSettingCustom(this);
    }
    var formId = $("#formId").val();
    var uuid = $("#uuid").val()||$("#ds1\\$uuid").val();
    var numberStyle = this.settings.numberStyle;
    var numberLength = this.settings.numberLength;
    var year = new Date().getFullYear();
    var oaNumber = 0;
    if(this.settings.year!==undefined){
      year = this.settings.year;
    }
    var numberRule = this.settings.numberRule;
    var beforeStyle = this.settings.beforeStyle;
    var afterStyle = this.settings.afterStyle;
    var getEvent = this.settings.getEvent;
    var updateEvent = this.settings.updateEvent;

    self = this;
    var id = this.getUrlParam("id")
    var instId = this.getUrlParam("instId");
    //只有新建才获取编号更新编号
    if(id==null && instId==null){
      //获取编号
      $(document).on(getEvent,function(){
        uuid = $("#uuid").val()||$("#ds1\\$uuid").val();
        //获取编号
        oaNumber = self.getNonFlowNumber(formId,uuid,numberStyle,year);
        if(oaNumber.toString()!=""){
          // oaNumber = parseInt(oaNumber)+1
          //设置编号长度位数不足补0
          var fullNumber = self.PrefixInteger(parseInt(oaNumber),parseInt(numberLength));
          //安装规则处理编号
          var theNumber = numberRule.replace(/{STYLE}/g,numberStyle).replace(/{BEFORE}/g,beforeStyle).replace(/{YEAR}/g,year).replace(/{AFTER}/g,afterStyle).replace(/{NUMBER}/g,fullNumber);
          //设置编号值
          self.setValue(theNumber);
        }
      })

      //更新编号
      $(document).on(updateEvent,function(event, cbscope, retdata) {
        if(retdata.success==true||retdata.fields!==undefined){
          oaNumber = self.getNonFlowNumber(formId,uuid,numberStyle,year);
          self.saveNonFlowNumber(formId,uuid,numberStyle,year,oaNumber);
        }
      })

    }


  };

  oaNumberPlugin.prototype.getValue = function() {
    return this.el.val();
  };

  oaNumberPlugin.prototype.setValue = function(value) {
    this.el.val(value);
  };

  oaNumberPlugin.prototype.getNonFlowNumber = function(formId,beanId,key,year) {
    var maxNum = "";
    dwrOaDocNumberService.findMaxNumByNumConfigId(formId,beanId,key,year,{
      callback:function(ret){
        maxNum = ret;
      },
      exceptionHandler : function(errorString, exception) {
        $.tip("编号获取失败，请联系管理员！");
        return;
      },async:false
    });
    return maxNum;
  };

  oaNumberPlugin.prototype.saveNonFlowNumber = function(formId,beanId,key,year,number) {
    dwrOaDocNumberService.autoSaveDocNumberByNonFlow(key,formId,beanId,year,number,{
      callback:function(ret){
        console.log("编号保存成功，目前最新编号："+ret);
      },
      exceptionHandler : function(errorString, exception) {
        $.tip("编号保存失败，请联系管理员！");
        return;
      }
    });
  }

  oaNumberPlugin.prototype.PrefixInteger = function(num, length) {
    return (Array(length).join('0') + num).slice(-length);
  }

  //获取url中的参数
  oaNumberPlugin.prototype.getUrlParam = function(name){
    // 用该属性获取页面 URL 地址从问号 (?) 开始的 URL（查询部分）
    var url = window.location.search;
    // 正则筛选地址栏
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    // 匹配目标参数
    var result = url.substr(1).match(reg);
    //返回参数值
    return result ? decodeURIComponent(result[2]) : null;
  }

  $.hdFormFieldFactory.register('input', 'oaNumber', function(cfg, control, pageConfig) {
    var config = $.extend({}, cfg);
    var viewId = config.renderTo.replace(/\$/g, '\\$');
    if (config.validateActions) {
      config.validateActions = config.validateActions.split(',');
    }
    config.lang = lang;
    $('#' + viewId).oaNumber(config);
    return $('#' + viewId).data('hdWidget');
  });

})(jQuery);