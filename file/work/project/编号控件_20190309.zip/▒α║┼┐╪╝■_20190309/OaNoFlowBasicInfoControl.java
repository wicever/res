package com.hd.rcugrc.product.oa.widget.form;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.hd.rcugrc.form.dao.model.impl.ModelFormInfoBean;
import com.hd.rcugrc.page.engine.ControlPropertyValue;
import com.hd.rcugrc.page.engine.CustomControl;
import com.hd.rcugrc.page.widget.form.AbstractFormControl;
import com.hd.rcugrc.security.context.AuthenticationHelper;
import com.hd.rcugrc.security.hierarchy.service.HierarchySwitchService;

public class OaNoFlowBasicInfoControl extends AbstractFormControl {

	private HierarchySwitchService hierarchySwitchService;
	
	public HierarchySwitchService getHierarchySwitchService() {
		return hierarchySwitchService;
	}

	public void setHierarchySwitchService(HierarchySwitchService hierarchySwitchService) {
		this.hierarchySwitchService = hierarchySwitchService;
	}
	
	@Override
	protected void outputWriteableControlHtml(Map<String, Object> context, Map<String, Object> localContext,
			CustomControl control, Map<String, ControlPropertyValue> props, PrintWriter writer) throws Exception {
		//布局页面
		String layoutUrl = (String) getPropValue(props,"layoutUrl","");
		if(!"".equals(layoutUrl)){
			writer.print("<style>");
			writer.print(".form-horizontal{display:none;}\n");
			writer.print("</style>");
		}
		writer.print("<script>");
		//分级授权所属机构
		long cp_belongedOrgId = -1;
		String account = AuthenticationHelper.getCurrentUser();
		com.hd.rcugrc.security.user.Group group = hierarchySwitchService.findHierarchyGroupIdByUser(account);
		if(group != null){
			cp_belongedOrgId = group.getId();
		}
		writer.print("cp_belongedOrgId = " + cp_belongedOrgId + ";\n");

		//获取表单id
        Map<String,Object> formsMap = (Map<String,Object>) context.get("forms");
        //ModelFormInfoBean form = (ModelFormInfoBean) formsMap.entrySet().iterator().next();
        String formKey = "";
        for (Map.Entry<String, Object> entry : formsMap.entrySet()) {
            formKey = entry.getKey();
            if (formKey != null) {
                break;
            }
        }

		if(!"".equals(layoutUrl)){
			writer.print("$.jsRenderTemplate.register({"+
							"id:\"template.noflowform.layout\","+
							"url:\""+layoutUrl+"\""+
						"});");
		}
		writer.print("</script>");

        ModelFormInfoBean form = (ModelFormInfoBean) formsMap.get(formKey);
        String formId = form.getId();
        writer.print("<input id=\"formId\" name=\"formId\" value=\"model:"+formId+"\" type=\"hidden\">");
	}

}
