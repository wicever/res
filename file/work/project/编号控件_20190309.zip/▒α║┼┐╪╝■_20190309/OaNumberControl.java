/*
 * Copyright 2013-2019 Smartdot Technologies Co., Ltd. All rights reserved.
 * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 */
package com.hd.rcugrc.product.oa.widget.form;

import com.hd.rcugrc.page.engine.ControlPropertyValue;
import com.hd.rcugrc.page.engine.CustomControl;
import com.hd.rcugrc.page.widget.form.AbstractFormControl;
import com.hd.rcugrc.page.widget.form.FieldInfo;
import org.apache.commons.lang3.StringUtils;

import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <p>基于jquery的OA编号控件
 *
 * @author <a href="mailto:songjw@smartdot.com.cn">JiWen</a>
 * @version 1.0, 2019-03-06
 */
public class OaNumberControl extends AbstractFormControl {


    @Override
    protected void outputWriteableControlHtml(Map<String, Object> context,
                      Map<String, Object> localContext, CustomControl control,
                      Map<String, ControlPropertyValue> props, PrintWriter writer) throws Exception {
        String id = control.getId();
        Map<String, String> attrs = new LinkedHashMap<String, String>();
        generateWriteableStyleAttr(context, localContext, control, props, attrs);
        attrs.put("id", id);
        attrs.put("name", id);

        String inputType = (String) getPropValue(props, "inputType");
        if (StringUtils.isEmpty(inputType)) {
            inputType = "text";
        }
        attrs.put("type", inputType);

        String emptyText = (String) getPropValue(props, "emptyText");
        if (!StringUtils.isEmpty(emptyText)) {
            attrs.put("placeholder", emptyText);
        }
        attrs.put("value", getControlValue(context, localContext, control, props, attrs));
        writer.print("<input");
        outputControlAttrs(attrs, writer);
        writer.print(" >");
    }

    @Override
    protected void afterOutputWriteableControlHtml(Map<String, Object> context,
                                                   Map<String, Object> localContext, CustomControl control,
                                                   Map<String, ControlPropertyValue> props, PrintWriter writer)
            throws Exception {
        FieldInfo field = getFieldInfo(context, localContext, control, props);
        // 设定需要传递到client端的配置参数
        Map<String, Object> rules = new LinkedHashMap<String, Object>();
        if (field.isMandatory()) {
            rules.put("required", true);
        }
        Integer maxLength = (Integer) getPropValue(props, "maxLength");
        if (maxLength != null && maxLength != 0
                && maxLength != Integer.MAX_VALUE) {
            rules.put("maxlength", maxLength);
        }
        Integer minLength = (Integer) getPropValue(props, "minLength");
        if (minLength != null && minLength != 0) {
            rules.put("minlength", minLength);
        }
        String regex = (String) getPropValue(props, "regex");
        if (!StringUtils.isEmpty(regex)) {
            rules.put("regex", regex);
        }
        String validator = (String) getPropValue(props, "validator");
        if (!StringUtils.isEmpty(validator)) {
            String[] names = StringUtils.split(validator, ',');
            for (String name : names) {
                rules.put(name, true);
            }
        }
        if (!rules.isEmpty()) {
            field.setAttr("rules", rules);
        }
        String invalidText = (String) getPropValue(props, "invalidText");
        if (!StringUtils.isEmpty(invalidText)) {
            field.setAttr("messages", invalidText);
        }
        //年份
        String year = (String) getPropValue(props, "year");
        if(!StringUtils.isEmpty(year)){
            field.setAttr("year",year);
        }
        //样式
        String numberStyle = (String) getPropValue(props, "numberStyle");
        if(!StringUtils.isEmpty(numberStyle)){
            field.setAttr("numberStyle",numberStyle);
        }
        //编号位数
        String numberLength = (String) getPropValue(props, "numberLength");
        if(!StringUtils.isEmpty(numberLength)){
            field.setAttr("numberLength",numberLength);
        }
        //编号规则
        String numberRule = (String) getPropValue(props, "numberRule");
        if(!StringUtils.isEmpty(numberRule)){
            field.setAttr("numberRule",numberRule);
        }
        //样式前缀
        String beforeStyle = (String) getPropValue(props, "beforeStyle");
        if(!StringUtils.isEmpty(beforeStyle)){
            field.setAttr("beforeStyle",beforeStyle);
        }
        //样式后缀
        String afterStyle = (String) getPropValue(props, "afterStyle");
        if(!StringUtils.isEmpty(afterStyle)){
            field.setAttr("afterStyle",afterStyle);
        }
        //获取编号事件
        String getEvent = (String) getPropValue(props, "getEvent");
        if(!StringUtils.isEmpty(getEvent)){
            field.setAttr("getEvent",getEvent);
        }
        //更新编号事件
        String updateEvent = (String) getPropValue(props, "updateEvent");
        if(!StringUtils.isEmpty(updateEvent)){
            field.setAttr("updateEvent",updateEvent);
        }



    }

    @Override
    protected Class<?> getValueType(Map<String, Object> context,
                                    Map<String, Object> localContext, CustomControl control,
                                    Map<String, ControlPropertyValue> props) {
        FieldInfo fieldInfo = getFieldInfo(context, localContext, control,
                props);
        String fieldType = fieldInfo.getType();
        if ("long".equals(fieldType)) {
            return Long.class;
        } else if ("int".equals(fieldType)) {
            return Integer.class;
        } else if ("float".equals(fieldType)) {
            return Float.class;
        } else if ("double".equals(fieldType)) {
            return Double.class;
        } else if ("short".equals(fieldType)) {
            return Short.class;
        } else if ("string".equals(fieldType) || "title".equals(fieldType)) {
            return String.class;
        } else {
            return null;
        }
    }
}
