/**
* <p>
* 
* @author <a href="mailto:songjw@smartdot.com.cn">${USER}</a>
* @version 1.0, ${DATE}
*/