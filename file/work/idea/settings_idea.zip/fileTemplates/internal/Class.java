/*
* Copyright 2013-${YEAR} Smartdot Technologies Co., Ltd. All rights reserved.
* SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
*
*/
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* <p>
* 
* @author <a href="mailto:songjw@smartdot.com.cn">${USER}</a>
* @version 1.0, ${DATE}
*/
public class ${NAME} {
}
