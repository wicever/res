var docnum = "";
$(document).ready(function() {
	//根据流程属性配置显示办结反馈按钮  chenqin  start
	if(cp_oaBasicInfo.cp_flowNodeAttrs.overFeedback == "true"){
		var htmlfoot =  '<button type="button" class="btn btn-default" id="overFeedback">办结反馈</button>';
	    $(".processform-layout-foot").append(htmlfoot);
	}
	$("#overFeedback").click(function(){
		var beanId = $("#beanId").val();
    	var formId = $("#formId").val();
    	dwrOaFeedbackService.findByBeanIdAndFormId(beanId,formId,"1",{
    		callback:function(data){
    			if(data == "-1"){
    				$.seniorDialog({title:"办结反馈",size:"",height:"100",buttons:[{label:"反馈",clazz:"btn-primary",click:function(dialog){
    					$("#overFeedback_iframe").contents().find("#save").click(); 
    				    }},{label:"取消",id:"feedbackBtn",click:function(dialog){
					    	dialog.modal('hide')
					    }}],onload:function(dom){
    				    	dom.find(".modal-body").append("<iframe id='overFeedback_iframe' src='/wp/G_1_RECEIPTFEEDBACK/G_1_FEEDBACK.htm?beanId="+beanId+"&formId="+formId+"&type=1' style='width: 100%;height: 95%;border:0px;'></iframe>");
    				    	dom.find(".modal-dialog").css("width","80%");
    				    	dom.find(".modal-body").css("height","300px");
    				    }
    				   });  
    			}else{
    				$.seniorDialog({title:"办结反馈",size:"",height:"100",buttons:[{label:"反馈",clazz:"btn-primary",click:function(dialog){
    					$("#overFeedback_iframe").contents().find("#save").click();
    				    }},{label:"取消",id:"feedbackBtn",click:function(dialog){
					    	dialog.modal('hide')
					    }}],onload:function(dom){
    				    	dom.find(".modal-body").append("<iframe id='overFeedback_iframe' src='/wp/G_1_RECEIPTFEEDBACK/G_1_FEEDBACK.htm?id="+data+"' style='width: 100%;height: 95%;border:0px;'></iframe>");
    				    	dom.find(".modal-dialog").css("width","80%");
    				    	dom.find(".modal-body").css("height","300px");
    				    
    				    }
    				   });  
    			}
    		}
    	});
		
	})
	
	//根据流程属性配置显示办结反馈按钮  chenqin  end
	//根据流程属性配置显示办理反馈按钮  chenqin  start
	if(cp_oaBasicInfo.cp_flowNodeAttrs.handleFeedback == "true"){
		var htmlfoot =  '<button type="button" class="btn btn-default" id="handleFeedback">办理反馈</button>';
	    $(".processform-layout-foot").append(htmlfoot);
	}
	$("#handleFeedback").click(function(){
		var beanId = $("#beanId").val();
    	var formId = $("#formId").val();
		dwrOaFeedbackService.findByBeanIdAndFormId(beanId,formId,"2",{
			callback:function(data){
				if(data == "-1"){
					$.seniorDialog({title:"办理反馈",size:"",height:"100",buttons:[{label:"反馈",clazz:"btn-primary",click:function(dialog){
						$("#handleFeedback_iframe").contents().find("#save").click(); 
					    }},{label:"取消",id:"feedbackBtn",click:function(dialog){
					    	dialog.modal('hide')
					    }}],onload:function(dom){
					    	dom.find(".modal-body").append("<iframe id='handleFeedback_iframe' src='/wp/G_1_RECEIPTFEEDBACK/G_1_FEEDBACK.htm?beanId="+beanId+"&formId="+formId+"&type=2' style='width: 100%;height: 95%;border:0px;'></iframe>");
					    	dom.find(".modal-dialog").css("width","80%");
					    	dom.find(".modal-body").css("height","300px");
					    }
				    }); 
				}else{
					$.seniorDialog({title:"办理反馈",size:"",height:"100",buttons:[{label:"反馈",clazz:"btn-primary",click:function(dialog){
						$("#handleFeedback_iframe").contents().find("#save").click(); 
					    }},{label:"取消",id:"feedbackBtn",click:function(dialog){
					    	dialog.modal('hide')
					    }}],onload:function(dom){
					    	dom.find(".modal-body").append("<iframe id='handleFeedback_iframe' src='/wp/G_1_RECEIPTFEEDBACK/G_1_FEEDBACK.htm?id="+data+"' style='width: 100%;height: 95%;border:0px;'></iframe>");
					    	dom.find(".modal-dialog").css("width","80%");
					    	dom.find(".modal-body").css("height","300px");
					    }
					   }); 
				}
			}
		});
		 
	})
	//根据流程属性配置显示办理反馈按钮  chenqin  end
	//根据流程属性配置显示签收反馈按钮  chenqin  start
	if(cp_oaBasicInfo.cp_flowNodeAttrs.signForFeedback == "true"){
		var htmlfoot =  '<button type="button" class="btn btn-default" id="signForFeedback">签收反馈</button>';
	    $(".processform-layout-foot").append(htmlfoot);
	}
	$("#signForFeedback").click(function(){
		var beanId = $("#beanId").val();
    	var formId = $("#formId").val();
    	dwrOaFeedbackService.sendDianZiGWAccepted(beanId,formId,{
			callback:function(ret){
				if(ret == "true"){
					alert("文件签收成功！");
				}else{
					alert("文件签收失败！");
				}
			}
		})
	})
	//根据流程属性配置显示签收反馈按钮  chenqin  end
  var year = new Date().getFullYear();
  docnum = "〔"+year+"〕号";
  if($("#stepDescriptorIsStart").val()=="true" && $("#instId").val() == "0" && $("#from_number").val()==""){
    $("#from_number").val(docnum);
  }
  //因未知用途 故只增加  pageConfig.id != "G_1_sdyjtChuShiReceipt" && pageConfig.id != "G_1_sdyjtShijvReceipt"判断
  if ($("#stepDescriptorIsStart").val()=="true" && pageConfig.id != "G_1_sdyjtChuShiReceipt" && pageConfig.id != "G_1_sdyjtShijvReceipt") {
    $("#doc_title").on("keyup",function(){$("#action_arr").val($("#doc_title").val())});
    $("#doc_title").val($("#action_arr").val());
  }


	$("#remark").css("margin-left","-15px");
	$("#remark").val("    "+$("#remark").val());
	if(location.href.indexOf("view.htm")!=-1){
		$("#remark_view textarea").css("margin-left","-15px");
		$("#remark_view textarea").val($("#remark").val());
	}
	if($("#attachment_view").find(".files tr").length > 0){
		setTimeout(function(){
			var fileArr = $("#attachment_view").find(".files").find(".name").text().split(".");
			
			if(fileArr[fileArr.length-1].replace(/\s*/g,"") != "pdf"){
				showimg();
			}else{
				showPdf();
			}
		},500);
	}
	//给报、送选人文本域加触发选人事件
	$("#bao_view").on("click",function(){
	
		$("#bao_view").parent().find(".glyphicon-plus").trigger("click");
	})
	
	$("#song_view").on("click",function(){
		
		$("#song_view").parent().find(".glyphicon-plus").trigger("click");
	})
	
	$("#chuanyue_view").on("click",function(){
		
		$("#chuanyue_view").parent().find(".glyphicon-plus").trigger("click");
	})
	
	$("#attachment_view").change(function(){
		setTimeout(function(){
			var str = $("#attachment_view").find(".files").find(".name").text();
			var index = str.lastIndexOf(".");  
			var t = str.substring(index + 1, str.length);
			if(!(t == "pdf" || t == "png" || t == "jpg" || t == "jpeg")){
				alert("请重新上传文件，文件类型有误，文件类型为：pdf，png，jpg，jpeg。");
				$(".files").find(".delete").click();
				return false ;
			}
			setTimeout(function(){
				var fileArr = $("#attachment_view").find(".files").find(".name").text().split(".");
				if(fileArr[fileArr.length-1].replace(/\s*/g,"") != "pdf"){
					showimg();
				}else{
					showPdf();
				}
				$("#attachment_view").find(".files").find(".delete").click(function(){
					if($("#attachment_view").find(".files").find(".name").text().split(".")[1].replace(/\s*/g,"") != "pdf"){
						$("#red_attachment_zs").attr("src","");
					}else{
						$("#container").css("display","none");
						$(".pop").text("");
					}
				})
			},500);
		},500);
	})
	
	var from_dept_name = $("#from_dept_name").val();
	var from_number = $("#from_number").val();
	var doc_title = $("#doc_title").val();
	/*if(!(doc_title.indexOf(from_number) > -1 )){
		var doc_titles = "";
		if(from_dept_name != "" ){
			doc_titles = from_dept_name + " ";
		}
		if(doc_title != ""){
			doc_titles = doc_titles + doc_title;
		}
		if(from_number != ""){
			doc_titles = doc_titles + " ("+from_number+")";
		}
		$("#doc_title").val(doc_titles);
	}*/
	
	
	/*dwrBaseFunctionService.getRoleOfUser("G-1_sdbgsnb",{
		callback:function(result){
			if(result == "true"){
				
			}else{
				$("#psyj #modifyOpinon").remove();
			}
		}
	});*/
	
	if(!($("#remark_view").length > 0)){
		var t = new Date();
		var year = t.getFullYear();
		var month = t.getMonth()+1;
		if(month < 10){
			month = "0" + month;
		}
		var day = t.getDate();
		if(day < 10){
			day = "0"+day;
		}
		var timeFormat = year+"-"+month+"-"+day;
		$("#editOpinionNB").click(function(){
			$("#saveOpinionNB").css("display","block");
			$("#remark").css("display","block");
			$("#remark").css("border-width","1");
			$("#editOpinionNB").css("display","none");
			$("#remark").removeAttrs("readonly");
			$("#sdyjAutograph").hide();
			$("#sdyjAutograph_time").hide();
			$("#autograph_img").remove();
			$("#remark").focus();
			moveEnd($("#remark").get(0));
		});
		
		$("#saveOpinionNB").click(function(){
			$("#saveOpinionNB").css("display","none");
			if($("#remark").val() == undefined || $("#remark").val() == null || $("#remark").val() == ""){
				$("#editOpinionNB").css("display","block");
				//拟办意见修改人为李建
				if(cp_oaBasicInfo.cp_userByAccount != undefined ){
					if(cp_oaBasicInfo.cp_userByAccount.account  != undefined){
						if(cp_oaBasicInfo.cp_userByAccount.account == "lijian"){
							$("#sdyjAutograph").val(cp_oaBasicInfo.cp_userByAccount.name+"  " + timeFormat);
							$("#sdyjAutograph").hide();
							if($("#sdyjAutograph_time").length > 0){
								$("#sdyjAutograph_time").remove();
						}
							$("#sdyjAutograph").parent().append("<input class='text-align:right form-control' id='sdyjAutograph_time' name='sdyjAutograph_time' type='text' value=' "+ timeFormat +"' readonly='readonly' style='border: 0px; width: 120px; float: right; margin-top: 20px;'>");
							if($("#autograph_img").length > 0){
								$("#autograph_img").remove();
					}
							var id = cp_oaBasicInfo.cp_userByAccount.props.signature;
							$("#sdyjAutograph").parent().append("<img id='autograph_img' src='/user/component/AttachmentController/signpicture?attachmentId="+id+"' style='float:right' width='120' height='60'>");
							$("#sdyjAutograph").css("width","120px");
							$("#sdyjAutograph").css("float","right");
							$("#sdyjAutograph").css("margin-top","20px");
							$('#autograph_img').error(function () {
								$("#autograph_img").remove();
								if($("#sdyjAutograph_view").length > 0){
									$("#sdyjAutograph_view span").text($("#sdyjAutograph").val());
								}else{
									$("#sdyjAutograph_time").val($("#sdyjAutograph").val());
				}
								
				            });
						}
					}
				}
			}else{
				
				//拟办意见修改人为李建
				if(cp_oaBasicInfo.cp_userByAccount != undefined ){
					if(cp_oaBasicInfo.cp_userByAccount.account  != undefined){
						if(cp_oaBasicInfo.cp_userByAccount.account == "lijian"){
							$("#sdyjAutograph").val(cp_oaBasicInfo.cp_userByAccount.name+"  " + timeFormat);
							$("#sdyjAutograph").hide();
							if($("#sdyjAutograph_time").length > 0){
								$("#sdyjAutograph_time").remove();
						}
							$("#sdyjAutograph").parent().append("<input class='text-align:right form-control' id='sdyjAutograph_time' name='sdyjAutograph_time' type='text' value=' "+ timeFormat +"' readonly='readonly' style='border: 0px; width: 120px; float: right; margin-top: 20px;'>");
							if($("#autograph_img").length > 0){
								$("#autograph_img").remove();
					}
							var id = cp_oaBasicInfo.cp_userByAccount.props.signature;
							$("#sdyjAutograph").parent().append("<img id='autograph_img' src='/user/component/AttachmentController/signpicture?attachmentId="+id+"' style='float:right' width='120' height='60'>");
							$("#sdyjAutograph").css("width","120px");
							$("#sdyjAutograph").css("float","right");
							$("#sdyjAutograph").css("margin-top","20px");
							$('#autograph_img').error(function () {
								$("#autograph_img").remove();
								if($("#sdyjAutograph_view").length > 0){
									$("#sdyjAutograph_view span").text($("#sdyjAutograph").val());
								}else{
									$("#sdyjAutograph_time").val($("#sdyjAutograph").val());
				}
				            });
						}
					}
				}
				$("#reEditOpinionNB").css("display","block");
			}
			$("#remark").css("border-width","0");
			$("#remark").attr("readonly","readonly");
		});

		$("#reEditOpinionNB").click(function(){
			$("#reEditOpinionNB").css("display","none");
			$("#saveOpinionNB").css("display","block");
			$("#remark").css("border-width","0");
			$("#remark").removeAttrs("readonly");
			$("#sdyjAutograph").hide();
			$("#sdyjAutograph_time").hide();
			$("#autograph_img").remove();
			$("#remark").focus();
			moveEnd($("#remark").get(0));
		});
		$("#remark").css("border-width","0");
		$("#remark").css("font-size","14px");
	}else{
		$("#editOpinionNB").css("display","none");
		var value = $("#remark").val();
		$("#remark_view").css("display","block");
		$("#remark_view").html('<textarea style="height:70px;background-color:white;border: 0px;font-size: 14px;display: block;margin-left:-15px;" type="text" class="form-control" readonly="readonly">'+value+"</textarea>");
	}
	//处室收文意见-start
	if(pageConfig.id == "G_1_sdyjtChuShiReceipt"){
		$("#cheifEditOpinionPS").click(function(){
			$("#saveOpinionPS").css("display","block");
			$("#cheifOpinionTR .timeline_opinion").css("display","block");
			$("#cheifOpinionTR .tdContent").find(".psyjzs").css("margin-bottom","0px");
			$("#cheifEditOpinionPS").css("display","none");
			$(".timeline_opinion").find("textarea").focus();//点击批示，文本域聚焦
		})
		$("#saveOpinionPS").click(function(){
			saveAllOpinions($("#cheifOpinionTR").find("textarea")[0]);
			$("#saveOpinionPS").css("display","none");
			$("#cheifOpinionTR .timeline_opinion").css("display","none");
			$("#cheifOpinionTR .tdContent").find(".psyjzs").css("margin-bottom","80px");
			$("#cheifEditOpinionPS").css("display","block");
		});
		$("#editOpinionBL").click(function(){
			$("#saveOpinionBL").css("display","block");
			$("#cheifDept .timeline_opinion").css("display","block");
			$("#cheifDept .tdContent").find(".psyjzs").css("margin-bottom","0px");
			$("#editOpinionBL").css("display","none");
			$(".timeline_opinion").find("textarea").focus();//点击批示，文本域聚焦
		})
		$("#saveOpinionBL").click(function(){
			saveAllOpinions($("#cheifDept").find("textarea")[0]);
			$("#saveOpinionBL").css("display","none");
			$("#cheifDept .timeline_opinion").css("display","none");
			$("#cheifDept .tdContent").find(".psyjzs").css("margin-bottom","80px");
			$("#editOpinionBL").css("display","block");
		});
	}
	////处室收文意见-end
	
	//拟办意见签名 -- start 陈钦
	if($("#sdyjAutograph").length > 0) {
		$("#sdyjAutograph_view").css("float","right");
		$("#sdyjAutograph_view").css("margin-right","10px");
		
		$("#sdyjAutograph").css("text-align","right");
		$("#sdyjAutograph").css("display","none");
		$("#sdyjAutograph").attr("readonly","readonly");
		if($("#sdyjAutograph_view span").text() == ""){
			$("#autograph_img").remove();
		}else{
			$("#sdyjAutograph_view span").text($("#sdyjAutograph_view span").text().split("李建")[1]);
			$("#sdyjAutograph_view").css("float","right");
			$("#sdyjAutograph_view").css("margin-right","10px");
			$("#sdyjAutograph_view").css("margin-top","15px");
			if($("#autograph_img").length > 0){
				$("#autograph_img").remove();
			}
			dwrBaseFunctionService.getUserInfoByAccount("lijian",{
				"callback":function(ret){
					$("#sdyjAutograph").parent().append("<img id='autograph_img' src='/user/component/AttachmentController/signpicture?attachmentId="+ret.props.signature+"' style='float:right' width='120' height='60'>");
					$('#autograph_img').error(function () {
						$("#autograph_img").remove();
						$("#sdyjAutograph_view span").text($("#sdyjAutograph").val());
		            });
				},
				async:false
			}); 
		}
		
	}  
	//拟办意见签名 -- end 陈钦
	
	//业务处室反馈意见 -- start 陈钦
	
	if($("#ywcs").find("textarea")[0] != undefined){
		$("#ywcsOpinion\\$_opinion_popup_content").hide();
		$("#editOpinionYWCS").click(function(){
			$("#saveOpinionYWCS").css("display","block");
			$("#ywcs .timeline_opinion").css("display","block");
			$("#ywcs .tdContent").find(".ywcszs").css("margin-bottom","0px");
			$("#editOpinionYWCS").css("display","none");
			$("#ywcsOpinion\\$_opinion_popup_content").show();
			$("#ywcsOpinion\\$_opinion_popup_content").focus();
		});
		
		$("#saveOpinionYWCS").click(function(){
			saveAllOpinions($("#ywcs").find("textarea")[0]);
			$("#saveOpinionYWCS").css("display","none");
			$("#ywcs .timeline_opinion").css("display","none");
			$("#ywcs .tdContent").find(".ywcszs").css("margin-bottom","80px");
			$("#editOpinionYWCS").css("display","block");
		});
	}else{
		$("#editOpinionYWCS").css("display","none");
	}
	//业务处室反馈意见 -- end 陈钦
	
	//时间戳的文号用流水	
	var numberWordView = $("#NUMBER_WORD").val();
	if(numberWordView){
		$("[name='oaNumberWord']").text(numberWordView);
		$("[name='oaNumberWord']").show();
	}else{
		$("[name='oaNumberControl']").show();
	}
	
	/*setTimeout(function(){
		if($(".step-cur").find("span").text()=="登记"){
			//var str2 = $("#swcoanumber").text();
			//$("#swcoanumber").text(str2.substr(str2.length-1));
		}else{
			//var str = $("#control6").val();
			//$("#control6_view").find("span").text(str.substr(str.length-1));
			
		}
	},1500);*/
	
	
	
	if($("#psyj").find("textarea")[0] != undefined){
		$("#editOpinionPS").click(function(){
			$("#saveOpinionPS").css("display","block");
			$("#psyj .timeline_opinion").css("display","block");
			$("#psyj .tdContent").find(".psyjzs").css("margin-bottom","0px");
			$("#editOpinionPS").css("display","none");
			$(".timeline_opinion").find("textarea").focus();//点击批示，文本域聚焦
		});
		
		$("#saveOpinionPS").click(function(){
			saveAllOpinions($("#psyj").find("textarea")[0]);
			$("#saveOpinionPS").css("display","none");
			$("#psyj .timeline_opinion").css("display","none");
			$("#psyj .tdContent").find(".psyjzs").css("margin-bottom","80px");
			$("#editOpinionPS").css("display","block");
		});
	}else{
		$("#editOpinionPS").css("display","none");
	}
	 


		//隐藏所有输入框的边框
		$("table textarea").css("border","0px");
		$("table input").css("border","0px");
		$(".tdContent ").find(".input-group .input-group-addon").css("border","0px");
	
		//点击业务办理和流程跟踪的时候显示隐藏正文
		$("a[href='#business-area']").on("click",function(){
			$(".bottom").show();
		});

		$("a[href='#flowTrace']").on("click",function(){
			$(".bottom").hide();
		});
		
		//初始化流程特送按钮
		initFlowToStepBtn();
		
		//处室收文意见签署按钮显示隐藏--start
		if(($("#stepDescriptorIsStart").val() == "true" && $("#flowId").val() == "G_1_cheifDept")){
			$("#editOpinionBL").hide();
		}
		if(($("#framework_node").text() == "处内人员办理" && $("#flowId").val() == "G_1_cheifDept")){
			$("#cheifEditOpinionPS").hide();
		}
		if($("#stepDescriptorIsEnd").val() == "true" && ($("#flowId").val() == "G_1_cheifDept" || $("#flowId").val() == "G_1_kxcswlc")){
			$("#editOpinionBL").hide();
			$("#cheifEditOpinionPS").hide();
		}
		if($(".processform-layout-foot [cmd='workflow$encancelfoot']").length > 0 && ($("#flowId").val() == "G_1_cheifDept" || $("#flowId").val() == "G_1_kxcswlc")){
			$("#editOpinionBL").hide();
			$("#cheifEditOpinionPS").hide();
		}
		if($("#flowId").val() == "G_1_kxcswlc"){
			if($("#stepId").val() == "G_1_kxcswlc.4"){
				$("#editOpinionBL").hide();
			}
			if($("#stepId").val() != "G_1_kxcswlc.4"){
				$("#cheifEditOpinionPS").hide();
			}
		} 
		//处室收文意见签署按钮显示隐藏--end
		
		//科信处收文来文日期错乱
		if($("#from_date_picker").val()){
			$("#from_date_view").css("pointer-events","none");
			$("#from_date_view .input-group-addon").css("display","none");
		}
	//增加待阅填意见
		if(location.href.indexOf("sendtoread") > -1){
			if($("#chuanyue").length > 0 && $("#chuanyue").val() != undefined && $("#chuanyue").val() != null && $("#chuanyue").val() != ""){
				var chuanyueValue = JSON.parse($("#chuanyue").val());
				var trueUser = false;
				for(var i=0;i<chuanyueValue.length;i++){
					if(chuanyueValue[i].code == pageConfig.currentUserInfo.currentUserAccount){
						trueUser = true;
						break;
					}
				}
				if(trueUser == true){
					var html = '<button class="btn btn-default" id="editOpinionDaiyue" style="display: block;" type="button">批示</button><button class="btn btn-default" id="saveOpinionDaiyue" style="display: none;" type="button">保存</button>';
					$("#LEADER_OPINION").append(html);
					$("#editOpinionDaiyue").on("click",function(){
						$("#LEADER_OPINION .timeline_opinion").show();
						$("#LEADER_OPINION .timeline_opinion").find("textarea").focus();
						$("#saveOpinionDaiyue").show();
						$("#editOpinionDaiyue").hide();
					});
					$("#saveOpinionDaiyue").click(function(){
						  var signDeptName = pageConfig.currentUserInfo.currentUserDeptName;
						  var account = pageConfig.currentUserInfo.currentUserAccount;
						  var signUserName = pageConfig.currentUserInfo.currentUserName;
						    
						    //意见预览
						    var fieldId = "CENTER_LEADER";
						    var json = {
						        "signUserName":signUserName,
						        "signDeptName":signDeptName,
						        "signDate":new Date().getTime(),
						        "signContent":$("#LEADER_OPINION .timeline_opinion").find("textarea").val(),
						        "attrs":{"attachment":_webpaintObj.attachmentGroupid && _webpaintObj.attachmentGroupid!=""? _webpaintObj.attachmentGroupid:"",
						        	"isImportOpinion":false,
						        	"activeStepId":$("#activeStepId").val(),
						        	"account":account,
						        	"trustor":""
						        	}
						    };
						   
						    
						    
						    //设置pageForm中的字段值，用于通过校验
						    
						    var opinion = JSON.stringify(json);
						    var formId = $("#formId").val();
					        var beanId = $("#beanId").val();
					        var entryId = $("#instId").val();
					        var stepSerialNumber = $("#stepSN").val();
						    dwrBaseFunctionService.saveExtOpinion(opinion,formId,fieldId,beanId,parseInt(entryId),parseInt(stepSerialNumber),1,{
					            callback :function(data){
					                return;
					            }
					        });
						    
						    

						  
						$("#saveOpinionDaiyue").hide();
						$("#psyj .timeline_opinion").css("display","none");
						$("#psyj .tdContent").find(".psyjzs").css("margin-bottom","80px");
						$("#editOpinionDaiyue").show();
						
						reviewOpinions(fieldId, json);
					});
				}
			}
		}
});

//移动光标到input最后面
function moveEnd(obj) {
	obj.focus();
	var len = obj.value.length;
	if (document.selection) {
		var sel = obj.createTextRange();
		sel.moveStart('character', len); //设置开头的位置
		sel.collapse();
		sel.select();
	} else if (typeof obj.selectionStart == 'number' && typeof obj.selectionEnd == 'number') {
		obj.selectionStart = obj.selectionEnd = len;
	}
}

function showimg(){
	$("#red_attachment_zs").attr("src","/user/component/AttachmentController/download?attachmentId="+$(".files").find(".template-download").attr("id"));
	$("#container").css("display","none");
}

function showPdf() {
		
	var pdfDoc = null,
    pageNum = 1,
    pageRendering = false,
    pageNumPending = null,
    scale = 0.8;
	
			$("#red_attachment_zs").attr("src","");
           var container = document.getElementById("container");
           container.style.display = "block";
           var url = "/user/component/AttachmentController/priviewpdf?attachmentId="+$(".files").find(".template-download").attr("id");
           PDFJS.workerSrc = "/resources/oa/hdCommon/js/pdf.worker.js";
           PDFJS.getDocument(url).then(function getPdfHelloWorld(pdf) {
        	   for(var n = 1 ; n <= pdf.pdfInfo.numPages ; n++ ){
        		   $("#pop").append('<canvas id="the-canvas" style="width: 100%;" height="1683" width="1190">.</canvas>')
        		   pageRendering = true;
        		   pdf.getPage(n).then(function getPageHelloWorld(page) {
                       var canvas = document.getElementsByTagName("canvas")[page.pageIndex];
                       
                       var context = canvas.getContext('2d');
                       var viewport = page.getViewport(scale);
                       canvas.height = viewport.height;
                       canvas.width = viewport.width;
                       
                       var renderContext = {
                          canvasContext: context,
                          viewport: viewport
                       };
                       var renderTask = page.render(renderContext);

                           // Wait for rendering to finish
	                       renderTask.promise.then(function() {
	                           pageRendering = false;
	                           if (pageNumPending !== null) {
	                               // New page rendering is pending
	                               renderPage(pageNumPending);
	                               pageNumPending = null;
	                           }
	                       });
                     });
        	   }
            });
}


function saveAllOpinions(ele){
	  if($.trim(ele.value)!="" || (_webpaintObj.attachmentGroupid && _webpaintObj.attachmentGroupid!="")){
	    //保存常用意见
	    if (ele.value.length <= 500) {
	          // 将意见内容保存为常用意见，去掉自动保存常用意见功能（2018年6月1日）
	          /*var c = {
	            opiniontype : 'personal',
	            opinion : ele.value,
	            deptId : pageConfig.currentUserInfo.currentUserDeptId,
	            userId : pageConfig.currentUserInfo.currentUserAccount
	          };
	          opinionService.saveOpinion(c);*/
	        } else if(ele.value.length > 500){
	          $.tip("请输入最大500字符的意见")
	        }
	    
	  var entrustInfo = "";
	  var signDeptName = pageConfig.currentUserInfo.currentUserDeptName;
	  var account = pageConfig.currentUserInfo.currentUserAccount;
	  var trustor = "";
	  //起草环节不会有代办情况，不需要获取秘书、领导信息
	  if($("#instId").val()!="0"){
		  dwr.engine.setAsync(false);
		  dwrBaseFunctionService.getEntrustInfo(parseInt($("#activeStepId").val()),pageConfig.currentUserInfo.currentUserAccount,
				  { callback: function(data){
					  if(data.length>0){
						  entrustInfo = data[0].name;
						  signDeptName = data[0].deptName;
						  trustor = data[0].account;
					  }
				  }
				  });
		  dwr.engine.setAsync(true);
	  }
	  var signUserName = pageConfig.currentUserInfo.currentUserName;
	    if(entrustInfo != ""){
	      signUserName = entrustInfo;
	    }
	    //意见预览
	    var fieldId = ele.id.split("$")[0];
	    var json = {
	        "signUserName":signUserName,
	        "signDeptName":signDeptName,
	        "signDate":new Date().getTime(),
	        "signContent":ele.value,
	        "attrs":{"attachment":_webpaintObj.attachmentGroupid && _webpaintObj.attachmentGroupid!=""? _webpaintObj.attachmentGroupid:"",
	        	"isImportOpinion":false,
	        	"activeStepId":$("#activeStepId").val(),
	        	"account":account,
	        	"trustor":trustor
	        	}
	    };
	     _webpaintObj.opinionJsonObj=json;
	    reviewOpinions(fieldId,json);
	    //保存表单意见
	    $("#"+fieldId).val(JSON.stringify(json));
	    
	    //设置pageForm中的字段值，用于通过校验
	    var opinionField = ele.id.substring(0,ele.id.indexOf("$"));
	    var opinionObject = $("#"+opinionField+"_view").hdOaOpinion();
	    opinionObject.data("hdWidget").opinion = JSON.stringify(json);
	    
	    /*var formId = $("#formId").val();
	    var fieldId = ele.id.split("$")[0];
	    var beanId = "";
	    var entryId = parseInt($("#entryId").val());
	    var stepId = $("#stepId").val();
	    stepId = stepId.split(".")[1];
	    var stepSerialNumber = parseInt(stepId);
	    var content = ele.value;
	    hdOpinionService.updateOpinion(formId,fieldId,beanId,entryId,stepSerialNumber,content,{
	            callback : function(ret) {
	                console.log(ret);
	            }
	    })*/
	    

	  }else{
	    //设置pageForm中的字段值，如果字段为空，将值清空
	    var opinionField = ele.id.substring(0,ele.id.indexOf("$"));
	    var json = {
	            "attrs":{"activeStepId":$("#activeStepId").val()}
	        };
	    //意见预览
		reviewOpinions(opinionField,json);
		
	    var opinionObject = $("#"+opinionField+"_view").hdOaOpinion();
	    opinionObject.data("hdWidget").opinion = "";
	  }
	}

	function reviewOpinions(fieldId,json){
		//山东应急管理部项目取消意见预览
		 $.ajax({
		      type: 'POST',
		      url: contextPath+"/rest/product/oa/opinion/getOpinions",
		      async:false, //同步取值
		      data: {
		       "formId": $("#formId").val(),
		       "beanId": $("#beanId").val(),
		       "flowId": $("#flowId").val(),
		       "fieldId": fieldId,
		       "instId": $("#instId").val(),
		       "opinionJson": json=="" ? "" : JSON.stringify(json)
		      }, 
		      success: function (data) {
		        //console.log(data)
		        if(data.stat=="success"){
		        	if($("input[controlids='"+data.fieldId+"']").siblings()[0]){
		        		$("input[controlids='"+data.fieldId+"']").siblings().eq(0).remove();
		        		$("input[controlids='"+data.fieldId+"']").after(data.opinions);
		        	}else{
		        		$("input[controlids='"+data.fieldId+"']").after(data.opinions);
		        	}
		        }
		      }
		 });
	}

	function smsSend(userAccount) {
    var thePhone = "";
    userService.getUser(userAccount,
        {
          callback:function(ret){
            thePhone = ret.phone;
          },async:false
        });
    var smsUserInfo = {};
    smsUserInfo.phone = thePhone;
    smsUserInfo.account = userAccount;
    if(thePhone==""){
      $.tip("此用户未配置手机号，暂时无法发送短信。");
    }else{
      $.seniorDialog({
        title: "短信提醒",
        size: "sm", // lg: 大框，sm: 小框, '':默认为中等
        height: 200, // 弹现框高度
        contentId: "", //弹出框内展示内容
        template: { //弹出框内要加载的模板
          name: "", //<script>模板ID, 如使用jQuery.jsRenderTemplate.register注册的模板，必须将script属性设置为true,且模板id值不许出现'.','$'等特殊字符, 如$.jsRenderTemplate.register({id:"pageDesignerPropertyGroupTable",url:"xxx",script:true});
          data: {} //模板将要使用的数据
        },
        buttons: [ //弹出框按钮
          {
            label: "确定",
            clazz:"btn-primary",
            click: function(seniorDialog) {
              console.log(seniorDialog.find("#smsContent").val());
              dwrBaseFunctionService.sendSms(smsUserInfo.account,seniorDialog.find("#smsContent").val(),{
                callback: function(data) {
                  console.log(data);
                  var result = JSON.parse(data);
                  console.log(result.returnstatus);
                  if(result.returnstatus=="Success"){
                    $.tip("发送成功");

                  }else{
                    $.tip("发送失败");
                  }
                },async:false
              })
              seniorDialog.modal("hide");
            }
          }, // 按钮定义，label:按钮文本;	clazz:按钮样式;	click: 按钮单击事件, autoClose: 是否自动关闭
          "cancel" //组件内嵌的按钮:取消
        ],
        autoDestroy: true, //在窗体关闭后，是否自动销毁窗体，默认值:true
        onload:function(seniorDialog){
          seniorDialog.find(".modal-body").append("<div><textarea style=\"margin: 0px; width: 270px; height: 160px;\" id=\"smsContent\" name=\"smsContent\" type=\"text\" ></textarea></div>");
        }
      });
    }
  }

	//去右空格;
	function rtrim(s){
	    return s.replace(/(\s*$)/g, "");
	}
	
	

	//初始化流程特送按钮	
	var g_currentStepInfo;
	function initFlowToStepBtn(){
		try{
			//按钮模板
			var btnTemp = '<button type="button" class="btn btn-default btn-primary" ' +
					'id="{{:id}}" onclick="oaFlowToStepBtn(\'{{:tagStepId}}\',\'{{:stepUserAccount}}\',\'{{:stepUserName}}\');">' +
					'{{:name}}</button>';
			
			var flowId = $("#flowId").val();
			var currentStepId = $("#stepId").val();
			var account = cp_oaBasicInfo.cp_userByAccount.account;
			
			var pageMode = $("#mode").val();
			if(!flowId || pageMode != "VIEW"){
				return;
			}
			
			//获取当前用户所具有的特送按钮
			dwrOaFlowToStepService.findOaFlowToStepByFlowInfoList("%,"+account+",%",flowId,"%,"+currentStepId+",%",{callback:function(ret){
											
				var btnList = [];
				$(ret).each(function(){
					var config = this;
					var btnData = {
							"id":config.buttonId,
							"name":config.buttonName,						
							"tagStepId":config.stepId,
							"stepUserAccount":config.stepHandleUserAccount || "",
							"stepUserName":config.stepHandleUserName || ""
					};
					btnList.push($.templates(btnTemp).render(btnData));
				});
				
				if(btnList.length > 0){
					$(".processform-layout-foot").prepend($(btnList.join("")));
				}
				
				
			}});
			
			var instId = $("#instId").val();		
			//获取当前流程节点信息
			dwrWorkflowListService.getCurrentSteps(instId,function(ret){
				if(ret.length==0){
					var newret = {};
					newret["id"]="0";
					newret["stepName"]="结束";
					ret.push(newret);
				}
				g_currentStepInfo = ret;
			});
			
		}catch(err){
			if(console){
				console.log(err);
			}
		}	
	}	

	//oa流程特送
	function oaFlowToStepBtn(tagStepId,stepUserAccount,stepUserName){
		if(!stepUserAccount){
			//没有配置用户，需要提交时选择
			var deptid= $("#belongedOrgId").val().length==0?"G-1":"G"+$("#belongedOrgId").val();
			var deptname = $("#belonged_org_name").length==0?"组织机构":$("#belonged_org_name").val();
			$().seniorOaExternalUserSelector({
				rootData:{id : deptid, pId : null, name : deptname, isParent : true},
		    	selection : 'multi',
		    	tabCfg : 'user,personalusergroup',
		    	grzCfg : 'yes',
				defaults : [],
				onOkClick : function(result) {				
					if(result.length > 0){
						var userAccountList = [];
						var userNameList = [];
						$(result).each(function(){
							userAccountList.push(this.code);
							userNameList.push(this.name);
						});
						activeOaFlowToStep(tagStepId,userAccountList.join(","),userNameList.join(","));
					}else{
						$.tip("请选择要提交的用户");
					}	
				}
		  });
		}else{
			activeOaFlowToStep(tagStepId,stepUserAccount,stepUserName);
		}
		
	}

	//oa流程特送
	function activeOaFlowToStep(tagStepId,stepUserAccount,stepUserName){	
		
		var instId = $("#instId").val();
		var curStepId = g_currentStepInfo[0].id;
		
		var stepUserAccountList = stepUserAccount.split(",");
		var stepUserNameList = stepUserName.split(",");
		
		var operators = [];
		$(stepUserAccountList).each(function(index){
			operators.push({
				$dwrClassName: 'OperatorBean',
				type : 'User',
				code : this,
				name : stepUserNameList[index]
			});
		});
		
		dwrWorkflowListService.interveneToStep(instId, curStepId, tagStepId, operators,null, {
			callback : function(ret) {
				location.href = location.href;
			},
			exceptionHandler : function(errorString, exception) {
				$.tip("error");
			},
		});
	}

//提交前扩展函数
function beforeDoCommand(command, action, el){
  //处理标题字段的值
  dealTitle();
  return true;
}

//处理标题字段的值
function dealTitle() {
  var from_dept_name = $("#from_dept_name").val();
  var from_number = $("#from_number").val();
  if(from_number!="" && from_number!=docnum){
    from_number = " (" + from_number + ")";
  }else{
    from_number = "";
    $("#from_number").val("");
  }
  var doc_title = $("#action_arr").val();
  if ($("#stepDescriptorIsStart").val()=="true") {
    $("#doc_title").val(from_dept_name +" "+ doc_title +" " + from_number);
  }
}
	
$(function(){
	$(window).unbind('beforeunload');
	window.onbeforeunload = null;
})